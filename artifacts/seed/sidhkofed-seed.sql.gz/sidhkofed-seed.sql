--
-- PostgreSQL database dump
--

\restrict NzlMo74XolW0QqIAAi9NRbyziypt7YhOy61dVjYoiY1XMmDDRh5wpxkKEAScViD

-- Dumped from database version 18.4
-- Dumped by pg_dump version 18.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.videos DROP CONSTRAINT IF EXISTS videos_updated_by_fkey;
ALTER TABLE IF EXISTS ONLY public.videos DROP CONSTRAINT IF EXISTS videos_thumbnail_media_id_fkey;
ALTER TABLE IF EXISTS ONLY public.videos DROP CONSTRAINT IF EXISTS videos_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS user_roles_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS user_roles_role_id_fkey;
ALTER TABLE IF EXISTS ONLY public.toolkits DROP CONSTRAINT IF EXISTS toolkits_updated_by_fkey;
ALTER TABLE IF EXISTS ONLY public.toolkits DROP CONSTRAINT IF EXISTS toolkits_programme_scheme_id_fkey;
ALTER TABLE IF EXISTS ONLY public.toolkits DROP CONSTRAINT IF EXISTS toolkits_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.toolkits DROP CONSTRAINT IF EXISTS toolkits_cover_media_id_fkey;
ALTER TABLE IF EXISTS ONLY public.toolkits DROP CONSTRAINT IF EXISTS toolkits_commodity_id_fkey;
ALTER TABLE IF EXISTS ONLY public.toolkit_items DROP CONSTRAINT IF EXISTS toolkit_items_toolkit_id_fkey;
ALTER TABLE IF EXISTS ONLY public.toolkit_distribution_summaries DROP CONSTRAINT IF EXISTS toolkit_distribution_summaries_updated_by_fkey;
ALTER TABLE IF EXISTS ONLY public.toolkit_distribution_summaries DROP CONSTRAINT IF EXISTS toolkit_distribution_summaries_toolkit_id_fkey;
ALTER TABLE IF EXISTS ONLY public.toolkit_distribution_summaries DROP CONSTRAINT IF EXISTS toolkit_distribution_summaries_event_id_fkey;
ALTER TABLE IF EXISTS ONLY public.toolkit_distribution_summaries DROP CONSTRAINT IF EXISTS toolkit_distribution_summaries_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.toolkit_distribution_items DROP CONSTRAINT IF EXISTS toolkit_distribution_items_toolkit_item_id_fkey;
ALTER TABLE IF EXISTS ONLY public.toolkit_distribution_items DROP CONSTRAINT IF EXISTS toolkit_distribution_items_toolkit_distribution_summary_id_fkey;
ALTER TABLE IF EXISTS ONLY public.tenders DROP CONSTRAINT IF EXISTS tenders_updated_by_fkey;
ALTER TABLE IF EXISTS ONLY public.tenders DROP CONSTRAINT IF EXISTS tenders_tender_type_id_fkey;
ALTER TABLE IF EXISTS ONLY public.tenders DROP CONSTRAINT IF EXISTS tenders_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.settings DROP CONSTRAINT IF EXISTS settings_updated_by_fkey;
ALTER TABLE IF EXISTS ONLY public.role_permissions DROP CONSTRAINT IF EXISTS role_permissions_role_id_fkey;
ALTER TABLE IF EXISTS ONLY public.role_permissions DROP CONSTRAINT IF EXISTS role_permissions_permission_id_fkey;
ALTER TABLE IF EXISTS ONLY public.reporting_periods DROP CONSTRAINT IF EXISTS reporting_periods_financial_year_id_fkey;
ALTER TABLE IF EXISTS ONLY public.programme_schemes DROP CONSTRAINT IF EXISTS programme_schemes_updated_by_fkey;
ALTER TABLE IF EXISTS ONLY public.programme_schemes DROP CONSTRAINT IF EXISTS programme_schemes_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.programme_schemes DROP CONSTRAINT IF EXISTS programme_schemes_cover_media_id_fkey;
ALTER TABLE IF EXISTS ONLY public.programme_permitted_training_types DROP CONSTRAINT IF EXISTS programme_permitted_training_types_training_type_id_fkey;
ALTER TABLE IF EXISTS ONLY public.programme_permitted_training_types DROP CONSTRAINT IF EXISTS programme_permitted_training_types_programme_scheme_id_fkey;
ALTER TABLE IF EXISTS ONLY public.programme_commodities DROP CONSTRAINT IF EXISTS programme_commodities_programme_scheme_id_fkey;
ALTER TABLE IF EXISTS ONLY public.programme_commodities DROP CONSTRAINT IF EXISTS programme_commodities_commodity_id_fkey;
ALTER TABLE IF EXISTS ONLY public.procurement_updates DROP CONSTRAINT IF EXISTS procurement_updates_updated_by_fkey;
ALTER TABLE IF EXISTS ONLY public.procurement_updates DROP CONSTRAINT IF EXISTS procurement_updates_programme_scheme_id_fkey;
ALTER TABLE IF EXISTS ONLY public.procurement_updates DROP CONSTRAINT IF EXISTS procurement_updates_procurement_update_type_id_fkey;
ALTER TABLE IF EXISTS ONLY public.procurement_updates DROP CONSTRAINT IF EXISTS procurement_updates_document_id_fkey;
ALTER TABLE IF EXISTS ONLY public.procurement_updates DROP CONSTRAINT IF EXISTS procurement_updates_district_id_fkey;
ALTER TABLE IF EXISTS ONLY public.procurement_updates DROP CONSTRAINT IF EXISTS procurement_updates_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.procurement_updates DROP CONSTRAINT IF EXISTS procurement_updates_commodity_id_fkey;
ALTER TABLE IF EXISTS ONLY public.procurement_updates DROP CONSTRAINT IF EXISTS procurement_updates_block_id_fkey;
ALTER TABLE IF EXISTS ONLY public.pages DROP CONSTRAINT IF EXISTS pages_updated_by_fkey;
ALTER TABLE IF EXISTS ONLY public.pages DROP CONSTRAINT IF EXISTS pages_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.official_communications DROP CONSTRAINT IF EXISTS official_communications_updated_by_fkey;
ALTER TABLE IF EXISTS ONLY public.official_communications DROP CONSTRAINT IF EXISTS official_communications_document_id_fkey;
ALTER TABLE IF EXISTS ONLY public.official_communications DROP CONSTRAINT IF EXISTS official_communications_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.official_communications DROP CONSTRAINT IF EXISTS official_communications_communication_type_id_fkey;
ALTER TABLE IF EXISTS ONLY public.menu_items DROP CONSTRAINT IF EXISTS menu_items_updated_by_fkey;
ALTER TABLE IF EXISTS ONLY public.menu_items DROP CONSTRAINT IF EXISTS menu_items_parent_id_fkey;
ALTER TABLE IF EXISTS ONLY public.menu_items DROP CONSTRAINT IF EXISTS menu_items_page_id_fkey;
ALTER TABLE IF EXISTS ONLY public.menu_items DROP CONSTRAINT IF EXISTS menu_items_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.media_usages DROP CONSTRAINT IF EXISTS media_usages_media_id_fkey;
ALTER TABLE IF EXISTS ONLY public.media_assets DROP CONSTRAINT IF EXISTS media_assets_uploaded_by_fkey;
ALTER TABLE IF EXISTS ONLY public.media_assets DROP CONSTRAINT IF EXISTS media_assets_replaced_by_id_fkey;
ALTER TABLE IF EXISTS ONLY public.institutions DROP CONSTRAINT IF EXISTS institutions_updated_by_fkey;
ALTER TABLE IF EXISTS ONLY public.institutions DROP CONSTRAINT IF EXISTS institutions_logo_media_id_fkey;
ALTER TABLE IF EXISTS ONLY public.institutions DROP CONSTRAINT IF EXISTS institutions_institution_type_id_fkey;
ALTER TABLE IF EXISTS ONLY public.institutions DROP CONSTRAINT IF EXISTS institutions_district_id_fkey;
ALTER TABLE IF EXISTS ONLY public.institutions DROP CONSTRAINT IF EXISTS institutions_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.institutional_memberships DROP CONSTRAINT IF EXISTS institutional_memberships_updated_by_fkey;
ALTER TABLE IF EXISTS ONLY public.institutional_memberships DROP CONSTRAINT IF EXISTS institutional_memberships_reporting_period_id_fkey;
ALTER TABLE IF EXISTS ONLY public.institutional_memberships DROP CONSTRAINT IF EXISTS institutional_memberships_institution_id_fkey;
ALTER TABLE IF EXISTS ONLY public.institutional_memberships DROP CONSTRAINT IF EXISTS institutional_memberships_district_union_id_fkey;
ALTER TABLE IF EXISTS ONLY public.institutional_memberships DROP CONSTRAINT IF EXISTS institutional_memberships_district_id_fkey;
ALTER TABLE IF EXISTS ONLY public.institutional_memberships DROP CONSTRAINT IF EXISTS institutional_memberships_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.gallery_images DROP CONSTRAINT IF EXISTS gallery_images_media_id_fkey;
ALTER TABLE IF EXISTS ONLY public.gallery_images DROP CONSTRAINT IF EXISTS gallery_images_gallery_id_fkey;
ALTER TABLE IF EXISTS ONLY public.galleries DROP CONSTRAINT IF EXISTS galleries_updated_by_fkey;
ALTER TABLE IF EXISTS ONLY public.galleries DROP CONSTRAINT IF EXISTS galleries_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.galleries DROP CONSTRAINT IF EXISTS galleries_cover_media_id_fkey;
ALTER TABLE IF EXISTS ONLY public.faqs DROP CONSTRAINT IF EXISTS faqs_updated_by_fkey;
ALTER TABLE IF EXISTS ONLY public.faqs DROP CONSTRAINT IF EXISTS faqs_faq_category_id_fkey;
ALTER TABLE IF EXISTS ONLY public.faqs DROP CONSTRAINT IF EXISTS faqs_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.events DROP CONSTRAINT IF EXISTS events_updated_by_fkey;
ALTER TABLE IF EXISTS ONLY public.events DROP CONSTRAINT IF EXISTS events_training_type_id_fkey;
ALTER TABLE IF EXISTS ONLY public.events DROP CONSTRAINT IF EXISTS events_event_type_id_fkey;
ALTER TABLE IF EXISTS ONLY public.events DROP CONSTRAINT IF EXISTS events_district_id_fkey;
ALTER TABLE IF EXISTS ONLY public.events DROP CONSTRAINT IF EXISTS events_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.events DROP CONSTRAINT IF EXISTS events_cover_media_id_fkey;
ALTER TABLE IF EXISTS ONLY public.events DROP CONSTRAINT IF EXISTS events_block_id_fkey;
ALTER TABLE IF EXISTS ONLY public.event_programmes DROP CONSTRAINT IF EXISTS event_programmes_programme_scheme_id_fkey;
ALTER TABLE IF EXISTS ONLY public.event_programmes DROP CONSTRAINT IF EXISTS event_programmes_event_id_fkey;
ALTER TABLE IF EXISTS ONLY public.event_news DROP CONSTRAINT IF EXISTS event_news_updated_by_fkey;
ALTER TABLE IF EXISTS ONLY public.event_news DROP CONSTRAINT IF EXISTS event_news_event_id_fkey;
ALTER TABLE IF EXISTS ONLY public.event_news DROP CONSTRAINT IF EXISTS event_news_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.event_news DROP CONSTRAINT IF EXISTS event_news_cover_media_id_fkey;
ALTER TABLE IF EXISTS ONLY public.event_institutions DROP CONSTRAINT IF EXISTS event_institutions_institution_id_fkey;
ALTER TABLE IF EXISTS ONLY public.event_institutions DROP CONSTRAINT IF EXISTS event_institutions_event_id_fkey;
ALTER TABLE IF EXISTS ONLY public.event_galleries DROP CONSTRAINT IF EXISTS event_galleries_gallery_id_fkey;
ALTER TABLE IF EXISTS ONLY public.event_galleries DROP CONSTRAINT IF EXISTS event_galleries_event_id_fkey;
ALTER TABLE IF EXISTS ONLY public.event_field_definitions DROP CONSTRAINT IF EXISTS event_field_definitions_event_type_id_fkey;
ALTER TABLE IF EXISTS ONLY public.event_documents DROP CONSTRAINT IF EXISTS event_documents_event_id_fkey;
ALTER TABLE IF EXISTS ONLY public.event_documents DROP CONSTRAINT IF EXISTS event_documents_document_id_fkey;
ALTER TABLE IF EXISTS ONLY public.event_commodities DROP CONSTRAINT IF EXISTS event_commodities_event_id_fkey;
ALTER TABLE IF EXISTS ONLY public.event_commodities DROP CONSTRAINT IF EXISTS event_commodities_commodity_id_fkey;
ALTER TABLE IF EXISTS ONLY public.enquiries DROP CONSTRAINT IF EXISTS enquiries_programme_scheme_id_fkey;
ALTER TABLE IF EXISTS ONLY public.enquiries DROP CONSTRAINT IF EXISTS enquiries_enquiry_type_id_fkey;
ALTER TABLE IF EXISTS ONLY public.enquiries DROP CONSTRAINT IF EXISTS enquiries_commodity_id_fkey;
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS documents_updated_by_fkey;
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS documents_knowledge_category_id_fkey;
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS documents_financial_year_id_fkey;
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS documents_file_asset_id_fkey;
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS documents_document_type_id_fkey;
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS documents_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.document_tags DROP CONSTRAINT IF EXISTS document_tags_tag_id_fkey;
ALTER TABLE IF EXISTS ONLY public.document_tags DROP CONSTRAINT IF EXISTS document_tags_document_id_fkey;
ALTER TABLE IF EXISTS ONLY public.document_programmes DROP CONSTRAINT IF EXISTS document_programmes_programme_scheme_id_fkey;
ALTER TABLE IF EXISTS ONLY public.document_programmes DROP CONSTRAINT IF EXISTS document_programmes_document_id_fkey;
ALTER TABLE IF EXISTS ONLY public.document_institutions DROP CONSTRAINT IF EXISTS document_institutions_institution_id_fkey;
ALTER TABLE IF EXISTS ONLY public.document_institutions DROP CONSTRAINT IF EXISTS document_institutions_document_id_fkey;
ALTER TABLE IF EXISTS ONLY public.document_districts DROP CONSTRAINT IF EXISTS document_districts_document_id_fkey;
ALTER TABLE IF EXISTS ONLY public.document_districts DROP CONSTRAINT IF EXISTS document_districts_district_id_fkey;
ALTER TABLE IF EXISTS ONLY public.document_commodities DROP CONSTRAINT IF EXISTS document_commodities_document_id_fkey;
ALTER TABLE IF EXISTS ONLY public.document_commodities DROP CONSTRAINT IF EXISTS document_commodities_commodity_id_fkey;
ALTER TABLE IF EXISTS ONLY public.digital_services DROP CONSTRAINT IF EXISTS digital_services_updated_by_fkey;
ALTER TABLE IF EXISTS ONLY public.digital_services DROP CONSTRAINT IF EXISTS digital_services_icon_media_id_fkey;
ALTER TABLE IF EXISTS ONLY public.digital_services DROP CONSTRAINT IF EXISTS digital_services_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.dashboard_reports DROP CONSTRAINT IF EXISTS dashboard_reports_updated_by_fkey;
ALTER TABLE IF EXISTS ONLY public.dashboard_reports DROP CONSTRAINT IF EXISTS dashboard_reports_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.dashboard_metrics DROP CONSTRAINT IF EXISTS dashboard_metrics_updated_by_fkey;
ALTER TABLE IF EXISTS ONLY public.dashboard_metrics DROP CONSTRAINT IF EXISTS dashboard_metrics_reporting_period_id_fkey;
ALTER TABLE IF EXISTS ONLY public.dashboard_metrics DROP CONSTRAINT IF EXISTS dashboard_metrics_report_id_fkey;
ALTER TABLE IF EXISTS ONLY public.dashboard_metrics DROP CONSTRAINT IF EXISTS dashboard_metrics_financial_year_id_fkey;
ALTER TABLE IF EXISTS ONLY public.dashboard_metrics DROP CONSTRAINT IF EXISTS dashboard_metrics_dataset_id_fkey;
ALTER TABLE IF EXISTS ONLY public.dashboard_metrics DROP CONSTRAINT IF EXISTS dashboard_metrics_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.dashboard_datasets DROP CONSTRAINT IF EXISTS dashboard_datasets_source_file_asset_id_fkey;
ALTER TABLE IF EXISTS ONLY public.dashboard_datasets DROP CONSTRAINT IF EXISTS dashboard_datasets_reporting_period_id_fkey;
ALTER TABLE IF EXISTS ONLY public.dashboard_datasets DROP CONSTRAINT IF EXISTS dashboard_datasets_report_id_fkey;
ALTER TABLE IF EXISTS ONLY public.dashboard_datasets DROP CONSTRAINT IF EXISTS dashboard_datasets_financial_year_id_fkey;
ALTER TABLE IF EXISTS ONLY public.dashboard_datasets DROP CONSTRAINT IF EXISTS dashboard_datasets_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.commodities DROP CONSTRAINT IF EXISTS commodities_icon_media_id_fkey;
ALTER TABLE IF EXISTS ONLY public.blocks DROP CONSTRAINT IF EXISTS blocks_district_id_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_logs DROP CONSTRAINT IF EXISTS audit_logs_user_id_fkey;
DROP INDEX IF EXISTS public.videos_slug_key;
DROP INDEX IF EXISTS public.videos_show_on_homepage_display_order_idx;
DROP INDEX IF EXISTS public.videos_publication_state_public_visibility_archived_at_publ_idx;
DROP INDEX IF EXISTS public.users_email_key;
DROP INDEX IF EXISTS public.user_roles_user_id_role_id_key;
DROP INDEX IF EXISTS public.training_types_slug_key;
DROP INDEX IF EXISTS public.training_types_name_en_key;
DROP INDEX IF EXISTS public.toolkits_slug_key;
DROP INDEX IF EXISTS public.toolkits_show_on_homepage_display_order_idx;
DROP INDEX IF EXISTS public.toolkits_pubstate_vis_archived_published_idx;
DROP INDEX IF EXISTS public.toolkit_items_toolkit_id_display_order_idx;
DROP INDEX IF EXISTS public.toolkit_distribution_summaries_toolkit_id_idx;
DROP INDEX IF EXISTS public.toolkit_distribution_summaries_event_id_toolkit_id_key;
DROP INDEX IF EXISTS public.toolkit_distribution_items_toolkit_item_id_idx;
DROP INDEX IF EXISTS public.toolkit_distribution_items_summary_id_item_id_key;
DROP INDEX IF EXISTS public.tenders_tender_type_id_idx;
DROP INDEX IF EXISTS public.tenders_tender_number_key;
DROP INDEX IF EXISTS public.tenders_submission_deadline_idx;
DROP INDEX IF EXISTS public.tenders_slug_key;
DROP INDEX IF EXISTS public.tenders_show_on_homepage_display_order_idx;
DROP INDEX IF EXISTS public.tenders_search_vector_gin_idx;
DROP INDEX IF EXISTS public.tenders_publication_state_public_visibility_archived_at_pub_idx;
DROP INDEX IF EXISTS public.tender_types_slug_key;
DROP INDEX IF EXISTS public.tender_types_name_en_key;
DROP INDEX IF EXISTS public.tags_slug_key;
DROP INDEX IF EXISTS public.tags_name_en_key;
DROP INDEX IF EXISTS public.settings_key_key;
DROP INDEX IF EXISTS public.roles_key_key;
DROP INDEX IF EXISTS public.role_permissions_role_id_permission_id_key;
DROP INDEX IF EXISTS public.reporting_periods_slug_key;
DROP INDEX IF EXISTS public.reporting_periods_financial_year_id_idx;
DROP INDEX IF EXISTS public.programme_schemes_slug_key;
DROP INDEX IF EXISTS public.programme_schemes_show_on_homepage_display_order_idx;
DROP INDEX IF EXISTS public.programme_schemes_search_vector_gin_idx;
DROP INDEX IF EXISTS public.programme_schemes_publication_state_public_visibility_archi_idx;
DROP INDEX IF EXISTS public.programme_permitted_training_types_training_type_id_program_idx;
DROP INDEX IF EXISTS public.programme_permitted_training_types_programme_scheme_id_trai_key;
DROP INDEX IF EXISTS public.programme_commodities_programme_scheme_id_commodity_id_key;
DROP INDEX IF EXISTS public.programme_commodities_commodity_id_programme_scheme_id_idx;
DROP INDEX IF EXISTS public.procurement_updates_slug_key;
DROP INDEX IF EXISTS public.procurement_updates_show_on_homepage_display_order_idx;
DROP INDEX IF EXISTS public.procurement_updates_search_vector_gin_idx;
DROP INDEX IF EXISTS public.procurement_updates_publication_state_public_visibility_arc_idx;
DROP INDEX IF EXISTS public.procurement_updates_procurement_update_type_id_idx;
DROP INDEX IF EXISTS public.procurement_updates_effective_date_idx;
DROP INDEX IF EXISTS public.procurement_updates_district_id_idx;
DROP INDEX IF EXISTS public.procurement_updates_commodity_id_idx;
DROP INDEX IF EXISTS public.procurement_update_types_slug_key;
DROP INDEX IF EXISTS public.procurement_update_types_name_en_key;
DROP INDEX IF EXISTS public.permissions_module_action_key;
DROP INDEX IF EXISTS public.permissions_key_key;
DROP INDEX IF EXISTS public.pages_slug_key;
DROP INDEX IF EXISTS public.pages_show_on_homepage_display_order_idx;
DROP INDEX IF EXISTS public.pages_search_vector_gin_idx;
DROP INDEX IF EXISTS public.pages_publication_state_public_visibility_archived_at_publi_idx;
DROP INDEX IF EXISTS public.official_communications_slug_key;
DROP INDEX IF EXISTS public.official_communications_show_on_homepage_display_order_idx;
DROP INDEX IF EXISTS public.official_communications_search_vector_gin_idx;
DROP INDEX IF EXISTS public.official_communications_publication_state_public_visibility_idx;
DROP INDEX IF EXISTS public.official_communications_issue_date_idx;
DROP INDEX IF EXISTS public.official_communications_communication_type_id_idx;
DROP INDEX IF EXISTS public.menu_items_parent_id_idx;
DROP INDEX IF EXISTS public.menu_items_location_display_order_idx;
DROP INDEX IF EXISTS public.media_usages_media_id_entity_type_entity_id_field_key;
DROP INDEX IF EXISTS public.media_usages_entity_type_entity_id_idx;
DROP INDEX IF EXISTS public.media_assets_storage_key_key;
DROP INDEX IF EXISTS public.media_assets_mime_type_idx;
DROP INDEX IF EXISTS public.media_assets_checksum_idx;
DROP INDEX IF EXISTS public.media_assets_archived_at_idx;
DROP INDEX IF EXISTS public.knowledge_categories_slug_key;
DROP INDEX IF EXISTS public.knowledge_categories_name_en_key;
DROP INDEX IF EXISTS public.institutions_slug_key;
DROP INDEX IF EXISTS public.institutions_show_on_homepage_display_order_idx;
DROP INDEX IF EXISTS public.institutions_publication_state_public_visibility_archived_a_idx;
DROP INDEX IF EXISTS public.institutions_institution_type_id_idx;
DROP INDEX IF EXISTS public.institutions_district_id_idx;
DROP INDEX IF EXISTS public.institutional_memberships_slug_key;
DROP INDEX IF EXISTS public.institutional_memberships_show_on_homepage_display_order_idx;
DROP INDEX IF EXISTS public.institutional_memberships_publication_state_public_visibili_idx;
DROP INDEX IF EXISTS public.institutional_memberships_membership_number_key;
DROP INDEX IF EXISTS public.institutional_memberships_membership_level_membership_type__idx;
DROP INDEX IF EXISTS public.institutional_memberships_institution_id_idx;
DROP INDEX IF EXISTS public.institutional_memberships_district_id_idx;
DROP INDEX IF EXISTS public.institutional_memberships_business_key;
DROP INDEX IF EXISTS public.institution_types_slug_key;
DROP INDEX IF EXISTS public.institution_types_name_en_key;
DROP INDEX IF EXISTS public.gallery_images_gallery_id_media_id_key;
DROP INDEX IF EXISTS public.galleries_slug_key;
DROP INDEX IF EXISTS public.galleries_publication_state_public_visibility_archived_at_p_idx;
DROP INDEX IF EXISTS public.financial_years_label_key;
DROP INDEX IF EXISTS public.faqs_slug_key;
DROP INDEX IF EXISTS public.faqs_show_on_homepage_display_order_idx;
DROP INDEX IF EXISTS public.faqs_publication_state_public_visibility_archived_at_publis_idx;
DROP INDEX IF EXISTS public.faqs_faq_category_id_idx;
DROP INDEX IF EXISTS public.faq_categories_slug_key;
DROP INDEX IF EXISTS public.faq_categories_name_en_key;
DROP INDEX IF EXISTS public.events_start_date_idx;
DROP INDEX IF EXISTS public.events_slug_key;
DROP INDEX IF EXISTS public.events_show_on_homepage_display_order_idx;
DROP INDEX IF EXISTS public.events_search_vector_gin_idx;
DROP INDEX IF EXISTS public.events_pubstate_vis_archived_publishstart_idx;
DROP INDEX IF EXISTS public.events_publication_state_public_visibility_archived_at_publ_idx;
DROP INDEX IF EXISTS public.events_event_type_id_idx;
DROP INDEX IF EXISTS public.events_event_status_idx;
DROP INDEX IF EXISTS public.events_district_id_idx;
DROP INDEX IF EXISTS public.event_types_slug_key;
DROP INDEX IF EXISTS public.event_types_name_en_key;
DROP INDEX IF EXISTS public.event_programmes_programme_scheme_id_event_id_idx;
DROP INDEX IF EXISTS public.event_programmes_event_id_programme_scheme_id_key;
DROP INDEX IF EXISTS public.event_news_slug_key;
DROP INDEX IF EXISTS public.event_news_search_vector_gin_idx;
DROP INDEX IF EXISTS public.event_news_pubstate_vis_archived_publishstart_idx;
DROP INDEX IF EXISTS public.event_news_publication_state_public_visibility_archived_at__idx;
DROP INDEX IF EXISTS public.event_news_news_published_at_idx;
DROP INDEX IF EXISTS public.event_news_event_id_key;
DROP INDEX IF EXISTS public.event_institutions_institution_id_event_id_idx;
DROP INDEX IF EXISTS public.event_institutions_event_id_institution_id_key;
DROP INDEX IF EXISTS public.event_galleries_gallery_id_event_id_idx;
DROP INDEX IF EXISTS public.event_galleries_event_id_gallery_id_key;
DROP INDEX IF EXISTS public.event_field_definitions_event_type_id_idx;
DROP INDEX IF EXISTS public.event_field_definitions_event_type_id_field_key_key;
DROP INDEX IF EXISTS public.event_documents_event_id_document_id_key;
DROP INDEX IF EXISTS public.event_documents_document_id_event_id_idx;
DROP INDEX IF EXISTS public.event_commodities_event_id_commodity_id_key;
DROP INDEX IF EXISTS public.event_commodities_commodity_id_event_id_idx;
DROP INDEX IF EXISTS public.enquiry_types_slug_key;
DROP INDEX IF EXISTS public.enquiry_types_name_en_key;
DROP INDEX IF EXISTS public.enquiries_submitted_at_idx;
DROP INDEX IF EXISTS public.enquiries_spam_state_idx;
DROP INDEX IF EXISTS public.enquiries_enquiry_type_id_idx;
DROP INDEX IF EXISTS public.enquiries_archived_at_idx;
DROP INDEX IF EXISTS public.documents_slug_key;
DROP INDEX IF EXISTS public.documents_show_in_knowledge_centre_idx;
DROP INDEX IF EXISTS public.documents_search_vector_gin_idx;
DROP INDEX IF EXISTS public.documents_pubstate_vis_ispublic_archived_publishstart_idx;
DROP INDEX IF EXISTS public.documents_publication_state_public_visibility_is_public_arc_idx;
DROP INDEX IF EXISTS public.documents_publication_state_public_visibility_archived_at_p_idx;
DROP INDEX IF EXISTS public.documents_publication_date_idx;
DROP INDEX IF EXISTS public.documents_knowledge_category_id_idx;
DROP INDEX IF EXISTS public.documents_financial_year_id_idx;
DROP INDEX IF EXISTS public.documents_document_type_id_idx;
DROP INDEX IF EXISTS public.document_types_slug_key;
DROP INDEX IF EXISTS public.document_types_name_en_key;
DROP INDEX IF EXISTS public.document_tags_tag_id_document_id_idx;
DROP INDEX IF EXISTS public.document_tags_document_id_tag_id_key;
DROP INDEX IF EXISTS public.document_programmes_programme_scheme_id_document_id_idx;
DROP INDEX IF EXISTS public.document_programmes_document_id_programme_scheme_id_key;
DROP INDEX IF EXISTS public.document_institutions_institution_id_document_id_idx;
DROP INDEX IF EXISTS public.document_institutions_document_id_institution_id_key;
DROP INDEX IF EXISTS public.document_districts_document_id_district_id_key;
DROP INDEX IF EXISTS public.document_districts_district_id_document_id_idx;
DROP INDEX IF EXISTS public.document_commodities_document_id_commodity_id_key;
DROP INDEX IF EXISTS public.document_commodities_commodity_id_document_id_idx;
DROP INDEX IF EXISTS public.districts_slug_key;
DROP INDEX IF EXISTS public.districts_name_en_key;
DROP INDEX IF EXISTS public.digital_services_slug_key;
DROP INDEX IF EXISTS public.digital_services_show_on_homepage_display_order_idx;
DROP INDEX IF EXISTS public.digital_services_publication_state_public_visibility_archiv_idx;
DROP INDEX IF EXISTS public.dashboard_reports_show_on_homepage_display_order_idx;
DROP INDEX IF EXISTS public.dashboard_reports_report_key_key;
DROP INDEX IF EXISTS public.dashboard_reports_publication_state_public_visibility_archi_idx;
DROP INDEX IF EXISTS public.dashboard_metrics_unique;
DROP INDEX IF EXISTS public.dashboard_metrics_report_id_financial_year_id_reporting_peri_id;
DROP INDEX IF EXISTS public.dashboard_datasets_report_id_idx;
DROP INDEX IF EXISTS public.communication_types_slug_key;
DROP INDEX IF EXISTS public.communication_types_name_en_key;
DROP INDEX IF EXISTS public.commodities_slug_key;
DROP INDEX IF EXISTS public.commodities_name_en_key;
DROP INDEX IF EXISTS public.blocks_slug_key;
DROP INDEX IF EXISTS public.blocks_district_id_name_en_key;
DROP INDEX IF EXISTS public.blocks_district_id_idx;
DROP INDEX IF EXISTS public.audit_logs_user_id_idx;
DROP INDEX IF EXISTS public.audit_logs_module_record_id_idx;
DROP INDEX IF EXISTS public.audit_logs_created_at_idx;
DROP INDEX IF EXISTS public.audit_logs_action_idx;
ALTER TABLE IF EXISTS ONLY public.videos DROP CONSTRAINT IF EXISTS videos_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS user_roles_pkey;
ALTER TABLE IF EXISTS ONLY public.training_types DROP CONSTRAINT IF EXISTS training_types_pkey;
ALTER TABLE IF EXISTS ONLY public.toolkits DROP CONSTRAINT IF EXISTS toolkits_pkey;
ALTER TABLE IF EXISTS ONLY public.toolkit_items DROP CONSTRAINT IF EXISTS toolkit_items_pkey;
ALTER TABLE IF EXISTS ONLY public.toolkit_distribution_summaries DROP CONSTRAINT IF EXISTS toolkit_distribution_summaries_pkey;
ALTER TABLE IF EXISTS ONLY public.toolkit_distribution_items DROP CONSTRAINT IF EXISTS toolkit_distribution_items_pkey;
ALTER TABLE IF EXISTS ONLY public.tenders DROP CONSTRAINT IF EXISTS tenders_pkey;
ALTER TABLE IF EXISTS ONLY public.tender_types DROP CONSTRAINT IF EXISTS tender_types_pkey;
ALTER TABLE IF EXISTS ONLY public.tags DROP CONSTRAINT IF EXISTS tags_pkey;
ALTER TABLE IF EXISTS ONLY public.settings DROP CONSTRAINT IF EXISTS settings_pkey;
ALTER TABLE IF EXISTS ONLY public.roles DROP CONSTRAINT IF EXISTS roles_pkey;
ALTER TABLE IF EXISTS ONLY public.role_permissions DROP CONSTRAINT IF EXISTS role_permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.reporting_periods DROP CONSTRAINT IF EXISTS reporting_periods_pkey;
ALTER TABLE IF EXISTS ONLY public.programme_schemes DROP CONSTRAINT IF EXISTS programme_schemes_pkey;
ALTER TABLE IF EXISTS ONLY public.programme_permitted_training_types DROP CONSTRAINT IF EXISTS programme_permitted_training_types_pkey;
ALTER TABLE IF EXISTS ONLY public.programme_commodities DROP CONSTRAINT IF EXISTS programme_commodities_pkey;
ALTER TABLE IF EXISTS ONLY public.procurement_updates DROP CONSTRAINT IF EXISTS procurement_updates_pkey;
ALTER TABLE IF EXISTS ONLY public.procurement_update_types DROP CONSTRAINT IF EXISTS procurement_update_types_pkey;
ALTER TABLE IF EXISTS ONLY public.permissions DROP CONSTRAINT IF EXISTS permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.pages DROP CONSTRAINT IF EXISTS pages_pkey;
ALTER TABLE IF EXISTS ONLY public.official_communications DROP CONSTRAINT IF EXISTS official_communications_pkey;
ALTER TABLE IF EXISTS ONLY public.menu_items DROP CONSTRAINT IF EXISTS menu_items_pkey;
ALTER TABLE IF EXISTS ONLY public.media_usages DROP CONSTRAINT IF EXISTS media_usages_pkey;
ALTER TABLE IF EXISTS ONLY public.media_assets DROP CONSTRAINT IF EXISTS media_assets_pkey;
ALTER TABLE IF EXISTS ONLY public.knowledge_categories DROP CONSTRAINT IF EXISTS knowledge_categories_pkey;
ALTER TABLE IF EXISTS ONLY public.institutions DROP CONSTRAINT IF EXISTS institutions_pkey;
ALTER TABLE IF EXISTS ONLY public.institutional_memberships DROP CONSTRAINT IF EXISTS institutional_memberships_pkey;
ALTER TABLE IF EXISTS ONLY public.institution_types DROP CONSTRAINT IF EXISTS institution_types_pkey;
ALTER TABLE IF EXISTS ONLY public.gallery_images DROP CONSTRAINT IF EXISTS gallery_images_pkey;
ALTER TABLE IF EXISTS ONLY public.galleries DROP CONSTRAINT IF EXISTS galleries_pkey;
ALTER TABLE IF EXISTS ONLY public.financial_years DROP CONSTRAINT IF EXISTS financial_years_pkey;
ALTER TABLE IF EXISTS ONLY public.faqs DROP CONSTRAINT IF EXISTS faqs_pkey;
ALTER TABLE IF EXISTS ONLY public.faq_categories DROP CONSTRAINT IF EXISTS faq_categories_pkey;
ALTER TABLE IF EXISTS ONLY public.events DROP CONSTRAINT IF EXISTS events_pkey;
ALTER TABLE IF EXISTS ONLY public.event_types DROP CONSTRAINT IF EXISTS event_types_pkey;
ALTER TABLE IF EXISTS ONLY public.event_programmes DROP CONSTRAINT IF EXISTS event_programmes_pkey;
ALTER TABLE IF EXISTS ONLY public.event_news DROP CONSTRAINT IF EXISTS event_news_pkey;
ALTER TABLE IF EXISTS ONLY public.event_institutions DROP CONSTRAINT IF EXISTS event_institutions_pkey;
ALTER TABLE IF EXISTS ONLY public.event_galleries DROP CONSTRAINT IF EXISTS event_galleries_pkey;
ALTER TABLE IF EXISTS ONLY public.event_field_definitions DROP CONSTRAINT IF EXISTS event_field_definitions_pkey;
ALTER TABLE IF EXISTS ONLY public.event_documents DROP CONSTRAINT IF EXISTS event_documents_pkey;
ALTER TABLE IF EXISTS ONLY public.event_commodities DROP CONSTRAINT IF EXISTS event_commodities_pkey;
ALTER TABLE IF EXISTS ONLY public.enquiry_types DROP CONSTRAINT IF EXISTS enquiry_types_pkey;
ALTER TABLE IF EXISTS ONLY public.enquiries DROP CONSTRAINT IF EXISTS enquiries_pkey;
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS documents_pkey;
ALTER TABLE IF EXISTS ONLY public.document_types DROP CONSTRAINT IF EXISTS document_types_pkey;
ALTER TABLE IF EXISTS ONLY public.document_tags DROP CONSTRAINT IF EXISTS document_tags_pkey;
ALTER TABLE IF EXISTS ONLY public.document_programmes DROP CONSTRAINT IF EXISTS document_programmes_pkey;
ALTER TABLE IF EXISTS ONLY public.document_institutions DROP CONSTRAINT IF EXISTS document_institutions_pkey;
ALTER TABLE IF EXISTS ONLY public.document_districts DROP CONSTRAINT IF EXISTS document_districts_pkey;
ALTER TABLE IF EXISTS ONLY public.document_commodities DROP CONSTRAINT IF EXISTS document_commodities_pkey;
ALTER TABLE IF EXISTS ONLY public.districts DROP CONSTRAINT IF EXISTS districts_pkey;
ALTER TABLE IF EXISTS ONLY public.digital_services DROP CONSTRAINT IF EXISTS digital_services_pkey;
ALTER TABLE IF EXISTS ONLY public.dashboard_reports DROP CONSTRAINT IF EXISTS dashboard_reports_pkey;
ALTER TABLE IF EXISTS ONLY public.dashboard_metrics DROP CONSTRAINT IF EXISTS dashboard_metrics_pkey;
ALTER TABLE IF EXISTS ONLY public.dashboard_datasets DROP CONSTRAINT IF EXISTS dashboard_datasets_pkey;
ALTER TABLE IF EXISTS ONLY public.communication_types DROP CONSTRAINT IF EXISTS communication_types_pkey;
ALTER TABLE IF EXISTS ONLY public.commodities DROP CONSTRAINT IF EXISTS commodities_pkey;
ALTER TABLE IF EXISTS ONLY public.blocks DROP CONSTRAINT IF EXISTS blocks_pkey;
ALTER TABLE IF EXISTS ONLY public.audit_logs DROP CONSTRAINT IF EXISTS audit_logs_pkey;
ALTER TABLE IF EXISTS ONLY public._prisma_migrations DROP CONSTRAINT IF EXISTS _prisma_migrations_pkey;
DROP TABLE IF EXISTS public.videos;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.user_roles;
DROP TABLE IF EXISTS public.training_types;
DROP TABLE IF EXISTS public.toolkits;
DROP TABLE IF EXISTS public.toolkit_items;
DROP TABLE IF EXISTS public.toolkit_distribution_summaries;
DROP TABLE IF EXISTS public.toolkit_distribution_items;
DROP TABLE IF EXISTS public.tenders;
DROP TABLE IF EXISTS public.tender_types;
DROP TABLE IF EXISTS public.tags;
DROP TABLE IF EXISTS public.settings;
DROP TABLE IF EXISTS public.roles;
DROP TABLE IF EXISTS public.role_permissions;
DROP TABLE IF EXISTS public.reporting_periods;
DROP TABLE IF EXISTS public.programme_schemes;
DROP TABLE IF EXISTS public.programme_permitted_training_types;
DROP TABLE IF EXISTS public.programme_commodities;
DROP TABLE IF EXISTS public.procurement_updates;
DROP TABLE IF EXISTS public.procurement_update_types;
DROP TABLE IF EXISTS public.permissions;
DROP TABLE IF EXISTS public.pages;
DROP TABLE IF EXISTS public.official_communications;
DROP TABLE IF EXISTS public.menu_items;
DROP TABLE IF EXISTS public.media_usages;
DROP TABLE IF EXISTS public.media_assets;
DROP TABLE IF EXISTS public.knowledge_categories;
DROP TABLE IF EXISTS public.institutions;
DROP TABLE IF EXISTS public.institutional_memberships;
DROP TABLE IF EXISTS public.institution_types;
DROP TABLE IF EXISTS public.gallery_images;
DROP TABLE IF EXISTS public.galleries;
DROP TABLE IF EXISTS public.financial_years;
DROP TABLE IF EXISTS public.faqs;
DROP TABLE IF EXISTS public.faq_categories;
DROP TABLE IF EXISTS public.events;
DROP TABLE IF EXISTS public.event_types;
DROP TABLE IF EXISTS public.event_programmes;
DROP TABLE IF EXISTS public.event_news;
DROP TABLE IF EXISTS public.event_institutions;
DROP TABLE IF EXISTS public.event_galleries;
DROP TABLE IF EXISTS public.event_field_definitions;
DROP TABLE IF EXISTS public.event_documents;
DROP TABLE IF EXISTS public.event_commodities;
DROP TABLE IF EXISTS public.enquiry_types;
DROP TABLE IF EXISTS public.enquiries;
DROP TABLE IF EXISTS public.documents;
DROP TABLE IF EXISTS public.document_types;
DROP TABLE IF EXISTS public.document_tags;
DROP TABLE IF EXISTS public.document_programmes;
DROP TABLE IF EXISTS public.document_institutions;
DROP TABLE IF EXISTS public.document_districts;
DROP TABLE IF EXISTS public.document_commodities;
DROP TABLE IF EXISTS public.districts;
DROP TABLE IF EXISTS public.digital_services;
DROP TABLE IF EXISTS public.dashboard_reports;
DROP TABLE IF EXISTS public.dashboard_metrics;
DROP TABLE IF EXISTS public.dashboard_datasets;
DROP TABLE IF EXISTS public.communication_types;
DROP TABLE IF EXISTS public.commodities;
DROP TABLE IF EXISTS public.blocks;
DROP TABLE IF EXISTS public.audit_logs;
DROP TABLE IF EXISTS public._prisma_migrations;
DROP TYPE IF EXISTS public."TranslationSource";
DROP TYPE IF EXISTS public."SpamState";
DROP TYPE IF EXISTS public."ReportingPeriodType";
DROP TYPE IF EXISTS public."PublicationState";
DROP TYPE IF EXISTS public."MembershipType";
DROP TYPE IF EXISTS public."MembershipStatus";
DROP TYPE IF EXISTS public."MembershipLevel";
DROP TYPE IF EXISTS public."Language";
DROP TYPE IF EXISTS public."HighlightType";
DROP TYPE IF EXISTS public."FieldDataType";
DROP TYPE IF EXISTS public."EventStatus";
DROP TYPE IF EXISTS public."DistributionModel";
DROP TYPE IF EXISTS public."DistributionBasis";
DROP TYPE IF EXISTS public."DateMode";
DROP TYPE IF EXISTS public."DatasetSource";
DROP TYPE IF EXISTS public."AuditAction";
DROP EXTENSION IF EXISTS citext;
--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: AuditAction; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AuditAction" AS ENUM (
    'create',
    'update',
    'publish',
    'unpublish',
    'archive',
    'restore',
    'media_replace',
    'config_change',
    'master_change',
    'login'
);


--
-- Name: DatasetSource; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."DatasetSource" AS ENUM (
    'cms_derived',
    'manual',
    'excel'
);


--
-- Name: DateMode; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."DateMode" AS ENUM (
    'single',
    'range',
    'multi_day'
);


--
-- Name: DistributionBasis; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."DistributionBasis" AS ENUM (
    'individual',
    'group'
);


--
-- Name: DistributionModel; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."DistributionModel" AS ENUM (
    'individual',
    'group',
    'mixed'
);


--
-- Name: EventStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."EventStatus" AS ENUM (
    'scheduled',
    'ongoing',
    'completed',
    'postponed',
    'cancelled'
);


--
-- Name: FieldDataType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."FieldDataType" AS ENUM (
    'text',
    'textarea',
    'number',
    'date',
    'boolean',
    'select'
);


--
-- Name: HighlightType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."HighlightType" AS ENUM (
    'new',
    'latest',
    'important',
    'urgent',
    'featured'
);


--
-- Name: Language; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."Language" AS ENUM (
    'en',
    'hi'
);


--
-- Name: MembershipLevel; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."MembershipLevel" AS ENUM (
    'sidhkofed',
    'district_union'
);


--
-- Name: MembershipStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."MembershipStatus" AS ENUM (
    'active',
    'inactive'
);


--
-- Name: MembershipType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."MembershipType" AS ENUM (
    'primary',
    'nominal'
);


--
-- Name: PublicationState; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PublicationState" AS ENUM (
    'draft',
    'published',
    'unpublished',
    'archived'
);


--
-- Name: ReportingPeriodType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ReportingPeriodType" AS ENUM (
    'month',
    'financial_year',
    'calendar_year',
    'cumulative'
);


--
-- Name: SpamState; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SpamState" AS ENUM (
    'clean',
    'suspected',
    'spam'
);


--
-- Name: TranslationSource; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."TranslationSource" AS ENUM (
    'manual',
    'automatic',
    'missing'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id uuid NOT NULL,
    user_id uuid,
    action public."AuditAction" NOT NULL,
    module text NOT NULL,
    record_id uuid,
    previous_state text,
    new_state text,
    change_summary text,
    metadata jsonb,
    ip_hash text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: blocks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.blocks (
    id uuid NOT NULL,
    district_id uuid NOT NULL,
    name_en text NOT NULL,
    name_hi text,
    slug text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    display_order integer,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: commodities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commodities (
    id uuid NOT NULL,
    name_en text NOT NULL,
    name_hi text,
    slug text NOT NULL,
    description_en text,
    description_hi text,
    icon_media_id uuid,
    is_active boolean DEFAULT true NOT NULL,
    display_order integer,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: communication_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.communication_types (
    id uuid NOT NULL,
    name_en text NOT NULL,
    name_hi text,
    slug text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    display_order integer,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: dashboard_datasets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dashboard_datasets (
    id uuid NOT NULL,
    report_id uuid NOT NULL,
    source public."DatasetSource" NOT NULL,
    financial_year_id uuid,
    reporting_period_id uuid,
    source_file_asset_id uuid,
    raw_rows jsonb,
    row_count integer DEFAULT 0 NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    processed_at timestamp(3) without time zone,
    created_by uuid,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: dashboard_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dashboard_metrics (
    id uuid NOT NULL,
    report_id uuid NOT NULL,
    metric_key text NOT NULL,
    label_en text NOT NULL,
    label_hi text,
    value numeric(18,4),
    value_text text,
    unit text,
    financial_year_id uuid,
    reporting_period_id uuid,
    source public."DatasetSource" DEFAULT 'manual'::public."DatasetSource" NOT NULL,
    dataset_id uuid,
    display_order integer DEFAULT 0 NOT NULL,
    created_by uuid,
    updated_by uuid,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: dashboard_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dashboard_reports (
    id uuid NOT NULL,
    report_key text NOT NULL,
    title_en text NOT NULL,
    title_hi text,
    description_en text,
    description_hi text,
    layout_config jsonb,
    publication_state public."PublicationState" DEFAULT 'draft'::public."PublicationState" NOT NULL,
    public_visibility boolean DEFAULT true NOT NULL,
    publish_start_at timestamp(3) without time zone,
    published_at timestamp(3) without time zone,
    archived_at timestamp(3) without time zone,
    highlight_type public."HighlightType",
    highlight_start_at timestamp(3) without time zone,
    highlight_end_at timestamp(3) without time zone,
    display_order integer,
    show_on_homepage boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_by uuid,
    updated_by uuid,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: digital_services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.digital_services (
    id uuid NOT NULL,
    title_en text NOT NULL,
    title_hi text,
    description_en text,
    description_hi text,
    external_url text NOT NULL,
    icon_media_id uuid,
    slug text NOT NULL,
    publication_state public."PublicationState" DEFAULT 'draft'::public."PublicationState" NOT NULL,
    public_visibility boolean DEFAULT true NOT NULL,
    publish_start_at timestamp(3) without time zone,
    published_at timestamp(3) without time zone,
    archived_at timestamp(3) without time zone,
    highlight_type public."HighlightType",
    highlight_start_at timestamp(3) without time zone,
    highlight_end_at timestamp(3) without time zone,
    display_order integer,
    show_on_homepage boolean DEFAULT false NOT NULL,
    created_by uuid,
    updated_by uuid,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: districts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.districts (
    id uuid NOT NULL,
    name_en text NOT NULL,
    name_hi text,
    slug text NOT NULL,
    state text DEFAULT 'Jharkhand'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    display_order integer,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: document_commodities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_commodities (
    id uuid NOT NULL,
    document_id uuid NOT NULL,
    commodity_id uuid NOT NULL
);


--
-- Name: document_districts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_districts (
    id uuid NOT NULL,
    document_id uuid NOT NULL,
    district_id uuid NOT NULL
);


--
-- Name: document_institutions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_institutions (
    id uuid NOT NULL,
    document_id uuid NOT NULL,
    institution_id uuid NOT NULL
);


--
-- Name: document_programmes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_programmes (
    id uuid NOT NULL,
    document_id uuid NOT NULL,
    programme_scheme_id uuid NOT NULL
);


--
-- Name: document_tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_tags (
    id uuid NOT NULL,
    document_id uuid NOT NULL,
    tag_id uuid NOT NULL
);


--
-- Name: document_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_types (
    id uuid NOT NULL,
    name_en text NOT NULL,
    name_hi text,
    slug text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    display_order integer,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.documents (
    id uuid NOT NULL,
    title_en text NOT NULL,
    title_hi text,
    description_en text,
    description_hi text,
    document_type_id uuid NOT NULL,
    file_asset_id uuid NOT NULL,
    publication_date date,
    language public."Language" DEFAULT 'en'::public."Language" NOT NULL,
    is_public boolean DEFAULT true NOT NULL,
    show_in_knowledge_centre boolean DEFAULT false NOT NULL,
    knowledge_category_id uuid,
    financial_year_id uuid,
    slug text NOT NULL,
    publication_state public."PublicationState" DEFAULT 'draft'::public."PublicationState" NOT NULL,
    public_visibility boolean DEFAULT true NOT NULL,
    publish_start_at timestamp(3) without time zone,
    published_at timestamp(3) without time zone,
    archived_at timestamp(3) without time zone,
    highlight_type public."HighlightType",
    highlight_start_at timestamp(3) without time zone,
    highlight_end_at timestamp(3) without time zone,
    display_order integer,
    show_on_homepage boolean DEFAULT false NOT NULL,
    created_by uuid,
    updated_by uuid,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    search_vector tsvector GENERATED ALWAYS AS (to_tsvector('simple'::regconfig, ((((((COALESCE(title_en, ''::text) || ' '::text) || COALESCE(title_hi, ''::text)) || ' '::text) || COALESCE(description_en, ''::text)) || ' '::text) || COALESCE(description_hi, ''::text)))) STORED
);


--
-- Name: enquiries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.enquiries (
    id uuid NOT NULL,
    enquiry_type_id uuid NOT NULL,
    name character varying(150) NOT NULL,
    mobile character varying(20) NOT NULL,
    email character varying(255) NOT NULL,
    subject character varying(255) NOT NULL,
    message text NOT NULL,
    organization character varying(255),
    commodity_id uuid,
    programme_scheme_id uuid,
    submitted_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    source_ip_hash character varying(128),
    spam_state public."SpamState" DEFAULT 'clean'::public."SpamState" NOT NULL,
    internal_notes text,
    archived_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: enquiry_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.enquiry_types (
    id uuid NOT NULL,
    name_en text NOT NULL,
    name_hi text,
    slug text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    display_order integer,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: event_commodities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_commodities (
    id uuid NOT NULL,
    event_id uuid NOT NULL,
    commodity_id uuid NOT NULL
);


--
-- Name: event_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_documents (
    id uuid NOT NULL,
    event_id uuid NOT NULL,
    document_id uuid NOT NULL
);


--
-- Name: event_field_definitions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_field_definitions (
    id uuid NOT NULL,
    event_type_id uuid NOT NULL,
    field_key text NOT NULL,
    label_en text NOT NULL,
    label_hi text,
    data_type public."FieldDataType" NOT NULL,
    is_required boolean DEFAULT false NOT NULL,
    options jsonb,
    display_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: event_galleries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_galleries (
    id uuid NOT NULL,
    event_id uuid NOT NULL,
    gallery_id uuid NOT NULL
);


--
-- Name: event_institutions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_institutions (
    id uuid NOT NULL,
    event_id uuid NOT NULL,
    institution_id uuid NOT NULL
);


--
-- Name: event_news; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_news (
    id uuid NOT NULL,
    event_id uuid NOT NULL,
    title_en text NOT NULL,
    title_hi text,
    summary_en text,
    summary_hi text,
    body_en text,
    body_hi text,
    cover_media_id uuid,
    news_published_at timestamp(3) without time zone,
    slug text NOT NULL,
    publication_state public."PublicationState" DEFAULT 'draft'::public."PublicationState" NOT NULL,
    public_visibility boolean DEFAULT true NOT NULL,
    publish_start_at timestamp(3) without time zone,
    published_at timestamp(3) without time zone,
    archived_at timestamp(3) without time zone,
    highlight_type public."HighlightType",
    highlight_start_at timestamp(3) without time zone,
    highlight_end_at timestamp(3) without time zone,
    display_order integer,
    show_on_homepage boolean DEFAULT false NOT NULL,
    created_by uuid,
    updated_by uuid,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    search_vector tsvector GENERATED ALWAYS AS (to_tsvector('simple'::regconfig, ((((((((((COALESCE(title_en, ''::text) || ' '::text) || COALESCE(title_hi, ''::text)) || ' '::text) || COALESCE(summary_en, ''::text)) || ' '::text) || COALESCE(summary_hi, ''::text)) || ' '::text) || COALESCE(body_en, ''::text)) || ' '::text) || COALESCE(body_hi, ''::text)))) STORED
);


--
-- Name: event_programmes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_programmes (
    id uuid NOT NULL,
    event_id uuid NOT NULL,
    programme_scheme_id uuid NOT NULL
);


--
-- Name: event_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_types (
    id uuid NOT NULL,
    name_en text NOT NULL,
    name_hi text,
    slug text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    display_order integer,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.events (
    id uuid NOT NULL,
    event_type_id uuid NOT NULL,
    training_type_id uuid,
    title_en text NOT NULL,
    title_hi text,
    summary_en text,
    summary_hi text,
    description_en text,
    description_hi text,
    date_mode public."DateMode" DEFAULT 'single'::public."DateMode" NOT NULL,
    start_date date NOT NULL,
    end_date date,
    location_text text,
    district_id uuid,
    block_id uuid,
    cover_media_id uuid,
    event_status public."EventStatus" DEFAULT 'scheduled'::public."EventStatus" NOT NULL,
    status_override boolean DEFAULT false NOT NULL,
    cancellation_reason text,
    revised_start_date date,
    dynamic_values jsonb,
    outcome_summary_en text,
    outcome_summary_hi text,
    key_highlights text,
    final_participant_count integer,
    participant_male_count integer,
    participant_female_count integer,
    participant_other_count integer,
    completion_remarks_en text,
    completion_remarks_hi text,
    completed_date date,
    translation_source public."TranslationSource" DEFAULT 'manual'::public."TranslationSource" NOT NULL,
    slug text NOT NULL,
    publication_state public."PublicationState" DEFAULT 'draft'::public."PublicationState" NOT NULL,
    public_visibility boolean DEFAULT true NOT NULL,
    publish_start_at timestamp(3) without time zone,
    published_at timestamp(3) without time zone,
    archived_at timestamp(3) without time zone,
    highlight_type public."HighlightType",
    highlight_start_at timestamp(3) without time zone,
    highlight_end_at timestamp(3) without time zone,
    display_order integer,
    show_on_homepage boolean DEFAULT false NOT NULL,
    created_by uuid,
    updated_by uuid,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    search_vector tsvector GENERATED ALWAYS AS (to_tsvector('simple'::regconfig, ((((((((((COALESCE(title_en, ''::text) || ' '::text) || COALESCE(title_hi, ''::text)) || ' '::text) || COALESCE(summary_en, ''::text)) || ' '::text) || COALESCE(summary_hi, ''::text)) || ' '::text) || COALESCE(description_en, ''::text)) || ' '::text) || COALESCE(description_hi, ''::text)))) STORED
);


--
-- Name: faq_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.faq_categories (
    id uuid NOT NULL,
    name_en text NOT NULL,
    name_hi text,
    slug text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    display_order integer,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: faqs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.faqs (
    id uuid NOT NULL,
    faq_category_id uuid,
    question_en text NOT NULL,
    question_hi text,
    answer_en text NOT NULL,
    answer_hi text,
    slug text NOT NULL,
    publication_state public."PublicationState" DEFAULT 'draft'::public."PublicationState" NOT NULL,
    public_visibility boolean DEFAULT true NOT NULL,
    publish_start_at timestamp(3) without time zone,
    published_at timestamp(3) without time zone,
    archived_at timestamp(3) without time zone,
    highlight_type public."HighlightType",
    highlight_start_at timestamp(3) without time zone,
    highlight_end_at timestamp(3) without time zone,
    display_order integer,
    show_on_homepage boolean DEFAULT false NOT NULL,
    created_by uuid,
    updated_by uuid,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: financial_years; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.financial_years (
    id uuid NOT NULL,
    label text NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: galleries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.galleries (
    id uuid NOT NULL,
    title_en text NOT NULL,
    title_hi text,
    description_en text,
    description_hi text,
    cover_media_id uuid,
    slug text NOT NULL,
    publication_state public."PublicationState" DEFAULT 'draft'::public."PublicationState" NOT NULL,
    public_visibility boolean DEFAULT true NOT NULL,
    publish_start_at timestamp(3) without time zone,
    published_at timestamp(3) without time zone,
    archived_at timestamp(3) without time zone,
    highlight_type public."HighlightType",
    highlight_start_at timestamp(3) without time zone,
    highlight_end_at timestamp(3) without time zone,
    display_order integer,
    show_on_homepage boolean DEFAULT false NOT NULL,
    created_by uuid,
    updated_by uuid,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: gallery_images; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gallery_images (
    id uuid NOT NULL,
    gallery_id uuid NOT NULL,
    media_id uuid NOT NULL,
    display_order integer DEFAULT 0 NOT NULL,
    caption_en text,
    caption_hi text
);


--
-- Name: institution_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.institution_types (
    id uuid NOT NULL,
    name_en text NOT NULL,
    name_hi text,
    slug text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    display_order integer,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: institutional_memberships; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.institutional_memberships (
    id uuid NOT NULL,
    institution_id uuid NOT NULL,
    membership_level public."MembershipLevel" NOT NULL,
    membership_type public."MembershipType" NOT NULL,
    membership_number text,
    district_id uuid,
    district_union_id uuid,
    reporting_period_id uuid,
    status public."MembershipStatus" DEFAULT 'active'::public."MembershipStatus" NOT NULL,
    join_date date,
    notes_en text,
    notes_hi text,
    slug text NOT NULL,
    publication_state public."PublicationState" DEFAULT 'draft'::public."PublicationState" NOT NULL,
    public_visibility boolean DEFAULT true NOT NULL,
    publish_start_at timestamp(3) without time zone,
    published_at timestamp(3) without time zone,
    archived_at timestamp(3) without time zone,
    highlight_type public."HighlightType",
    highlight_start_at timestamp(3) without time zone,
    highlight_end_at timestamp(3) without time zone,
    display_order integer,
    show_on_homepage boolean DEFAULT false NOT NULL,
    created_by uuid,
    updated_by uuid,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: institutions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.institutions (
    id uuid NOT NULL,
    institution_type_id uuid NOT NULL,
    name_en text NOT NULL,
    name_hi text,
    description_en text,
    description_hi text,
    address_en text,
    address_hi text,
    website_url text,
    logo_media_id uuid,
    district_id uuid,
    contact_email text,
    contact_phone text,
    slug text NOT NULL,
    publication_state public."PublicationState" DEFAULT 'draft'::public."PublicationState" NOT NULL,
    public_visibility boolean DEFAULT true NOT NULL,
    publish_start_at timestamp(3) without time zone,
    published_at timestamp(3) without time zone,
    archived_at timestamp(3) without time zone,
    highlight_type public."HighlightType",
    highlight_start_at timestamp(3) without time zone,
    highlight_end_at timestamp(3) without time zone,
    display_order integer,
    show_on_homepage boolean DEFAULT false NOT NULL,
    created_by uuid,
    updated_by uuid,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: knowledge_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_categories (
    id uuid NOT NULL,
    name_en text NOT NULL,
    name_hi text,
    slug text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    display_order integer,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: media_assets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.media_assets (
    id uuid NOT NULL,
    storage_key text NOT NULL,
    url text NOT NULL,
    file_name text NOT NULL,
    mime_type text NOT NULL,
    file_size_bytes bigint NOT NULL,
    width integer,
    height integer,
    title text,
    alt_text text,
    caption text,
    checksum text,
    replaced_by_id uuid,
    archived_at timestamp(3) without time zone,
    uploaded_by uuid,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: media_usages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.media_usages (
    id uuid NOT NULL,
    media_id uuid NOT NULL,
    entity_type text NOT NULL,
    entity_id uuid NOT NULL,
    field text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: menu_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.menu_items (
    id uuid NOT NULL,
    label_en text NOT NULL,
    label_hi text,
    location text NOT NULL,
    url text,
    page_id uuid,
    parent_id uuid,
    opens_new_tab boolean DEFAULT false NOT NULL,
    display_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_by uuid,
    updated_by uuid,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: official_communications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.official_communications (
    id uuid NOT NULL,
    title_en text NOT NULL,
    title_hi text,
    summary_en text,
    summary_hi text,
    body_en text,
    body_hi text,
    communication_type_id uuid NOT NULL,
    reference_number text,
    issue_date date,
    effective_date date,
    expiry_date date,
    issuing_authority text,
    document_id uuid,
    slug text NOT NULL,
    publication_state public."PublicationState" DEFAULT 'draft'::public."PublicationState" NOT NULL,
    public_visibility boolean DEFAULT true NOT NULL,
    publish_start_at timestamp(3) without time zone,
    published_at timestamp(3) without time zone,
    archived_at timestamp(3) without time zone,
    highlight_type public."HighlightType",
    highlight_start_at timestamp(3) without time zone,
    highlight_end_at timestamp(3) without time zone,
    display_order integer,
    show_on_homepage boolean DEFAULT false NOT NULL,
    created_by uuid,
    updated_by uuid,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    search_vector tsvector GENERATED ALWAYS AS (to_tsvector('simple'::regconfig, ((((((((((COALESCE(title_en, ''::text) || ' '::text) || COALESCE(title_hi, ''::text)) || ' '::text) || COALESCE(summary_en, ''::text)) || ' '::text) || COALESCE(summary_hi, ''::text)) || ' '::text) || COALESCE(body_en, ''::text)) || ' '::text) || COALESCE(body_hi, ''::text)))) STORED
);


--
-- Name: pages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pages (
    id uuid NOT NULL,
    title_en text NOT NULL,
    title_hi text,
    body_en text,
    body_hi text,
    meta_title_en text,
    meta_title_hi text,
    meta_description_en text,
    meta_description_hi text,
    slug text NOT NULL,
    publication_state public."PublicationState" DEFAULT 'draft'::public."PublicationState" NOT NULL,
    public_visibility boolean DEFAULT true NOT NULL,
    publish_start_at timestamp(3) without time zone,
    published_at timestamp(3) without time zone,
    archived_at timestamp(3) without time zone,
    highlight_type public."HighlightType",
    highlight_start_at timestamp(3) without time zone,
    highlight_end_at timestamp(3) without time zone,
    display_order integer,
    show_on_homepage boolean DEFAULT false NOT NULL,
    created_by uuid,
    updated_by uuid,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    search_vector tsvector GENERATED ALWAYS AS (to_tsvector('simple'::regconfig, ((((((((((((((COALESCE(title_en, ''::text) || ' '::text) || COALESCE(title_hi, ''::text)) || ' '::text) || COALESCE(body_en, ''::text)) || ' '::text) || COALESCE(body_hi, ''::text)) || ' '::text) || COALESCE(meta_title_en, ''::text)) || ' '::text) || COALESCE(meta_title_hi, ''::text)) || ' '::text) || COALESCE(meta_description_en, ''::text)) || ' '::text) || COALESCE(meta_description_hi, ''::text)))) STORED
);


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permissions (
    id uuid NOT NULL,
    key text NOT NULL,
    module text NOT NULL,
    action text NOT NULL,
    description text
);


--
-- Name: procurement_update_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.procurement_update_types (
    id uuid NOT NULL,
    name_en text NOT NULL,
    name_hi text,
    slug text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    display_order integer,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: procurement_updates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.procurement_updates (
    id uuid NOT NULL,
    title_en text NOT NULL,
    title_hi text,
    summary_en text,
    summary_hi text,
    description_en text,
    description_hi text,
    procurement_update_type_id uuid NOT NULL,
    commodity_id uuid,
    rate numeric(14,2),
    unit text,
    effective_date date,
    period_start date,
    period_end date,
    district_id uuid,
    block_id uuid,
    location_text text,
    programme_scheme_id uuid,
    document_id uuid,
    status text,
    slug text NOT NULL,
    publication_state public."PublicationState" DEFAULT 'draft'::public."PublicationState" NOT NULL,
    public_visibility boolean DEFAULT true NOT NULL,
    publish_start_at timestamp(3) without time zone,
    published_at timestamp(3) without time zone,
    archived_at timestamp(3) without time zone,
    highlight_type public."HighlightType",
    highlight_start_at timestamp(3) without time zone,
    highlight_end_at timestamp(3) without time zone,
    display_order integer,
    show_on_homepage boolean DEFAULT false NOT NULL,
    created_by uuid,
    updated_by uuid,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    search_vector tsvector GENERATED ALWAYS AS (to_tsvector('simple'::regconfig, ((((((((((COALESCE(title_en, ''::text) || ' '::text) || COALESCE(title_hi, ''::text)) || ' '::text) || COALESCE(summary_en, ''::text)) || ' '::text) || COALESCE(summary_hi, ''::text)) || ' '::text) || COALESCE(description_en, ''::text)) || ' '::text) || COALESCE(description_hi, ''::text)))) STORED
);


--
-- Name: programme_commodities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programme_commodities (
    id uuid NOT NULL,
    programme_scheme_id uuid NOT NULL,
    commodity_id uuid NOT NULL
);


--
-- Name: programme_permitted_training_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programme_permitted_training_types (
    id uuid NOT NULL,
    programme_scheme_id uuid NOT NULL,
    training_type_id uuid NOT NULL
);


--
-- Name: programme_schemes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.programme_schemes (
    id uuid NOT NULL,
    title_en text NOT NULL,
    title_hi text,
    short_code text,
    summary_en text,
    summary_hi text,
    description_en text,
    description_hi text,
    objectives_en text,
    objectives_hi text,
    eligibility_en text,
    eligibility_hi text,
    benefits_en text,
    benefits_hi text,
    application_process_en text,
    application_process_hi text,
    funding_source text,
    start_date date,
    end_date date,
    cover_media_id uuid,
    slug text NOT NULL,
    publication_state public."PublicationState" DEFAULT 'draft'::public."PublicationState" NOT NULL,
    public_visibility boolean DEFAULT true NOT NULL,
    publish_start_at timestamp(3) without time zone,
    published_at timestamp(3) without time zone,
    archived_at timestamp(3) without time zone,
    highlight_type public."HighlightType",
    highlight_start_at timestamp(3) without time zone,
    highlight_end_at timestamp(3) without time zone,
    display_order integer,
    show_on_homepage boolean DEFAULT false NOT NULL,
    created_by uuid,
    updated_by uuid,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    search_vector tsvector GENERATED ALWAYS AS (to_tsvector('simple'::regconfig, ((((((((((((COALESCE(title_en, ''::text) || ' '::text) || COALESCE(title_hi, ''::text)) || ' '::text) || COALESCE(short_code, ''::text)) || ' '::text) || COALESCE(summary_en, ''::text)) || ' '::text) || COALESCE(summary_hi, ''::text)) || ' '::text) || COALESCE(description_en, ''::text)) || ' '::text) || COALESCE(description_hi, ''::text)))) STORED
);


--
-- Name: reporting_periods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reporting_periods (
    id uuid NOT NULL,
    financial_year_id uuid,
    name_en text NOT NULL,
    name_hi text,
    slug text NOT NULL,
    period_type public."ReportingPeriodType" NOT NULL,
    calendar_year integer,
    start_date date NOT NULL,
    end_date date NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_permissions (
    id uuid NOT NULL,
    role_id uuid NOT NULL,
    permission_id uuid NOT NULL
);


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id uuid NOT NULL,
    key text NOT NULL,
    name_en text NOT NULL,
    description text,
    is_system boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.settings (
    id uuid NOT NULL,
    key text NOT NULL,
    value_text text,
    value_json jsonb,
    description text,
    updated_by uuid,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tags (
    id uuid NOT NULL,
    name_en text NOT NULL,
    name_hi text,
    slug text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: tender_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tender_types (
    id uuid NOT NULL,
    name_en text NOT NULL,
    name_hi text,
    slug text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    display_order integer,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: tenders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenders (
    id uuid NOT NULL,
    title_en text NOT NULL,
    title_hi text,
    summary_en text,
    summary_hi text,
    tender_type_id uuid NOT NULL,
    tender_number public.citext,
    publish_date date,
    submission_deadline timestamp(3) without time zone,
    opening_date timestamp(3) without time zone,
    tender_status text,
    gem_url text,
    slug text NOT NULL,
    publication_state public."PublicationState" DEFAULT 'draft'::public."PublicationState" NOT NULL,
    public_visibility boolean DEFAULT true NOT NULL,
    publish_start_at timestamp(3) without time zone,
    published_at timestamp(3) without time zone,
    archived_at timestamp(3) without time zone,
    highlight_type public."HighlightType",
    highlight_start_at timestamp(3) without time zone,
    highlight_end_at timestamp(3) without time zone,
    display_order integer,
    show_on_homepage boolean DEFAULT false NOT NULL,
    created_by uuid,
    updated_by uuid,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    search_vector tsvector GENERATED ALWAYS AS (to_tsvector('simple'::regconfig, ((((((((COALESCE(title_en, ''::text) || ' '::text) || COALESCE(title_hi, ''::text)) || ' '::text) || COALESCE(summary_en, ''::text)) || ' '::text) || COALESCE(summary_hi, ''::text)) || ' '::text) || COALESCE((tender_number)::text, ''::text)))) STORED
);


--
-- Name: toolkit_distribution_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.toolkit_distribution_items (
    id uuid NOT NULL,
    toolkit_distribution_summary_id uuid CONSTRAINT toolkit_distribution_items_toolkit_distribution_summar_not_null NOT NULL,
    toolkit_item_id uuid NOT NULL,
    distribution_basis public."DistributionBasis" NOT NULL,
    quantity_per_unit numeric(14,2),
    number_of_units_or_groups integer,
    total_quantity numeric(14,2),
    manual_override boolean DEFAULT false NOT NULL
);


--
-- Name: toolkit_distribution_summaries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.toolkit_distribution_summaries (
    id uuid NOT NULL,
    event_id uuid NOT NULL,
    toolkit_id uuid NOT NULL,
    distribution_done boolean DEFAULT false NOT NULL,
    distribution_model public."DistributionModel" NOT NULL,
    participants_covered integer,
    distribution_date date,
    remarks_en text,
    remarks_hi text,
    created_by uuid,
    updated_by uuid,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: toolkit_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.toolkit_items (
    id uuid NOT NULL,
    toolkit_id uuid NOT NULL,
    name_en text NOT NULL,
    name_hi text,
    description_en text,
    description_hi text,
    unit text,
    distribution_basis public."DistributionBasis" DEFAULT 'individual'::public."DistributionBasis" NOT NULL,
    default_quantity_per_unit numeric(14,2),
    default_group_size integer,
    quantity_summary numeric(14,2),
    is_active boolean DEFAULT true NOT NULL,
    display_order integer DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: toolkits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.toolkits (
    id uuid NOT NULL,
    title_en text NOT NULL,
    title_hi text,
    summary_en text,
    summary_hi text,
    description_en text,
    description_hi text,
    programme_scheme_id uuid,
    commodity_id uuid,
    cover_media_id uuid,
    slug text NOT NULL,
    publication_state public."PublicationState" DEFAULT 'draft'::public."PublicationState" NOT NULL,
    public_visibility boolean DEFAULT true NOT NULL,
    publish_start_at timestamp(3) without time zone,
    published_at timestamp(3) without time zone,
    archived_at timestamp(3) without time zone,
    highlight_type public."HighlightType",
    highlight_start_at timestamp(3) without time zone,
    highlight_end_at timestamp(3) without time zone,
    display_order integer,
    show_on_homepage boolean DEFAULT false NOT NULL,
    created_by uuid,
    updated_by uuid,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: training_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.training_types (
    id uuid NOT NULL,
    name_en text NOT NULL,
    name_hi text,
    slug text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    display_order integer,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    role_id uuid NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    full_name text NOT NULL,
    preferred_language public."Language" DEFAULT 'en'::public."Language" NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    last_login_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: videos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.videos (
    id uuid NOT NULL,
    title_en text NOT NULL,
    title_hi text,
    description_en text,
    description_hi text,
    youtube_id text NOT NULL,
    youtube_url text NOT NULL,
    thumbnail_media_id uuid,
    slug text NOT NULL,
    publication_state public."PublicationState" DEFAULT 'draft'::public."PublicationState" NOT NULL,
    public_visibility boolean DEFAULT true NOT NULL,
    publish_start_at timestamp(3) without time zone,
    published_at timestamp(3) without time zone,
    archived_at timestamp(3) without time zone,
    highlight_type public."HighlightType",
    highlight_start_at timestamp(3) without time zone,
    highlight_end_at timestamp(3) without time zone,
    display_order integer,
    show_on_homepage boolean DEFAULT false NOT NULL,
    created_by uuid,
    updated_by uuid,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
da618ce6-8dd3-475c-8e79-726f622f66c6	72d560c4757c7f2d856b769f152ae6c309b2d7235aecc899c1ecbd9f6d029673	2026-06-27 18:24:23.142035+05:30	20260624120000_init_identity_governance	\N	\N	2026-06-27 18:24:23.10477+05:30	1
2586b633-82c4-4bc6-ad7c-f9ed6c2b2953	733d2eae5a30627ae0d6b5bd66ca642532611d763049fd952cea83db4182525a	2026-06-27 18:24:23.65464+05:30	20260626140000_tender_number_citext	\N	\N	2026-06-27 18:24:23.561965+05:30	1
8b090711-4c14-4f40-b16c-25e4dcb0b2ff	da4110ab4000ae2146e7b4b6ecbb5ced6c7ba01f115d673aec78b961637f16a2	2026-06-27 18:24:23.180135+05:30	20260625090000_media_system	\N	\N	2026-06-27 18:24:23.142674+05:30	1
f9835b17-e255-4618-bf1c-8d143937b26d	4217dafe79f7800da27cf412bed81f04894d5a42234ef9bd81df9c79acdbdac0	2026-06-27 18:24:23.261051+05:30	20260625100000_masters	\N	\N	2026-06-27 18:24:23.180921+05:30	1
532e06ea-1682-4a81-a6be-8cf98ddcdd88	d212670b6201e91b298b9c4a72490e17ae31c8e925be0e65bdedcce718532506	2026-06-27 18:24:23.273413+05:30	20260625110000_audit_fk_relations	\N	\N	2026-06-27 18:24:23.261636+05:30	1
dd23b7f7-d188-4898-ab72-83263732a0bd	597c5d2f239a196627941dc08a3f5c4ca5951d941c8e5bcd4dbf28b270c40268	2026-06-27 18:24:23.673261+05:30	20260626150000_phase11_institutional_membership	\N	\N	2026-06-27 18:24:23.655182+05:30	1
021ca998-b585-497f-a0f7-ff6de77a478f	45acac43d382dbbe489308c2129f1d987967ff1069e81265e69f33990236e971	2026-06-27 18:24:23.309305+05:30	20260625120000_documents	\N	\N	2026-06-27 18:24:23.273878+05:30	1
31d83142-d82b-4792-8a25-7ac9a1eb88f7	64dc1792f56d272aeb447c6fd57e38703587b784c50d5de37818e886521ffd60	2026-06-27 18:24:23.316233+05:30	20260625130000_document_audit_fks	\N	\N	2026-06-27 18:24:23.309849+05:30	1
f16af761-ed35-42a7-8028-29c41cefd651	dd2798e63a463c520c97f31498eeda7f3a7722c319fb92fdbba72227de6f6cfb	2026-06-27 18:24:23.319902+05:30	20260625140000_document_listing_index	\N	\N	2026-06-27 18:24:23.316962+05:30	1
f4845d4d-8d92-48b2-a313-bda1311cafe0	0e10b1ccc4d9dc2ecd0bda173b4336d22dadfcdc9e853eeb0f91d4efc401a6bd	2026-06-27 18:24:23.677198+05:30	20260626160000_membership_duplicate_prevention	\N	\N	2026-06-27 18:24:23.673934+05:30	1
4a578565-85b4-4974-82a1-5eacd8b6b349	1bf939bb7ea4074f653e84db47a65634af2dce4481db473eb0ffdbbf6dab680e	2026-06-27 18:24:23.430879+05:30	20260625150000_events_programmes_institutions	\N	\N	2026-06-27 18:24:23.320708+05:30	1
24fc6144-e747-436f-aba8-c756ff8bca21	1c4a1095a41e03d967ad786e0e5ab21287ae31d3b3c6329bd0901908921e21d5	2026-06-27 18:24:23.439148+05:30	20260625160000_phase5_remediation	\N	\N	2026-06-27 18:24:23.431464+05:30	1
b4dda900-f439-44fb-9139-081372c9c487	5bf70f3b568fd24fa9a5af0fbea3117943d9202c7800cb1019889ff626912a67	2026-06-27 18:24:23.475063+05:30	20260625170000_toolkits	\N	\N	2026-06-27 18:24:23.439874+05:30	1
a627055b-9ec4-4ed2-a6b8-65b1bd03556f	4ad60a80f3964e63f255b6b3959a4373ba6d1ffc7b1b0dc6d2f40ea000f6a306	2026-06-27 18:24:23.703204+05:30	20260626170000_phase12_dashboard	\N	\N	2026-06-27 18:24:23.677803+05:30	1
48d2f6c2-794f-4886-90f5-ef17d2ce94a8	29c4b4c323be65d315f5a4630acf40b0d2125491aed234a730ad7f71284216e1	2026-06-27 18:24:23.513928+05:30	20260625195459_phase10_pages_menus_faqs_digital_services	\N	\N	2026-06-27 18:24:23.475711+05:30	1
adfdbe91-b682-4110-9ee7-5cecb62f8c5c	3de7c6ab3c7e5234e70cfc3db0974a07674e111ea838d42b6d2447b01f1102c2	2026-06-27 18:24:23.55815+05:30	20260626120000_phase9_communications_tenders_procurement	\N	\N	2026-06-27 18:24:23.514635+05:30	1
e90854f2-6d6c-4d8f-8b63-36bc94578e4b	79ab336e85aecba121f5c8e49b465a5b672dd5c7d1ce49a059bd7283b9de01a2	2026-06-27 18:24:23.561368+05:30	20260626130000_tender_number_unique	\N	\N	2026-06-27 18:24:23.558942+05:30	1
8194b29b-c315-465f-b25e-9b068b3bd1f6	224a020d39e3d248d0d83cb849dd623573fe19488af2d70279cac0fa0560e8f0	2026-06-27 18:24:23.707513+05:30	20260626180000_dashboard_metric_unique_nulls_not_distinct	\N	\N	2026-06-27 18:24:23.703682+05:30	1
ffadc77e-4c56-4888-89e2-0e64564493a6	962d8065de53755c0cddeecf61550569dae70fc14042ae026aafa220790abc54	2026-06-27 18:24:23.809915+05:30	20260626190000_metadata_full_text_search	\N	\N	2026-06-27 18:24:23.708183+05:30	1
916d51bc-1c2d-4345-9cbc-9a860224b68b	0e796b6f275a01b3ae235b5254269a53f2f198ca78141d4f76213331ce9d4df5	2026-06-27 18:24:23.825716+05:30	20260627061544_add_enquiries_table	\N	\N	2026-06-27 18:24:23.810592+05:30	1
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, user_id, action, module, record_id, previous_state, new_state, change_summary, metadata, ip_hash, created_at) FROM stdin;
17253c27-a6f6-4f72-b5dd-dab24429b56e	daee13c3-8dd0-404d-8bc3-12ef2206dc60	archive	institutions	785bc955-c11f-4667-9352-cc63d9b4c44b	\N	{"fixture":true,"sequence":5}	Fictional audit action 5	{"fixture": true, "request_id": "fixture-request-5"}	37c9d3899b40e031c4d06824d45131e74267e8c84f230c9f0467de6c20c92136	2026-06-27 04:00:00
aa45e4f2-c9b5-4ac3-ab5c-acb9693b3b5a	daee13c3-8dd0-404d-8bc3-12ef2206dc60	restore	settings	\N	\N	{"fixture":true,"sequence":6}	Fictional audit action 6	{"fixture": true, "request_id": "fixture-request-6"}	7eaacdb19e781bb29d080dff2fb442231707a19eedb041da0b54535295f50f2d	2026-06-27 03:00:00
b6d3c9d7-2745-44fc-8c75-3f5fa325b129	daee13c3-8dd0-404d-8bc3-12ef2206dc60	media_replace	media	9859fc5a-0b08-404c-ae2e-3d12e344ffe4	{"publication_state":"draft"}	{"fixture":true,"sequence":7}	Fictional audit action 7	{"fixture": true, "request_id": "fixture-request-7"}	204522ea0c568b9be0c35d910df34fbf3c4035d205b55b353f7003494f10324f	2026-06-27 02:00:00
a319dbbe-94a7-4db3-a053-ba202cb84e6d	daee13c3-8dd0-404d-8bc3-12ef2206dc60	config_change	dashboard	113c1e98-e580-4dde-a6a3-b7c6f238adb0	\N	{"fixture":true,"sequence":8}	Fictional audit action 8	{"fixture": true, "request_id": "fixture-request-8"}	edee110449fd4ca25c60b380a792a61bdeee619df5cb22740d13c92084e6e6fb	2026-06-27 01:00:00
813a53d2-a73c-4a0c-b3fe-176a83035f9a	daee13c3-8dd0-404d-8bc3-12ef2206dc60	master_change	events	5f2efed6-7e9f-490e-a095-2eac4571c72f	\N	{"fixture":true,"sequence":9}	Fictional audit action 9	{"fixture": true, "request_id": "fixture-request-9"}	87b4e4eb9be9e2d7ca9d3d69f79a2389fd1b7b6aca5d17c7b8056990116d1d58	2026-06-27 00:00:00
34e65697-032f-4cd6-a854-f57fdeb90f5c	daee13c3-8dd0-404d-8bc3-12ef2206dc60	create	programmes	\N	\N	{"fixture":true,"sequence":11}	Fictional audit action 11	{"fixture": true, "request_id": "fixture-request-11"}	f0de823ceb807d4d51670e1147cb63c45e86ef941d23469773de7899cfeeca6b	2026-06-26 22:00:00
7424c7a0-8187-4391-9a52-12b004e8d3d4	daee13c3-8dd0-404d-8bc3-12ef2206dc60	update	toolkits	66a73d51-cba7-4cf9-be98-c07122494e39	\N	{"fixture":true,"sequence":12}	Fictional audit action 12	{"fixture": true, "request_id": "fixture-request-12"}	c96872afff68eb08a039321fdf67d4d284c34eb26031b937127d31cab9a5805c	2026-06-26 21:00:00
82680c43-d454-4dcd-bb7c-490de3882e26	daee13c3-8dd0-404d-8bc3-12ef2206dc60	publish	institutions	8fe44ffb-35cc-4c1b-b368-d4c2d9b05bac	{"publication_state":"draft"}	{"fixture":true,"sequence":13}	Fictional audit action 13	{"fixture": true, "request_id": "fixture-request-13"}	811f9061ae302af6eca4e779c4914942b4109d2a8439f0d65a693e43d083d537	2026-06-26 20:00:00
64a732ef-dc11-4543-a8f7-71d870d174b5	daee13c3-8dd0-404d-8bc3-12ef2206dc60	unpublish	settings	c63415a1-1b5a-4b1a-9933-02c65bb899b9	\N	{"fixture":true,"sequence":14}	Fictional audit action 14	{"fixture": true, "request_id": "fixture-request-14"}	247dd2a60454ea875994d42135ec67903e56b967d51e5fea14610424cbee7599	2026-06-26 19:00:00
1729db96-eef6-490e-a5e9-97bb7b720e5e	daee13c3-8dd0-404d-8bc3-12ef2206dc60	archive	media	021566a1-4d5e-444f-8ccb-575eef96372a	\N	{"fixture":true,"sequence":15}	Fictional audit action 15	{"fixture": true, "request_id": "fixture-request-15"}	88f24d61a3409a03bf9254749f016e96156b866c12975fe31cebc42e47622dfc	2026-06-26 18:00:00
dca49dc6-c84d-41b8-908c-05a8a0c87cce	daee13c3-8dd0-404d-8bc3-12ef2206dc60	restore	dashboard	\N	{"publication_state":"draft"}	{"fixture":true,"sequence":16}	Fictional audit action 16	{"fixture": true, "request_id": "fixture-request-16"}	ebc48498f9ff385f0ea74da327f9076258c630cd8acfd73fd797b8a5cca55c2c	2026-06-26 17:00:00
892cea03-7b79-4cfa-ba9f-8dbde42e622f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	media_replace	events	fedcc812-f311-44c1-a2f4-ee0e8eabd0d3	\N	{"fixture":true,"sequence":17}	Fictional audit action 17	{"fixture": true, "request_id": "fixture-request-17"}	e4246c89f916f01db4b96c96aa4aea163eab6f1d65a65d415e047a29cf802ed2	2026-06-26 16:00:00
e3f9c351-31dd-4dd6-927f-c281b55c4fe5	daee13c3-8dd0-404d-8bc3-12ef2206dc60	config_change	documents	7b3ffb02-f093-456a-b62e-ed95e1fa116b	\N	{"fixture":true,"sequence":18}	Fictional audit action 18	{"fixture": true, "request_id": "fixture-request-18"}	903b19f72a15e84e25eac796b906f3730a63c1915c303b02678c6264c11bb81e	2026-06-26 15:00:00
c159bad3-edc7-412e-8a1d-8a48753ab3d0	daee13c3-8dd0-404d-8bc3-12ef2206dc60	master_change	programmes	ad254ca2-7b89-4980-b1f9-2083236036a3	{"publication_state":"draft"}	{"fixture":true,"sequence":19}	Fictional audit action 19	{"fixture": true, "request_id": "fixture-request-19"}	ee702bee4b688b2e3986094481b2677062706a56f8ad95e332a9d62781f97113	2026-06-26 14:00:00
f831de0b-f39b-4535-8d66-abd5168b2e38	daee13c3-8dd0-404d-8bc3-12ef2206dc60	login	toolkits	ee5eedee-0f5c-4359-b2a2-65abe82fcaac	\N	{"fixture":true,"sequence":20}	Fictional audit action 20	{"fixture": true, "request_id": "fixture-request-20"}	5240542bf3c3ad71efe43c98ee3f3965c56a9616b785148df12eb615ff52d217	2026-06-26 13:00:00
bc2d29ae-41a8-49a0-8be9-b154b4d89730	daee13c3-8dd0-404d-8bc3-12ef2206dc60	create	institutions	\N	\N	{"fixture":true,"sequence":21}	Fictional audit action 21	{"fixture": true, "request_id": "fixture-request-21"}	008aa509ebdd4365eb4719229107bbf4c3443173dcd7783dc1494875844974ba	2026-06-26 12:00:00
d612fa61-fcc3-4ad8-a077-7e2bdb50ad9f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	update	settings	01e7abed-0289-42db-bfe8-d9e4115443b8	{"publication_state":"draft"}	{"fixture":true,"sequence":22}	Fictional audit action 22	{"fixture": true, "request_id": "fixture-request-22"}	2326eaca00c9d0a228d958efcb9ee4985d0c8faccee93d12ed4004d445633d4a	2026-06-26 11:00:00
02a657ea-ce24-466a-b15f-0b30419c2951	daee13c3-8dd0-404d-8bc3-12ef2206dc60	publish	media	4eb43ad1-2f90-407f-977f-8a313c20323d	\N	{"fixture":true,"sequence":23}	Fictional audit action 23	{"fixture": true, "request_id": "fixture-request-23"}	409d9b0d4702db033dcbd640632a742caed4e90903e893e7c65dba4040cc84a5	2026-06-26 10:00:00
8eb80803-371a-4d46-9dec-659b7b7048ac	daee13c3-8dd0-404d-8bc3-12ef2206dc60	unpublish	dashboard	a0ebef1f-88a2-4f75-96dc-049cad3aaaec	\N	{"fixture":true,"sequence":24}	Fictional audit action 24	{"fixture": true, "request_id": "fixture-request-24"}	0c0be32a1d2d2914c8c275fe9af824fbf388e881b69f68c9f78cab344dd21936	2026-06-26 09:00:00
bfec0eeb-b154-4d79-9f53-2a50b31f2749	daee13c3-8dd0-404d-8bc3-12ef2206dc60	archive	events	434b4b9b-ec1e-4a70-a8d0-52e3fd633c97	{"publication_state":"draft"}	{"fixture":true,"sequence":25}	Fictional audit action 25	{"fixture": true, "request_id": "fixture-request-25"}	2d9cefdc79624c7ffa97910945aa4a22c3195a847b16d14f4fac1f138685338b	2026-06-26 08:00:00
35ddda3e-1204-4d88-aa5e-e15606e7713e	daee13c3-8dd0-404d-8bc3-12ef2206dc60	restore	documents	\N	\N	{"fixture":true,"sequence":26}	Fictional audit action 26	{"fixture": true, "request_id": "fixture-request-26"}	d0b47037cc7064378cf622efab30985951e5c1fccf6b159504320222c103e800	2026-06-26 07:00:00
c44ca4fd-2f16-4b0a-949e-358cb621ead4	daee13c3-8dd0-404d-8bc3-12ef2206dc60	media_replace	programmes	6a0624d1-7478-49e6-9e75-3e336c85530a	\N	{"fixture":true,"sequence":27}	Fictional audit action 27	{"fixture": true, "request_id": "fixture-request-27"}	4b5439986866af589f012c3163d009845ddaae667873f871d19c568c17f00009	2026-06-26 06:00:00
a1af6705-55b4-4f81-ad01-de108b9f95ef	daee13c3-8dd0-404d-8bc3-12ef2206dc60	config_change	toolkits	b4af239f-d25b-413d-9259-3956b02bfa10	{"publication_state":"draft"}	{"fixture":true,"sequence":28}	Fictional audit action 28	{"fixture": true, "request_id": "fixture-request-28"}	54f98f3ed755a83b6a032d15168dbbcf41a16e1a1eed4f9d8cb649bc7267f27e	2026-06-26 05:00:00
2e039c67-f005-40f2-80de-22fad9d5677e	daee13c3-8dd0-404d-8bc3-12ef2206dc60	update	documents	0a7bff3a-4f14-4bfa-99ed-ef7bfe405151	\N	{"fixture":true,"sequence":2}	Fictional audit action 2	{"fixture": true, "request_id": "fixture-request-2"}	881501dd25492b5c40abaf1b53516307a4e5a7da9a9dc970a50a3615232fd441	2026-06-27 07:00:00
bfb65d05-6b6b-423e-bffc-fd594807b273	daee13c3-8dd0-404d-8bc3-12ef2206dc60	publish	programmes	e6fc8a81-527e-4d68-a7fd-d960d84cf6bb	\N	{"fixture":true,"sequence":3}	Fictional audit action 3	{"fixture": true, "request_id": "fixture-request-3"}	99c0b6830c0640c13c70405f97ea08f236afd5661d191557ec5d974768387533	2026-06-27 06:00:00
d107866e-f8c4-49d8-ab42-b682f5be9077	daee13c3-8dd0-404d-8bc3-12ef2206dc60	unpublish	toolkits	1b2659fd-4f4e-49ad-8f19-38c1d0f2348f	{"publication_state":"draft"}	{"fixture":true,"sequence":4}	Fictional audit action 4	{"fixture": true, "request_id": "fixture-request-4"}	3a19b0949e3ea2b6ae547a707bd7fb580b561b8a2f7d024e2d09c3fe4e95300d	2026-06-27 05:00:00
6a5a6cd3-1e09-4015-9c44-524611605ac0	daee13c3-8dd0-404d-8bc3-12ef2206dc60	create	media	\N	{"publication_state":"draft"}	{"fixture":true,"sequence":31}	Fictional audit action 31	{"fixture": true, "request_id": "fixture-request-31"}	fd46c391d5448970a77b75ea5e85efe42ca47ad9096197bb466b8daa6c92dd2e	2026-06-26 02:00:00
eb9d1a91-4455-48f3-82f2-3884f67aba0e	daee13c3-8dd0-404d-8bc3-12ef2206dc60	update	dashboard	243c2331-bd01-44f5-8f2e-4feea1140cc1	\N	{"fixture":true,"sequence":32}	Fictional audit action 32	{"fixture": true, "request_id": "fixture-request-32"}	a702b8310e5dcff4653d1696d7cfde53efb169ce99575c68ed611d37837045f3	2026-06-26 01:00:00
5be5f745-9e8b-4a19-ac9a-1cd49bd0f9b7	daee13c3-8dd0-404d-8bc3-12ef2206dc60	publish	events	665f3dbc-7156-4d97-a30d-e8aad6f7b9ca	\N	{"fixture":true,"sequence":33}	Fictional audit action 33	{"fixture": true, "request_id": "fixture-request-33"}	e6577c05d49c921a7f7778811f5275ec4a80f4a3ffb26d2c06554ff49d5c6382	2026-06-26 00:00:00
eb72dd28-f1c5-4955-85f2-919ea3113d08	daee13c3-8dd0-404d-8bc3-12ef2206dc60	unpublish	documents	c297c136-ae21-4dd8-81f1-7f620c0ea9f8	{"publication_state":"draft"}	{"fixture":true,"sequence":34}	Fictional audit action 34	{"fixture": true, "request_id": "fixture-request-34"}	a1d32a3614ceab7aeb98401732c50ddb212b6c4495511a7bc5b214cc97d9ced3	2026-06-25 23:00:00
14be93dd-dd76-4ab4-b7a1-f71999a81e20	daee13c3-8dd0-404d-8bc3-12ef2206dc60	archive	programmes	6796eb0d-d2fe-4a21-9303-7597eae14b3c	\N	{"fixture":true,"sequence":35}	Fictional audit action 35	{"fixture": true, "request_id": "fixture-request-35"}	0a74fe692204eecc803a06c4c431ac5a64f2eed9b54faf7a28c872c8de132a8c	2026-06-25 22:00:00
7fa97b1f-96eb-46c1-bdae-f1c27a47f95e	daee13c3-8dd0-404d-8bc3-12ef2206dc60	restore	toolkits	\N	\N	{"fixture":true,"sequence":36}	Fictional audit action 36	{"fixture": true, "request_id": "fixture-request-36"}	49f36a4dcfb99a42adcd2bae0414800673a26a2f570ae0f5cab417202aaa4d0c	2026-06-25 21:00:00
fed83766-69b3-4b40-a838-fceab3dec1f9	daee13c3-8dd0-404d-8bc3-12ef2206dc60	create	events	\N	{"publication_state":"draft"}	{"fixture":true,"sequence":1}	Fictional audit action 1	{"fixture": true, "request_id": "fixture-request-1"}	6016b22c70a5ea73bc5bf5c1d9c166f1a5306f018729132261aa9a350dcbac83	2026-06-27 08:00:00
86e7afa0-f6b4-4e0f-8858-4f8e48f464c2	daee13c3-8dd0-404d-8bc3-12ef2206dc60	login	documents	33d6d2f5-a369-4bb8-ba07-8b23b6f9d027	{"publication_state":"draft"}	{"fixture":true,"sequence":10}	Fictional audit action 10	{"fixture": true, "request_id": "fixture-request-10"}	357b64fe1b1827867372764d9875fe75a3e2fd5ff0f8d8a84712aec00f9fb584	2026-06-26 23:00:00
17964fff-2838-4a13-adae-2b461922223c	daee13c3-8dd0-404d-8bc3-12ef2206dc60	master_change	institutions	8014d146-85e3-4dcc-94d2-90c1b3f24177	\N	{"fixture":true,"sequence":29}	Fictional audit action 29	{"fixture": true, "request_id": "fixture-request-29"}	2a9b1eae5e4375adf6a6c2aa64f03f794ce387d70cba5d18b51ea0d3267514ad	2026-06-26 04:00:00
fa01087a-a7d9-490f-b19b-a5b4ac3258ce	daee13c3-8dd0-404d-8bc3-12ef2206dc60	login	settings	bbdc3616-db28-4acb-8bb7-5cce98d2572e	\N	{"fixture":true,"sequence":30}	Fictional audit action 30	{"fixture": true, "request_id": "fixture-request-30"}	4e86ae041559f2e4d7f0a4dbc4ae8f7b1857c5bfafd3325fd2666a18165d80aa	2026-06-26 03:00:00
\.


--
-- Data for Name: blocks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.blocks (id, district_id, name_en, name_hi, slug, is_active, display_order, created_at, updated_at) FROM stdin;
5d9bc516-4b05-4029-80a6-9f9f4e66d58d	7e07b268-f055-4f23-9a1c-2a9923e08f67	Ranchi Sadar	\N	ranchi-ranchi-sadar	t	1	2026-06-27 12:55:02.027	2026-06-27 13:00:45.816
5a926805-07ff-4793-b207-98e299841e51	7e07b268-f055-4f23-9a1c-2a9923e08f67	Namkum	\N	ranchi-namkum	t	2	2026-06-27 12:55:02.033	2026-06-27 13:00:45.817
beedebbb-6e21-480d-98fb-8c0af1692951	7e07b268-f055-4f23-9a1c-2a9923e08f67	Kanke	\N	ranchi-kanke	t	3	2026-06-27 12:55:02.035	2026-06-27 13:00:45.818
33cd2e6d-26d6-4690-9a56-15eca545bda2	7e07b268-f055-4f23-9a1c-2a9923e08f67	Ratu	\N	ranchi-ratu	t	4	2026-06-27 12:55:02.036	2026-06-27 13:00:45.819
21d84c58-dc1f-477d-a827-6a3868047b36	7e07b268-f055-4f23-9a1c-2a9923e08f67	Bero	\N	ranchi-bero	t	5	2026-06-27 12:55:02.037	2026-06-27 13:00:45.819
85cf7022-9e51-4285-b99f-3c850dcbeb96	a7f3f827-3863-4cb3-8ab8-2a8df83147df	Gumla	\N	gumla-gumla	t	1	2026-06-27 12:55:02.039	2026-06-27 13:00:45.821
97b37d19-a055-4a6d-aece-63ada3e00cff	a7f3f827-3863-4cb3-8ab8-2a8df83147df	Bishunpur	\N	gumla-bishunpur	t	2	2026-06-27 12:55:02.041	2026-06-27 13:00:45.821
4e69a312-10c8-4b31-89a8-cdfb7fccf8cb	a7f3f827-3863-4cb3-8ab8-2a8df83147df	Ghaghra	\N	gumla-ghaghra	t	3	2026-06-27 12:55:02.042	2026-06-27 13:00:45.822
7ecd51cf-c605-4f55-b14f-99ed00ec0fe9	a7f3f827-3863-4cb3-8ab8-2a8df83147df	Raidih	\N	gumla-raidih	t	4	2026-06-27 12:55:02.043	2026-06-27 13:00:45.823
dff461d4-35a0-4ee2-85e0-0b01b693f4e4	a7f3f827-3863-4cb3-8ab8-2a8df83147df	Sisai	\N	gumla-sisai	t	5	2026-06-27 12:55:02.044	2026-06-27 13:00:45.824
b21319fb-f3a1-4e30-bdc7-fac2f31e01cc	c55140f4-a206-4bb4-9e40-cea4a362d3f6	Khunti	\N	khunti-khunti	t	1	2026-06-27 12:55:02.047	2026-06-27 13:00:45.825
64240281-2ebb-4c1c-a5a9-49c500d73e99	c55140f4-a206-4bb4-9e40-cea4a362d3f6	Murhu	\N	khunti-murhu	t	2	2026-06-27 12:55:02.048	2026-06-27 13:00:45.826
f40df2e5-dd34-4d20-b677-dd53be548c0b	c55140f4-a206-4bb4-9e40-cea4a362d3f6	Torpa	\N	khunti-torpa	t	3	2026-06-27 12:55:02.049	2026-06-27 13:00:45.826
84f3370d-b997-4b1e-a2dc-babdc5e43a4d	c55140f4-a206-4bb4-9e40-cea4a362d3f6	Rania	\N	khunti-rania	t	4	2026-06-27 12:55:02.05	2026-06-27 13:00:45.827
\.


--
-- Data for Name: commodities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.commodities (id, name_en, name_hi, slug, description_en, description_hi, icon_media_id, is_active, display_order, created_at, updated_at) FROM stdin;
29abba96-aa2b-49b5-ba07-d75f2ce64932	Lac	लाख	lac	\N	\N	\N	t	1	2026-06-27 12:55:01.923	2026-06-27 13:00:45.742
d5302db1-d57e-4d7c-85ad-bf3dbc6db6e5	Honey	शहद	honey	\N	\N	\N	t	2	2026-06-27 12:55:01.927	2026-06-27 13:00:45.743
b4873f7f-544f-42c3-855e-2810c7970236	Ragi / Millets	रागी / मिलेट्स	ragi-millets	\N	\N	\N	t	3	2026-06-27 12:55:01.928	2026-06-27 13:00:45.744
cffc6a8c-ed36-4163-aab4-2417904ca859	Sal Seed	साल बीज	sal-seed	\N	\N	\N	t	4	2026-06-27 12:55:01.929	2026-06-27 13:00:45.745
df849f1b-b168-45a9-a1cb-40139f8d225d	Karanj	करंज	karanj	\N	\N	\N	t	5	2026-06-27 12:55:01.929	2026-06-27 13:00:45.746
4f276af1-d981-4294-9f50-fbcdf2c979c2	Tamarind	इमली	tamarind	\N	\N	\N	t	6	2026-06-27 12:55:01.93	2026-06-27 13:00:45.747
\.


--
-- Data for Name: communication_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.communication_types (id, name_en, name_hi, slug, is_active, display_order, created_at, updated_at) FROM stdin;
42ecac9d-42cd-40c8-85ba-3e89d9e0137d	Notice	\N	notice	t	1	2026-06-27 12:55:01.956	2026-06-27 13:00:45.77
58341cb8-722d-4bb7-a1b3-4b0fc17e6df7	Circular	\N	circular	t	2	2026-06-27 12:55:01.959	2026-06-27 13:00:45.771
47b8a50a-f6e8-4af2-b07f-de6bbb1da434	Office Order	\N	office-order	t	3	2026-06-27 12:55:01.96	2026-06-27 13:00:45.772
0968f479-b97e-4dae-b4a7-815868d54f2a	Notification	\N	notification	t	4	2026-06-27 12:55:01.96	2026-06-27 13:00:45.772
ac7cd88e-ce6b-4ab3-bca8-c22a5231581e	Advisory	\N	advisory	t	5	2026-06-27 12:55:01.961	2026-06-27 13:00:45.773
350525f0-eb9f-4c22-a502-5e40ceefee69	Public Announcement	\N	public-announcement	t	6	2026-06-27 12:55:01.962	2026-06-27 13:00:45.774
\.


--
-- Data for Name: dashboard_datasets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dashboard_datasets (id, report_id, source, financial_year_id, reporting_period_id, source_file_asset_id, raw_rows, row_count, status, processed_at, created_by, created_at, updated_at) FROM stdin;
832bd91b-0eec-48a1-92ce-de07761a9957	82b806a3-a98f-4d6c-9b15-4e1323189d02	excel	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	0c2d3490-97d3-49a3-ac4d-890c553eef7f	[{"value": 100, "district": "Ranchi"}, {"value": 80, "district": "Gumla"}]	2	processed	2026-06-27 08:00:00	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.502	2026-06-27 13:00:47.114
0ebc3afd-142d-4326-9537-84fbf31078dc	831039a0-1e63-4d70-aae3-a1f97764794c	manual	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	eb4b5f98-228a-4cee-9150-8167a303dd9d	[{"value": 101, "district": "Ranchi"}, {"value": 81, "district": "Gumla"}]	2	processed	2026-06-27 08:00:00	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.521	2026-06-27 13:00:47.122
c7d6129e-2ca2-4db8-a778-6bc9fa1e4657	6060f07a-b72b-47c4-9fd1-139ab3f14e99	cms_derived	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	79d022a1-0156-407f-b0e5-9dfb743eff91	[{"value": 102, "district": "Ranchi"}, {"value": 82, "district": "Gumla"}]	2	processed	2026-06-27 08:00:00	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.533	2026-06-27 13:00:47.13
6bf8452e-db10-4091-8ecc-055edd56813f	0af3fc45-18c3-4906-ab6c-6c0570fa2fbd	excel	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	afd1fc9a-6a81-408d-b0de-2af96a642b7c	[{"value": 103, "district": "Ranchi"}, {"value": 83, "district": "Gumla"}]	2	processed	2026-06-27 08:00:00	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.543	2026-06-27 13:00:47.137
d1dd86e2-1198-4958-b0f1-064279e1fce3	6d03ee2b-603d-4f19-a8a0-a93ca50b8b96	manual	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	2bede4ce-021a-4e26-87f9-a598050a3c0b	[{"value": 104, "district": "Ranchi"}, {"value": 84, "district": "Gumla"}]	2	processed	2026-06-27 08:00:00	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.553	2026-06-27 13:00:47.144
87e341d6-3575-43bd-9fc9-a07ea2bd2186	4274c745-1cb4-4435-a9ee-a5ea9fc98f91	cms_derived	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	89019f27-920a-464e-80fe-49b0135b5d11	[{"value": 105, "district": "Ranchi"}, {"value": 85, "district": "Gumla"}]	2	processed	2026-06-27 08:00:00	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.564	2026-06-27 13:00:47.15
52a5f18b-30df-4ed6-867c-1184200d5a4b	913826e3-2f97-4f61-8a09-91e8969da352	excel	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	32946568-e6ae-424b-9d93-b7351a35902b	[{"value": 106, "district": "Ranchi"}, {"value": 86, "district": "Gumla"}]	2	processed	2026-06-27 08:00:00	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.574	2026-06-27 13:00:47.156
a5ba80ab-1f49-4d2e-a18d-974a5861edbe	a716a91d-061a-426d-892a-2cf4162f4223	manual	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	a72e713b-0a42-4a02-af13-dabc59f39527	[{"value": 107, "district": "Ranchi"}, {"value": 87, "district": "Gumla"}]	2	processed	2026-06-27 08:00:00	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.584	2026-06-27 13:00:47.163
17e32f08-cec1-484b-904f-6676e6c2c1fd	d027c45d-e78c-4cac-9d8f-af9584715dd6	cms_derived	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	0c2d3490-97d3-49a3-ac4d-890c553eef7f	[{"value": 108, "district": "Ranchi"}, {"value": 88, "district": "Gumla"}]	2	processed	2026-06-27 08:00:00	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.593	2026-06-27 13:00:47.17
7d89af7b-6ec7-4dbd-9dff-f60e1b014984	9599a2e5-d860-4bae-bdc3-fe992b14180f	excel	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	eb4b5f98-228a-4cee-9150-8167a303dd9d	[{"value": 109, "district": "Ranchi"}, {"value": 89, "district": "Gumla"}]	2	processed	2026-06-27 08:00:00	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.603	2026-06-27 13:00:47.177
bd2b3c3a-beab-4fc7-9769-28806cc07b0d	468c64e4-11a5-4a64-8092-c531f99f622c	manual	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	79d022a1-0156-407f-b0e5-9dfb743eff91	[{"value": 110, "district": "Ranchi"}, {"value": 90, "district": "Gumla"}]	2	processed	2026-06-27 08:00:00	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.611	2026-06-27 13:00:47.184
4ebb8eb2-aeec-4de9-a310-ef3c904f052c	5e71fec4-d5a4-41ef-87ff-545b7ee39908	cms_derived	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	afd1fc9a-6a81-408d-b0de-2af96a642b7c	[{"value": 111, "district": "Ranchi"}, {"value": 91, "district": "Gumla"}]	2	processed	2026-06-27 08:00:00	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.618	2026-06-27 13:00:47.19
57f30960-852c-4c5b-b713-214cce5912ea	ee1bf83e-8b5d-448e-a036-d229aee33399	excel	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	2bede4ce-021a-4e26-87f9-a598050a3c0b	[{"value": 112, "district": "Ranchi"}, {"value": 92, "district": "Gumla"}]	2	failed	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.626	2026-06-27 13:00:47.197
\.


--
-- Data for Name: dashboard_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dashboard_metrics (id, report_id, metric_key, label_en, label_hi, value, value_text, unit, financial_year_id, reporting_period_id, source, dataset_id, display_order, created_by, updated_by, created_at, updated_at) FROM stdin;
d761bbef-ee34-49de-9f3f-7242ec304e13	831039a0-1e63-4d70-aae3-a1f97764794c	fixture_metric_1	Total activities	डेमो संकेतक 1	110.0000	\N	count	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	manual	0ebc3afd-142d-4326-9537-84fbf31078dc	1	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.523	2026-06-27 13:00:47.124
8ba4655b-c206-46e1-b785-c122c52c81dc	831039a0-1e63-4d70-aae3-a1f97764794c	fixture_metric_2	Participants reached	डेमो संकेतक 2	111.0000	\N	count	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	manual	0ebc3afd-142d-4326-9537-84fbf31078dc	2	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.525	2026-06-27 13:00:47.125
1c0cbdd3-7f2f-460a-8bdd-0a4ac6d5f88e	831039a0-1e63-4d70-aae3-a1f97764794c	fixture_metric_3	Districts covered	\N	112.0000	\N	districts	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	manual	0ebc3afd-142d-4326-9537-84fbf31078dc	3	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.528	2026-06-27 13:00:47.126
d24d3d1f-a1a3-4ab0-8c15-5f8ca035ecd0	831039a0-1e63-4d70-aae3-a1f97764794c	fixture_metric_4	Completion rate	\N	87.5000	\N	percent	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	manual	0ebc3afd-142d-4326-9537-84fbf31078dc	4	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.53	2026-06-27 13:00:47.127
90cc6de3-463f-4677-a111-c5cf8123590d	6060f07a-b72b-47c4-9fd1-139ab3f14e99	fixture_metric_1	Total activities	डेमो संकेतक 1	120.0000	\N	count	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	cms_derived	c7d6129e-2ca2-4db8-a778-6bc9fa1e4657	1	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.535	2026-06-27 13:00:47.131
e6f2fc2e-b92f-4c02-a260-6cadf3d67aa7	6060f07a-b72b-47c4-9fd1-139ab3f14e99	fixture_metric_2	Participants reached	डेमो संकेतक 2	121.0000	\N	count	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	cms_derived	c7d6129e-2ca2-4db8-a778-6bc9fa1e4657	2	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.537	2026-06-27 13:00:47.133
ecf93066-6a9e-4eaa-8c66-7e93bc6d7642	6060f07a-b72b-47c4-9fd1-139ab3f14e99	fixture_metric_3	Districts covered	\N	122.0000	\N	districts	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	cms_derived	c7d6129e-2ca2-4db8-a778-6bc9fa1e4657	3	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.538	2026-06-27 13:00:47.133
78006e81-699f-47a4-8d9e-89acfd06a033	6060f07a-b72b-47c4-9fd1-139ab3f14e99	fixture_metric_4	Completion rate	\N	87.5000	\N	percent	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	cms_derived	c7d6129e-2ca2-4db8-a778-6bc9fa1e4657	4	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.54	2026-06-27 13:00:47.134
89a58e27-7b32-4e2e-82d4-6059b25745fb	0af3fc45-18c3-4906-ab6c-6c0570fa2fbd	fixture_metric_1	Total activities	डेमो संकेतक 1	130.0000	\N	count	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	excel	6bf8452e-db10-4091-8ecc-055edd56813f	1	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.545	2026-06-27 13:00:47.138
02ba8dca-3fd9-4845-83b1-ee7ce752d77a	0af3fc45-18c3-4906-ab6c-6c0570fa2fbd	fixture_metric_2	Participants reached	डेमो संकेतक 2	131.0000	\N	count	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	excel	6bf8452e-db10-4091-8ecc-055edd56813f	2	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.547	2026-06-27 13:00:47.139
b5423fa1-d241-464d-895b-4a8e3f5acb06	0af3fc45-18c3-4906-ab6c-6c0570fa2fbd	fixture_metric_3	Districts covered	\N	132.0000	\N	districts	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	excel	6bf8452e-db10-4091-8ecc-055edd56813f	3	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.548	2026-06-27 13:00:47.14
e5e0f03d-dfd7-42eb-8c2e-4785e1230cc7	0af3fc45-18c3-4906-ab6c-6c0570fa2fbd	fixture_metric_4	Completion rate	\N	87.5000	\N	percent	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	excel	6bf8452e-db10-4091-8ecc-055edd56813f	4	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.55	2026-06-27 13:00:47.141
a6a7e3a0-ebfb-4bb5-9231-c3b914881f99	6d03ee2b-603d-4f19-a8a0-a93ca50b8b96	fixture_metric_1	Total activities	डेमो संकेतक 1	140.0000	\N	count	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	manual	d1dd86e2-1198-4958-b0f1-064279e1fce3	1	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.555	2026-06-27 13:00:47.145
b4db8ab3-7000-494d-a84d-8a582c1e76de	6d03ee2b-603d-4f19-a8a0-a93ca50b8b96	fixture_metric_2	Participants reached	डेमो संकेतक 2	141.0000	\N	count	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	manual	d1dd86e2-1198-4958-b0f1-064279e1fce3	2	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.557	2026-06-27 13:00:47.146
212ede62-6ed1-4c0c-9b5a-1408ffdad12b	6d03ee2b-603d-4f19-a8a0-a93ca50b8b96	fixture_metric_3	Districts covered	\N	142.0000	\N	districts	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	manual	d1dd86e2-1198-4958-b0f1-064279e1fce3	3	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.559	2026-06-27 13:00:47.147
d71d0ed6-0b58-4fd4-afdb-ebe2ca7c860f	6d03ee2b-603d-4f19-a8a0-a93ca50b8b96	fixture_metric_4	Completion rate	\N	87.5000	\N	percent	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	manual	d1dd86e2-1198-4958-b0f1-064279e1fce3	4	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.56	2026-06-27 13:00:47.148
34dde253-058d-4829-8eaf-657633751e9c	4274c745-1cb4-4435-a9ee-a5ea9fc98f91	fixture_metric_1	Total activities	डेमो संकेतक 1	150.0000	\N	count	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	cms_derived	87e341d6-3575-43bd-9fc9-a07ea2bd2186	1	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.565	2026-06-27 13:00:47.151
15915e58-a7ad-4164-836a-2885fcd211b6	4274c745-1cb4-4435-a9ee-a5ea9fc98f91	fixture_metric_2	Participants reached	डेमो संकेतक 2	151.0000	\N	count	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	cms_derived	87e341d6-3575-43bd-9fc9-a07ea2bd2186	2	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.567	2026-06-27 13:00:47.152
278c2e25-7aca-49c0-8b76-59ba870397f6	4274c745-1cb4-4435-a9ee-a5ea9fc98f91	fixture_metric_3	Districts covered	\N	152.0000	\N	districts	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	cms_derived	87e341d6-3575-43bd-9fc9-a07ea2bd2186	3	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.569	2026-06-27 13:00:47.153
be8a5c29-5be3-491e-843e-13ac0d3b4a3f	4274c745-1cb4-4435-a9ee-a5ea9fc98f91	fixture_metric_4	Completion rate	\N	87.5000	\N	percent	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	cms_derived	87e341d6-3575-43bd-9fc9-a07ea2bd2186	4	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.571	2026-06-27 13:00:47.154
bf373847-1c0f-4749-bf41-78b4d29d9018	913826e3-2f97-4f61-8a09-91e8969da352	fixture_metric_1	Total activities	डेमो संकेतक 1	160.0000	\N	count	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	excel	52a5f18b-30df-4ed6-867c-1184200d5a4b	1	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.576	2026-06-27 13:00:47.157
f320464b-4714-443f-81f1-360890da02e4	913826e3-2f97-4f61-8a09-91e8969da352	fixture_metric_2	Participants reached	डेमो संकेतक 2	161.0000	\N	count	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	excel	52a5f18b-30df-4ed6-867c-1184200d5a4b	2	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.578	2026-06-27 13:00:47.159
29aa3738-67bf-4785-a026-90035767ef48	913826e3-2f97-4f61-8a09-91e8969da352	fixture_metric_3	Districts covered	\N	162.0000	\N	districts	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	excel	52a5f18b-30df-4ed6-867c-1184200d5a4b	3	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.579	2026-06-27 13:00:47.16
bba5857e-3d57-42f0-8eda-09e6024d6669	913826e3-2f97-4f61-8a09-91e8969da352	fixture_metric_4	Completion rate	\N	87.5000	\N	percent	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	excel	52a5f18b-30df-4ed6-867c-1184200d5a4b	4	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.58	2026-06-27 13:00:47.161
4ec5f088-1a28-4a71-87a6-f1d975227bea	a716a91d-061a-426d-892a-2cf4162f4223	fixture_metric_1	Total activities	डेमो संकेतक 1	170.0000	\N	count	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	manual	a5ba80ab-1f49-4d2e-a18d-974a5861edbe	1	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.585	2026-06-27 13:00:47.164
10921e04-d9c3-4a62-bd0c-cec8edeb9f2e	a716a91d-061a-426d-892a-2cf4162f4223	fixture_metric_2	Participants reached	डेमो संकेतक 2	171.0000	\N	count	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	manual	a5ba80ab-1f49-4d2e-a18d-974a5861edbe	2	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.586	2026-06-27 13:00:47.166
d42e4ba4-79d4-4a57-beea-abc09e54b73e	a716a91d-061a-426d-892a-2cf4162f4223	fixture_metric_3	Districts covered	\N	172.0000	\N	districts	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	manual	a5ba80ab-1f49-4d2e-a18d-974a5861edbe	3	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.588	2026-06-27 13:00:47.167
3ba93a74-d5a4-40d4-b6ed-206ff843616a	a716a91d-061a-426d-892a-2cf4162f4223	fixture_metric_4	Completion rate	\N	87.5000	\N	percent	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	manual	a5ba80ab-1f49-4d2e-a18d-974a5861edbe	4	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.59	2026-06-27 13:00:47.168
7dc5e483-4e35-4ad5-b5bc-2d079c3fafe2	d027c45d-e78c-4cac-9d8f-af9584715dd6	fixture_metric_1	Total activities	डेमो संकेतक 1	180.0000	\N	count	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	cms_derived	17e32f08-cec1-484b-904f-6676e6c2c1fd	1	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.595	2026-06-27 13:00:47.171
1e028727-c9c7-47e1-bf33-368b64b58cc3	82b806a3-a98f-4d6c-9b15-4e1323189d02	fixture_metric_2	Participants reached	डेमो संकेतक 2	101.0000	\N	count	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	excel	832bd91b-0eec-48a1-92ce-de07761a9957	2	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.512	2026-06-27 13:00:47.117
0d595b15-fbca-4a8a-90ac-f9a0e504a984	82b806a3-a98f-4d6c-9b15-4e1323189d02	fixture_metric_3	Districts covered	\N	102.0000	\N	districts	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	excel	832bd91b-0eec-48a1-92ce-de07761a9957	3	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.515	2026-06-27 13:00:47.118
3def55b7-0a7c-478b-8955-5a2bba55d94c	82b806a3-a98f-4d6c-9b15-4e1323189d02	fixture_metric_4	Completion rate	\N	87.5000	\N	percent	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	excel	832bd91b-0eec-48a1-92ce-de07761a9957	4	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.517	2026-06-27 13:00:47.119
13e8e230-0a98-4282-b51f-52feb32fb663	9599a2e5-d860-4bae-bdc3-fe992b14180f	fixture_metric_4	Completion rate	\N	87.5000	\N	percent	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	excel	7d89af7b-6ec7-4dbd-9dff-f60e1b014984	4	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.609	2026-06-27 13:00:47.182
ad66b90b-6c2f-478f-ad76-e4a2cdbaaa39	468c64e4-11a5-4a64-8092-c531f99f622c	fixture_metric_1	Total activities	डेमो संकेतक 1	200.0000	\N	count	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	manual	bd2b3c3a-beab-4fc7-9769-28806cc07b0d	1	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.612	2026-06-27 13:00:47.185
82609620-1740-4ea6-8ea1-1c6c00806418	ee1bf83e-8b5d-448e-a036-d229aee33399	fixture_metric_3	Districts covered	\N	222.0000	\N	districts	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	excel	57f30960-852c-4c5b-b713-214cce5912ea	3	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.629	2026-06-27 13:00:47.201
de588593-1da0-4306-a4f3-6e2a19516c26	ee1bf83e-8b5d-448e-a036-d229aee33399	fixture_metric_4	Completion rate	\N	87.5000	\N	percent	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	excel	57f30960-852c-4c5b-b713-214cce5912ea	4	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.631	2026-06-27 13:00:47.202
c79cd27b-6b6d-46f2-8f05-6cec5265a494	468c64e4-11a5-4a64-8092-c531f99f622c	fixture_metric_2	Participants reached	डेमो संकेतक 2	201.0000	\N	count	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	manual	bd2b3c3a-beab-4fc7-9769-28806cc07b0d	2	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.613	2026-06-27 13:00:47.186
ed2d7a26-7b4b-4d1d-a88f-ecbafd8009bc	468c64e4-11a5-4a64-8092-c531f99f622c	fixture_metric_3	Districts covered	\N	202.0000	\N	districts	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	manual	bd2b3c3a-beab-4fc7-9769-28806cc07b0d	3	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.614	2026-06-27 13:00:47.188
f9efc137-6578-48b5-ac52-9f472ea43390	468c64e4-11a5-4a64-8092-c531f99f622c	fixture_metric_4	Completion rate	\N	87.5000	\N	percent	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	manual	bd2b3c3a-beab-4fc7-9769-28806cc07b0d	4	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.615	2026-06-27 13:00:47.189
4d957071-df4c-4a6b-81f5-7b8fe7810b29	5e71fec4-d5a4-41ef-87ff-545b7ee39908	fixture_metric_1	Total activities	डेमो संकेतक 1	210.0000	\N	count	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	cms_derived	4ebb8eb2-aeec-4de9-a310-ef3c904f052c	1	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.619	2026-06-27 13:00:47.192
2138af59-bada-4d0d-9e97-b0e22897e2df	5e71fec4-d5a4-41ef-87ff-545b7ee39908	fixture_metric_2	Participants reached	डेमो संकेतक 2	211.0000	\N	count	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	cms_derived	4ebb8eb2-aeec-4de9-a310-ef3c904f052c	2	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.62	2026-06-27 13:00:47.193
1c080d50-b4ff-4d90-b881-232844ccc220	5e71fec4-d5a4-41ef-87ff-545b7ee39908	fixture_metric_3	Districts covered	\N	212.0000	\N	districts	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	cms_derived	4ebb8eb2-aeec-4de9-a310-ef3c904f052c	3	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.621	2026-06-27 13:00:47.194
b9c60e13-0b82-4c97-8172-fc0a67581f06	5e71fec4-d5a4-41ef-87ff-545b7ee39908	fixture_metric_4	Completion rate	\N	87.5000	\N	percent	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	cms_derived	4ebb8eb2-aeec-4de9-a310-ef3c904f052c	4	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.623	2026-06-27 13:00:47.195
a422333e-145d-4ba0-a99e-e5b8c7c403b2	ee1bf83e-8b5d-448e-a036-d229aee33399	fixture_metric_1	Total activities	डेमो संकेतक 1	220.0000	\N	count	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	excel	57f30960-852c-4c5b-b713-214cce5912ea	1	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.627	2026-06-27 13:00:47.198
390bc49c-5fa5-41e5-989e-b4572f9c3e05	ee1bf83e-8b5d-448e-a036-d229aee33399	fixture_metric_2	Participants reached	डेमो संकेतक 2	221.0000	\N	count	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	excel	57f30960-852c-4c5b-b713-214cce5912ea	2	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.628	2026-06-27 13:00:47.2
a92da338-656a-43b2-9061-a18fe7a35e47	82b806a3-a98f-4d6c-9b15-4e1323189d02	fixture_metric_1	Total activities	डेमो संकेतक 1	100.0000	\N	count	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	excel	832bd91b-0eec-48a1-92ce-de07761a9957	1	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.507	2026-06-27 13:00:47.115
41ce41c4-7aba-4a90-88ac-1701661f4e2e	d027c45d-e78c-4cac-9d8f-af9584715dd6	fixture_metric_2	Participants reached	डेमो संकेतक 2	181.0000	\N	count	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	cms_derived	17e32f08-cec1-484b-904f-6676e6c2c1fd	2	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.596	2026-06-27 13:00:47.172
cbdb05ac-51ce-42de-a1b2-b211a011d5c5	d027c45d-e78c-4cac-9d8f-af9584715dd6	fixture_metric_3	Districts covered	\N	182.0000	\N	districts	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	cms_derived	17e32f08-cec1-484b-904f-6676e6c2c1fd	3	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.598	2026-06-27 13:00:47.173
12b78ea6-3503-4530-8658-ca82517048fb	d027c45d-e78c-4cac-9d8f-af9584715dd6	fixture_metric_4	Completion rate	\N	87.5000	\N	percent	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	cms_derived	17e32f08-cec1-484b-904f-6676e6c2c1fd	4	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.6	2026-06-27 13:00:47.174
60398ea0-9e24-4e55-83d2-ac8a36d9e793	9599a2e5-d860-4bae-bdc3-fe992b14180f	fixture_metric_1	Total activities	डेमो संकेतक 1	190.0000	\N	count	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	excel	7d89af7b-6ec7-4dbd-9dff-f60e1b014984	1	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.604	2026-06-27 13:00:47.178
3d826391-e4be-4c1e-b156-fcaf4d74da3e	9599a2e5-d860-4bae-bdc3-fe992b14180f	fixture_metric_2	Participants reached	डेमो संकेतक 2	191.0000	\N	count	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	excel	7d89af7b-6ec7-4dbd-9dff-f60e1b014984	2	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.606	2026-06-27 13:00:47.179
68a7aa76-c53e-4f37-8b17-a2ccdc2ec0d6	9599a2e5-d860-4bae-bdc3-fe992b14180f	fixture_metric_3	Districts covered	\N	192.0000	\N	districts	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	16eef30e-3720-43c3-9d92-e2206cde1933	excel	7d89af7b-6ec7-4dbd-9dff-f60e1b014984	3	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.607	2026-06-27 13:00:47.18
\.


--
-- Data for Name: dashboard_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dashboard_reports (id, report_key, title_en, title_hi, description_en, description_hi, layout_config, publication_state, public_visibility, publish_start_at, published_at, archived_at, highlight_type, highlight_start_at, highlight_end_at, display_order, show_on_homepage, is_active, created_by, updated_by, created_at, updated_at) FROM stdin;
d027c45d-e78c-4cac-9d8f-af9584715dd6	partnerships_mous	Partnerships and MoUs	डेमो डैशबोर्ड रिपोर्ट 9	Fictional fixed-layout dashboard report.	\N	{"layout": "fixed", "default_source": "cms_derived"}	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	9	f	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.082	2026-06-27 13:00:47.169
9599a2e5-d860-4bae-bdc3-fe992b14180f	sidhkofed_primary_membership	SIDHKOFED Primary Membership	\N	Fictional fixed-layout dashboard report.	\N	{"layout": "fixed", "default_source": "cms_derived"}	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	10	f	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.083	2026-06-27 13:00:47.175
468c64e4-11a5-4a64-8092-c531f99f622c	sidhkofed_nominal_membership	SIDHKOFED Nominal Membership	डेमो डैशबोर्ड रिपोर्ट 11	Fictional fixed-layout dashboard report.	\N	{"layout": "fixed", "default_source": "cms_derived"}	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	11	f	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.084	2026-06-27 13:00:47.183
5e71fec4-d5a4-41ef-87ff-545b7ee39908	du_primary_membership	DU Primary Membership	\N	Fictional fixed-layout dashboard report.	\N	{"layout": "fixed", "default_source": "cms_derived"}	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	12	f	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.085	2026-06-27 13:00:47.189
ee1bf83e-8b5d-448e-a036-d229aee33399	du_nominal_membership	DU Nominal Membership	डेमो डैशबोर्ड रिपोर्ट 13	Fictional fixed-layout dashboard report.	\N	{"layout": "fixed", "default_source": "cms_derived"}	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	13	f	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.086	2026-06-27 13:00:47.196
82b806a3-a98f-4d6c-9b15-4e1323189d02	procurement_summary	Procurement Summary	डेमो डैशबोर्ड रिपोर्ट 1	Fictional fixed-layout dashboard report.	\N	{"layout": "fixed", "default_source": "manual"}	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	1	t	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.066	2026-06-27 13:00:47.112
831039a0-1e63-4d70-aae3-a1f97764794c	training_summary	Training Summary	\N	Fictional fixed-layout dashboard report.	\N	{"layout": "fixed", "default_source": "cms_derived"}	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	2	t	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.071	2026-06-27 13:00:47.121
6060f07a-b72b-47c4-9fd1-139ab3f14e99	beneficiaries_reached	Beneficiaries Reached	डेमो डैशबोर्ड रिपोर्ट 3	Fictional fixed-layout dashboard report.	\N	{"layout": "fixed", "default_source": "manual"}	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	3	t	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.073	2026-06-27 13:00:47.128
0af3fc45-18c3-4906-ab6c-6c0570fa2fbd	activities_events_summary	Activities / Events Summary	\N	Fictional fixed-layout dashboard report.	\N	{"layout": "fixed", "default_source": "cms_derived"}	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	4	t	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.074	2026-06-27 13:00:47.135
6d03ee2b-603d-4f19-a8a0-a93ca50b8b96	district_geographical_coverage	District and Geographical Coverage	डेमो डैशबोर्ड रिपोर्ट 5	Fictional fixed-layout dashboard report.	\N	{"layout": "fixed", "default_source": "cms_derived"}	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	5	t	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.076	2026-06-27 13:00:47.142
4274c745-1cb4-4435-a9ee-a5ea9fc98f91	commodity_wise_activities	Commodity-wise Activities	\N	Fictional fixed-layout dashboard report.	\N	{"layout": "fixed", "default_source": "cms_derived"}	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	6	f	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.078	2026-06-27 13:00:47.149
913826e3-2f97-4f61-8a09-91e8969da352	commodity_wise_toolkit_distribution	Commodity-wise Toolkit Distribution	डेमो डैशबोर्ड रिपोर्ट 7	Fictional fixed-layout dashboard report.	\N	{"layout": "fixed", "default_source": "cms_derived"}	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	7	f	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.079	2026-06-27 13:00:47.155
a716a91d-061a-426d-892a-2cf4162f4223	programme_scheme_coverage	Programme / Scheme Coverage	\N	Fictional fixed-layout dashboard report.	\N	{"layout": "fixed", "default_source": "cms_derived"}	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	8	f	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.08	2026-06-27 13:00:47.162
\.


--
-- Data for Name: digital_services; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.digital_services (id, title_en, title_hi, description_en, description_hi, external_url, icon_media_id, slug, publication_state, public_visibility, publish_start_at, published_at, archived_at, highlight_type, highlight_start_at, highlight_end_at, display_order, show_on_homepage, created_by, updated_by, created_at, updated_at) FROM stdin;
3c0e82dd-3912-409f-9d5e-89ffa0c27ceb	Demo Digital Service 1	डेमो डिजिटल सेवा 1	Fictional external service link for card and homepage testing.	\N	https://example.test/services/1	3f24f935-ecf7-4c53-bd05-2d673cef6692	demo-digital-service-1	published	t	\N	2026-01-15 08:00:00	\N	featured	2026-01-15 08:00:00	2027-01-15 08:00:00	1	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.376	2026-06-27 13:00:47.022
7f6642c5-9c91-4890-846b-5a74e25a66d0	Demo Digital Service 2	\N	Fictional external service link for card and homepage testing.	\N	https://example.test/services/2	6853eb6c-ba01-4312-b751-b608641a94f5	demo-digital-service-2	published	t	\N	2026-01-15 08:00:00	\N	latest	2026-01-15 08:00:00	2027-01-15 08:00:00	2	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.381	2026-06-27 13:00:47.023
67e18155-b155-4ce4-ba44-2063a937e690	Demo Digital Service 3	डेमो डिजिटल सेवा 3	Fictional external service link for card and homepage testing.	\N	https://example.test/services/3	cd1634aa-09ca-471d-a8b8-94968c0b7c9d	demo-digital-service-3	published	t	\N	2026-01-15 08:00:00	\N	important	2026-01-15 08:00:00	2027-01-15 08:00:00	3	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.382	2026-06-27 13:00:47.025
d0f0fa5d-6b6b-4e17-a8a1-36f32c9fc6ce	Demo Digital Service 4	\N	Fictional external service link for card and homepage testing.	\N	https://example.test/services/4	e572b312-06c9-47e3-b150-4fd9c2b4e59c	demo-digital-service-4	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	4	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.384	2026-06-27 13:00:47.026
42eb4290-7051-4d39-bbe8-465e054934b3	Demo Digital Service 5	डेमो डिजिटल सेवा 5	Fictional external service link for card and homepage testing.	\N	https://example.test/services/5	cc4f583c-bd55-44e8-a408-9af5aa951372	demo-digital-service-5	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	5	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.386	2026-06-27 13:00:47.028
e30b638c-833f-4a38-896f-8af291e91b88	Demo Digital Service 6	\N	Fictional external service link for card and homepage testing.	\N	https://example.test/services/6	eb3877af-dd51-4f3c-8b6b-57570d63c33c	demo-digital-service-6	unpublished	t	\N	\N	\N	\N	\N	\N	6	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.387	2026-06-27 13:00:47.029
1bfe579e-7a5d-4c66-99b6-c24a743143c7	Demo Digital Service 7	डेमो डिजिटल सेवा 7	Fictional external service link for card and homepage testing.	\N	https://example.test/services/7	18620944-e2bc-4e06-811d-f2c33d22ae84	demo-digital-service-7	published	t	2027-01-15 08:00:00	2026-01-15 08:00:00	\N	\N	\N	\N	7	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.389	2026-06-27 13:00:47.03
b573ec89-f168-4e74-a8bd-38c0df07c825	Demo Digital Service 8	\N	Fictional external service link for card and homepage testing.	\N	https://example.test/services/8	bf9358c7-960b-4365-8b61-74f8788a7ad3	demo-digital-service-8	published	f	\N	2026-01-15 08:00:00	\N	\N	\N	\N	8	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.39	2026-06-27 13:00:47.032
2b3c6c01-cb3e-4d82-9ea1-6e0fa1049045	Demo Digital Service 9	डेमो डिजिटल सेवा 9	Fictional external service link for card and homepage testing.	\N	https://example.test/services/9	84e59f6d-0311-404d-beaa-cf2172b47897	demo-digital-service-9	draft	t	\N	\N	\N	\N	\N	\N	9	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.392	2026-06-27 13:00:47.034
034c923b-290f-4c48-a37e-eac892d5d7a3	Demo Digital Service 10	\N	Fictional external service link for card and homepage testing.	\N	https://example.test/services/10	4e8d90dc-7a13-4084-addf-b476da99f4e6	demo-digital-service-10	archived	f	\N	2026-01-15 08:00:00	2026-06-27 08:00:00	\N	\N	\N	10	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.394	2026-06-27 13:00:47.035
\.


--
-- Data for Name: districts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.districts (id, name_en, name_hi, slug, state, is_active, display_order, created_at, updated_at) FROM stdin;
8d3043ee-820f-4ebc-ac56-8879f8e937f4	Bokaro	\N	bokaro	Jharkhand	t	1	2026-06-27 12:55:01.991	2026-06-27 13:00:45.792
d0e08c0c-31f8-4518-a427-283419fdd90e	Chatra	\N	chatra	Jharkhand	t	2	2026-06-27 12:55:01.999	2026-06-27 13:00:45.794
12b13393-e044-48ad-b999-7c6084714e9d	Deoghar	\N	deoghar	Jharkhand	t	3	2026-06-27 12:55:02.001	2026-06-27 13:00:45.795
09fe9edc-6f60-4529-b959-8484f092de7e	Dhanbad	\N	dhanbad	Jharkhand	t	4	2026-06-27 12:55:02.003	2026-06-27 13:00:45.796
3a1ea0fb-f4dd-46ea-bcd9-4c1e8f3650f6	Dumka	\N	dumka	Jharkhand	t	5	2026-06-27 12:55:02.004	2026-06-27 13:00:45.797
3915d156-ef49-420d-a645-0f8d521cbe9d	East Singhbhum	\N	east-singhbhum	Jharkhand	t	6	2026-06-27 12:55:02.005	2026-06-27 13:00:45.797
a65e8a15-c344-4895-8329-9bd0d816efbf	Garhwa	\N	garhwa	Jharkhand	t	7	2026-06-27 12:55:02.006	2026-06-27 13:00:45.798
33e25b83-3af1-46ee-b50a-17f1eaf47a66	Giridih	\N	giridih	Jharkhand	t	8	2026-06-27 12:55:02.007	2026-06-27 13:00:45.799
5ea7f0c7-cd37-4360-ac58-de95d7eec88f	Godda	\N	godda	Jharkhand	t	9	2026-06-27 12:55:02.008	2026-06-27 13:00:45.8
a7f3f827-3863-4cb3-8ab8-2a8df83147df	Gumla	\N	gumla	Jharkhand	t	10	2026-06-27 12:55:02.009	2026-06-27 13:00:45.801
55db93f2-cda9-44ec-a882-4a8072f755ce	Hazaribagh	\N	hazaribagh	Jharkhand	t	11	2026-06-27 12:55:02.01	2026-06-27 13:00:45.802
cf0d98e7-4f40-4426-9c27-3b41649469f1	Jamtara	\N	jamtara	Jharkhand	t	12	2026-06-27 12:55:02.011	2026-06-27 13:00:45.803
c55140f4-a206-4bb4-9e40-cea4a362d3f6	Khunti	\N	khunti	Jharkhand	t	13	2026-06-27 12:55:02.013	2026-06-27 13:00:45.804
14a0996f-885f-4f55-9dc0-3ceb5bc84d31	Koderma	\N	koderma	Jharkhand	t	14	2026-06-27 12:55:02.014	2026-06-27 13:00:45.804
07f531b5-9897-440b-9083-6053fd25d936	Latehar	\N	latehar	Jharkhand	t	15	2026-06-27 12:55:02.015	2026-06-27 13:00:45.805
14c04e14-a4be-404c-a2af-c306add55b0d	Lohardaga	\N	lohardaga	Jharkhand	t	16	2026-06-27 12:55:02.016	2026-06-27 13:00:45.806
34adfbeb-9da7-40df-beae-6efef59458e6	Pakur	\N	pakur	Jharkhand	t	17	2026-06-27 12:55:02.018	2026-06-27 13:00:45.807
8d81689c-b74b-44fb-bedb-3e07ec044ef4	Palamu	\N	palamu	Jharkhand	t	18	2026-06-27 12:55:02.019	2026-06-27 13:00:45.808
064a1b93-7c4c-4357-a140-d06d7b378b2b	Ramgarh	\N	ramgarh	Jharkhand	t	19	2026-06-27 12:55:02.02	2026-06-27 13:00:45.809
7e07b268-f055-4f23-9a1c-2a9923e08f67	Ranchi	\N	ranchi	Jharkhand	t	20	2026-06-27 12:55:02.02	2026-06-27 13:00:45.809
2eb8b17a-4c52-4c7e-a2b0-fffe9aabb3e5	Sahibganj	\N	sahibganj	Jharkhand	t	21	2026-06-27 12:55:02.021	2026-06-27 13:00:45.81
b046ca98-5a72-48e6-a3d6-8605c68f2eeb	Seraikela Kharsawan	\N	seraikela-kharsawan	Jharkhand	t	22	2026-06-27 12:55:02.022	2026-06-27 13:00:45.811
78b8972a-2db3-40bb-b8ba-4cefb357aff7	Simdega	\N	simdega	Jharkhand	t	23	2026-06-27 12:55:02.023	2026-06-27 13:00:45.812
ed28dfdf-d0ae-46b7-a3e4-20d001079088	West Singhbhum	\N	west-singhbhum	Jharkhand	t	24	2026-06-27 12:55:02.024	2026-06-27 13:00:45.813
\.


--
-- Data for Name: document_commodities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_commodities (id, document_id, commodity_id) FROM stdin;
8c8c51e8-2985-4cef-99c9-32371303b533	7944c41a-0cfa-4b43-a262-d498bd509c7e	29abba96-aa2b-49b5-ba07-d75f2ce64932
85c32428-99eb-4a28-b830-2aecac47d883	623abf9f-5986-42a1-bf2e-19ef4dd44ae4	d5302db1-d57e-4d7c-85ad-bf3dbc6db6e5
28f7be54-debb-4c15-bd0c-26f613331706	cc5052f0-2a3b-4122-85f2-54e91fe0e409	b4873f7f-544f-42c3-855e-2810c7970236
9c0706c1-130d-49ae-9a98-5a6c1a81ba36	5fa1f9d9-bb93-4e97-bace-309f87178155	cffc6a8c-ed36-4163-aab4-2417904ca859
82e31542-10d5-44cb-a4f8-3bb2a399898c	a718689f-92f0-4279-ae77-a975a854d6db	df849f1b-b168-45a9-a1cb-40139f8d225d
21718c69-9827-40c3-9c41-5ea051c0ce61	16a09d86-3153-4a7a-8071-b2d5968e80dd	4f276af1-d981-4294-9f50-fbcdf2c979c2
f5650f4b-0352-43e4-b18f-c8c105c24c26	2c366c39-c9ef-4a33-a676-5bfa04ab9305	29abba96-aa2b-49b5-ba07-d75f2ce64932
d0c2646d-1c53-456d-a1dc-b4bfe0b0d774	e326d4f8-140b-4f04-b43e-8790b44b3860	d5302db1-d57e-4d7c-85ad-bf3dbc6db6e5
3d31ecd2-6c4b-4d30-bc60-9e507ba11244	d223a5d9-ff95-4736-9292-727d62dde24a	b4873f7f-544f-42c3-855e-2810c7970236
568155dc-2561-46d4-9013-00e986bf16e2	3cd791ca-0192-4685-8332-78c2bce1ed4c	cffc6a8c-ed36-4163-aab4-2417904ca859
8d8ac71c-a439-44d3-a26b-f1bc8c71cfeb	151d0a3f-bddb-4ba2-8943-d788078de702	df849f1b-b168-45a9-a1cb-40139f8d225d
485df6b5-1faf-4b2b-b6ac-344a216bd75e	82b43929-43c0-40dd-bb89-0cc1eab52785	4f276af1-d981-4294-9f50-fbcdf2c979c2
2cf76e91-a8ed-4c9b-85e6-2da3fe87f2be	14ad3aa8-b254-462f-a976-66377504499b	29abba96-aa2b-49b5-ba07-d75f2ce64932
8b04aa2c-f6b7-403c-81c8-3d6571ed964b	01b37620-3a5f-45f5-9266-742ca492973c	d5302db1-d57e-4d7c-85ad-bf3dbc6db6e5
74f2796d-f0d5-4cad-a4dd-d59d2296e945	073f9d96-b171-4a77-8d40-d66943da389c	b4873f7f-544f-42c3-855e-2810c7970236
c1aaf7ea-9198-428a-9bd9-4dba08d9900e	8a15342c-2f4d-416b-b06b-3cfec936d223	cffc6a8c-ed36-4163-aab4-2417904ca859
f0d35d9a-2309-4d5a-a31f-713d57398cfe	fc5c00bd-3cb6-474a-aa74-dc66033a6856	df849f1b-b168-45a9-a1cb-40139f8d225d
7199fcd4-0d39-44da-94c6-30aed60075c2	bbb19a3e-0968-405e-ae86-0c0cf75fe756	4f276af1-d981-4294-9f50-fbcdf2c979c2
\.


--
-- Data for Name: document_districts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_districts (id, document_id, district_id) FROM stdin;
3f889b0d-bb22-4204-96ee-d86399011080	7944c41a-0cfa-4b43-a262-d498bd509c7e	8d3043ee-820f-4ebc-ac56-8879f8e937f4
5a24e92b-c8a1-4086-bb50-c93ccc4f63d4	623abf9f-5986-42a1-bf2e-19ef4dd44ae4	d0e08c0c-31f8-4518-a427-283419fdd90e
5b3227cf-4f66-4ded-b5fd-62506a2f9c7b	cc5052f0-2a3b-4122-85f2-54e91fe0e409	12b13393-e044-48ad-b999-7c6084714e9d
c5f40070-d3d7-4461-a3ea-1215e2faf794	5fa1f9d9-bb93-4e97-bace-309f87178155	09fe9edc-6f60-4529-b959-8484f092de7e
51bcc86a-5e1c-4810-b203-82a57498f808	a718689f-92f0-4279-ae77-a975a854d6db	3a1ea0fb-f4dd-46ea-bcd9-4c1e8f3650f6
c6c50792-0e29-4af6-b06c-cd17df19560a	16a09d86-3153-4a7a-8071-b2d5968e80dd	3915d156-ef49-420d-a645-0f8d521cbe9d
0de75720-1512-4616-99ec-eeeec3fa6746	2c366c39-c9ef-4a33-a676-5bfa04ab9305	a65e8a15-c344-4895-8329-9bd0d816efbf
13cb9369-a024-447b-a8ec-647d82025b8d	e326d4f8-140b-4f04-b43e-8790b44b3860	33e25b83-3af1-46ee-b50a-17f1eaf47a66
c71e970d-2e43-4643-8c51-36bd70293597	d223a5d9-ff95-4736-9292-727d62dde24a	5ea7f0c7-cd37-4360-ac58-de95d7eec88f
e00e8b4b-5563-4315-8f22-9a619876c1f3	3cd791ca-0192-4685-8332-78c2bce1ed4c	a7f3f827-3863-4cb3-8ab8-2a8df83147df
496ada73-a25c-46e3-8aca-d3658053745e	151d0a3f-bddb-4ba2-8943-d788078de702	55db93f2-cda9-44ec-a882-4a8072f755ce
6fd68029-ac03-4ee7-af4f-6ed5bae32ac1	82b43929-43c0-40dd-bb89-0cc1eab52785	cf0d98e7-4f40-4426-9c27-3b41649469f1
5b1f1a5e-635d-4493-b825-1c8bcbbfbf49	14ad3aa8-b254-462f-a976-66377504499b	c55140f4-a206-4bb4-9e40-cea4a362d3f6
fb76ed9d-83cd-499d-a57c-ace7d7b63b82	01b37620-3a5f-45f5-9266-742ca492973c	14a0996f-885f-4f55-9dc0-3ceb5bc84d31
19af2c64-ccc4-40e3-b446-fb2641a6081f	073f9d96-b171-4a77-8d40-d66943da389c	07f531b5-9897-440b-9083-6053fd25d936
fab6bbab-0baa-479e-bac0-4fac96d3464e	8a15342c-2f4d-416b-b06b-3cfec936d223	14c04e14-a4be-404c-a2af-c306add55b0d
cf06a6e3-6bed-4cd8-b55b-2e9adca46c48	fc5c00bd-3cb6-474a-aa74-dc66033a6856	34adfbeb-9da7-40df-beae-6efef59458e6
15655b8b-cbd3-423b-8523-47e2022d5900	bbb19a3e-0968-405e-ae86-0c0cf75fe756	8d81689c-b74b-44fb-bedb-3e07ec044ef4
\.


--
-- Data for Name: document_institutions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_institutions (id, document_id, institution_id) FROM stdin;
351fc693-66aa-40bb-9023-39b0ec0329cc	7944c41a-0cfa-4b43-a262-d498bd509c7e	a7882c7b-b339-405a-98ff-787ea22af71e
7e532eb4-b3c3-4943-9ea2-cfd8ae4f335a	623abf9f-5986-42a1-bf2e-19ef4dd44ae4	76216f41-cbea-4f28-af6e-325511eec36b
17a6243f-eb95-4dbf-9576-ae74d075baaa	cc5052f0-2a3b-4122-85f2-54e91fe0e409	4a4f9cba-ad6a-42ca-a33a-51c237b24959
c847cb17-4d93-4960-85e0-409ef64ea58e	5fa1f9d9-bb93-4e97-bace-309f87178155	eb467702-6b19-4e1a-91bb-8e0b6f8846b5
5aadd793-deca-4b03-a282-2d3b595e3e14	a718689f-92f0-4279-ae77-a975a854d6db	1ba549fe-161d-41c1-8df5-6ac141b9a203
d943df37-1006-4ef0-b8e5-95c3a94f5416	16a09d86-3153-4a7a-8071-b2d5968e80dd	8e19a717-50c2-4a26-b973-a6886b536573
7d02983c-f3f3-42b2-9d88-1cc987e0bb20	2c366c39-c9ef-4a33-a676-5bfa04ab9305	0e9b51f2-f393-4f8d-a004-2d22190ab744
65dcecf6-9b04-40f8-9b5f-c809554b8f21	e326d4f8-140b-4f04-b43e-8790b44b3860	aaaf27d6-9868-4bff-b595-e86bf092a2f1
25198518-ad3a-432b-8436-2c9322688fb7	d223a5d9-ff95-4736-9292-727d62dde24a	ae84e287-f81d-44ed-86ce-129141d2f407
c2136c5b-d31d-417d-80f3-fdd7d1537d74	3cd791ca-0192-4685-8332-78c2bce1ed4c	bff1ae9a-2a5e-4ade-970a-2b2e5d2b66e3
2578d088-905d-489c-b050-3ba162b807b4	151d0a3f-bddb-4ba2-8943-d788078de702	4eb59158-f8ac-44c5-aa57-21c73ace31b2
c62456fa-52ca-43aa-ac43-26155e376e30	82b43929-43c0-40dd-bb89-0cc1eab52785	a7934626-a21d-48ad-967c-7cb38d69d4b3
ff2841c9-3a2f-4d34-a9cb-e30d97252d51	14ad3aa8-b254-462f-a976-66377504499b	a7882c7b-b339-405a-98ff-787ea22af71e
69bbef04-dd25-4758-9c8e-2930c84eb8d3	01b37620-3a5f-45f5-9266-742ca492973c	76216f41-cbea-4f28-af6e-325511eec36b
e769dedd-621c-468b-8d1f-49afdeaa9082	073f9d96-b171-4a77-8d40-d66943da389c	4a4f9cba-ad6a-42ca-a33a-51c237b24959
df861fb4-8a2f-486d-8f82-000c7c6bcf4b	8a15342c-2f4d-416b-b06b-3cfec936d223	eb467702-6b19-4e1a-91bb-8e0b6f8846b5
100c50ef-33c1-4f90-a1b2-f22b8b5f029f	fc5c00bd-3cb6-474a-aa74-dc66033a6856	1ba549fe-161d-41c1-8df5-6ac141b9a203
ac7d8f12-2318-4a6a-9bb0-0bd8c3b69bc7	bbb19a3e-0968-405e-ae86-0c0cf75fe756	8e19a717-50c2-4a26-b973-a6886b536573
\.


--
-- Data for Name: document_programmes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_programmes (id, document_id, programme_scheme_id) FROM stdin;
d5f66a47-8261-4661-8687-378758a115ce	7944c41a-0cfa-4b43-a262-d498bd509c7e	22fcb9e5-5190-4635-ab71-825976847e51
b6848992-ed39-4d06-8ff1-04fdecdfef52	623abf9f-5986-42a1-bf2e-19ef4dd44ae4	d89d19c1-31ed-488f-a792-88de2325f352
862aa25a-b0cd-422e-b346-c65cc1854304	cc5052f0-2a3b-4122-85f2-54e91fe0e409	9867c29c-3ebf-41b0-98a8-221efcd86aca
b4a189c2-60bd-4152-ae37-ac177741e5a9	5fa1f9d9-bb93-4e97-bace-309f87178155	27a6b58a-a27a-4445-9ae4-1db0f6c6c223
c75c8dcb-59d6-4b02-ae55-5d02cbc16a82	a718689f-92f0-4279-ae77-a975a854d6db	cf87cfda-4657-46ab-8dc3-5f2c288b52a1
6832e3c6-3082-4e46-9b97-a785bd0cace4	16a09d86-3153-4a7a-8071-b2d5968e80dd	edf6864c-2bd3-4a15-8a3c-7b23c3407be0
bd742889-84bb-4ed5-915f-f3b47ce7d23f	2c366c39-c9ef-4a33-a676-5bfa04ab9305	f2418002-8794-4079-a380-4dc3f810aafa
bdf617ef-c56d-4522-b27c-724a97391f48	e326d4f8-140b-4f04-b43e-8790b44b3860	fbbc4562-43a7-4015-9d4d-31ec23f1fcd0
98b07e96-1b55-43bf-b7fc-46f728cf132d	d223a5d9-ff95-4736-9292-727d62dde24a	d6dcdc56-84dc-4d87-990a-986e8ded46fb
624c7d92-795a-4393-b72b-e147ae265f1a	3cd791ca-0192-4685-8332-78c2bce1ed4c	e5427a51-68a7-4fbe-b618-3378361218a7
25ea4f61-d809-4e2d-8f6b-2cead8f7d66e	151d0a3f-bddb-4ba2-8943-d788078de702	22fcb9e5-5190-4635-ab71-825976847e51
52182b1f-cdf2-4bd9-bf3a-6d1e085ef090	82b43929-43c0-40dd-bb89-0cc1eab52785	d89d19c1-31ed-488f-a792-88de2325f352
337ccf9d-deac-451a-89ac-6c40c2b8af11	14ad3aa8-b254-462f-a976-66377504499b	9867c29c-3ebf-41b0-98a8-221efcd86aca
4195dd44-73b6-4ecf-af34-d4ed30538bb8	01b37620-3a5f-45f5-9266-742ca492973c	27a6b58a-a27a-4445-9ae4-1db0f6c6c223
a570ae74-2919-4019-8b56-bfb8be995b9e	073f9d96-b171-4a77-8d40-d66943da389c	cf87cfda-4657-46ab-8dc3-5f2c288b52a1
c7eeea00-335b-4858-8b91-51878386cf5b	8a15342c-2f4d-416b-b06b-3cfec936d223	edf6864c-2bd3-4a15-8a3c-7b23c3407be0
c0b68142-761e-4012-a0e4-729d353f68f0	fc5c00bd-3cb6-474a-aa74-dc66033a6856	f2418002-8794-4079-a380-4dc3f810aafa
c701685d-f47d-48f4-a301-e269d136f6f4	bbb19a3e-0968-405e-ae86-0c0cf75fe756	fbbc4562-43a7-4015-9d4d-31ec23f1fcd0
\.


--
-- Data for Name: document_tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_tags (id, document_id, tag_id) FROM stdin;
7d610025-8176-4a9e-b2f1-19ca213b6c27	7944c41a-0cfa-4b43-a262-d498bd509c7e	5dc047c4-f3f9-4ca4-98f2-148fd2c54a57
097265ae-bd71-4442-9a3b-33ae69991428	623abf9f-5986-42a1-bf2e-19ef4dd44ae4	bf95bd6c-a3be-4411-aae7-46f2538356bd
58b5dc52-a195-4633-a7cb-c0ee23294cd5	cc5052f0-2a3b-4122-85f2-54e91fe0e409	faeb0032-27da-4135-9b5f-e9b459bca286
e3af6825-14f6-41d9-925a-a9db1b0cbf7c	5fa1f9d9-bb93-4e97-bace-309f87178155	20323969-dfd0-4c48-9110-0b01ff01db38
434bf249-49cf-4742-9620-4c1d314df1aa	a718689f-92f0-4279-ae77-a975a854d6db	3b750363-0a23-453e-a994-99e822372d4d
30c26981-e579-40be-9053-d56853e9fb04	16a09d86-3153-4a7a-8071-b2d5968e80dd	da31bd72-846a-400b-a9db-71cee53fc8c7
4d71268b-457c-4046-adb6-f5840b65964f	2c366c39-c9ef-4a33-a676-5bfa04ab9305	54e9b49e-78af-48da-8b81-2972b70ddadb
f159b3c1-127b-43d6-beca-5388b4277022	e326d4f8-140b-4f04-b43e-8790b44b3860	916c7a1c-25c6-4e06-bc21-fb648e749155
d6e43259-cff5-4942-8614-0c55f802adb3	d223a5d9-ff95-4736-9292-727d62dde24a	e52ede18-9e93-45c6-9b7b-785c0ed345b8
d6b208ec-82fe-4529-a832-560a1b59dcfb	3cd791ca-0192-4685-8332-78c2bce1ed4c	020b2af1-be29-460e-a04c-7db48eca5629
31fe3004-bf96-4c6f-a9aa-61f615e7cd35	151d0a3f-bddb-4ba2-8943-d788078de702	8fe861d8-5643-406d-a755-67e3c41e49a4
e7ce8964-2108-461c-aac3-2a37d3d7299c	82b43929-43c0-40dd-bb89-0cc1eab52785	6f39163d-11eb-41cd-8896-5bb3b7fe1b42
998218bd-dc6b-4fd3-b856-b85b187eb71c	14ad3aa8-b254-462f-a976-66377504499b	5dc047c4-f3f9-4ca4-98f2-148fd2c54a57
bc2faf91-d18d-49b1-8f07-aab65c390b69	01b37620-3a5f-45f5-9266-742ca492973c	bf95bd6c-a3be-4411-aae7-46f2538356bd
18aacbf9-a84e-49af-b0ed-8b4aff33f00c	073f9d96-b171-4a77-8d40-d66943da389c	faeb0032-27da-4135-9b5f-e9b459bca286
948741b6-83cf-4e49-a805-258c51d6155c	8a15342c-2f4d-416b-b06b-3cfec936d223	20323969-dfd0-4c48-9110-0b01ff01db38
a3dc1641-c10d-4e91-847b-fe85b207ad6f	fc5c00bd-3cb6-474a-aa74-dc66033a6856	3b750363-0a23-453e-a994-99e822372d4d
cbd044af-11d8-481f-ba77-81fa496b5466	bbb19a3e-0968-405e-ae86-0c0cf75fe756	da31bd72-846a-400b-a9db-71cee53fc8c7
\.


--
-- Data for Name: document_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_types (id, name_en, name_hi, slug, is_active, display_order, created_at, updated_at) FROM stdin;
861a94c4-78f9-47ad-90e2-c97916b950f6	Notice	\N	notice	t	1	2026-06-27 12:55:01.939	2026-06-27 13:00:45.755
f3073fcf-426c-4716-8c4d-7e272dbdc702	Circular	\N	circular	t	2	2026-06-27 12:55:01.942	2026-06-27 13:00:45.756
d62afb5d-5505-4207-9d4f-f8c9965444c5	Office Order	\N	office-order	t	3	2026-06-27 12:55:01.943	2026-06-27 13:00:45.757
0d1f9fee-404e-4cc6-bbf0-dfb098ecc45e	MoU	\N	mou	t	4	2026-06-27 12:55:01.943	2026-06-27 13:00:45.758
f987fc18-b1b0-48c7-b1c5-8f0d87103bf0	Report	\N	report	t	5	2026-06-27 12:55:01.944	2026-06-27 13:00:45.758
92b677ae-7c00-4e87-be2d-b713c3de41b3	Policy	\N	policy	t	6	2026-06-27 12:55:01.944	2026-06-27 13:00:45.759
9465e215-1953-4ffa-8d9e-15c3200d7f23	Guideline	\N	guideline	t	7	2026-06-27 12:55:01.945	2026-06-27 13:00:45.76
75cf4c93-903c-4002-b32b-748e614f09f0	SOP	\N	sop	t	8	2026-06-27 12:55:01.945	2026-06-27 13:00:45.761
e235da17-fc10-4f9d-8457-e9fb1cfe5414	Training Material	\N	training-material	t	9	2026-06-27 12:55:01.946	2026-06-27 13:00:45.762
2bbab1d1-0202-4754-9268-e4726e950a4d	Form	\N	form	t	10	2026-06-27 12:55:01.947	2026-06-27 13:00:45.762
28ff47bb-d0ce-4bd6-a2d9-cb3bb7219257	Publication	\N	publication	t	11	2026-06-27 12:55:01.948	2026-06-27 13:00:45.763
f5e246ab-2490-4d40-bfd3-205a077eaf8d	Other	\N	other	t	12	2026-06-27 12:55:01.948	2026-06-27 13:00:45.763
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.documents (id, title_en, title_hi, description_en, description_hi, document_type_id, file_asset_id, publication_date, language, is_public, show_in_knowledge_centre, knowledge_category_id, financial_year_id, slug, publication_state, public_visibility, publish_start_at, published_at, archived_at, highlight_type, highlight_start_at, highlight_end_at, display_order, show_on_homepage, created_by, updated_by, created_at, updated_at) FROM stdin;
a718689f-92f0-4279-ae77-a975a854d6db	Demo Report Publication 5	डेमो दस्तावेज़ 5	Fictional karanj reference document for API testing.	\N	f987fc18-b1b0-48c7-b1c5-8f0d87103bf0	69b7fec3-5b90-4b98-9c26-b04ef0192afe	2025-05-15	hi	t	t	44a76805-9117-41d9-b4ec-330842046640	d199ab88-ee7a-4503-b573-dbb8a3abf773	demo-publication-5	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	5	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.68	2026-06-27 13:00:46.405
16a09d86-3153-4a7a-8071-b2d5968e80dd	Demo Policy Publication 6	\N	Fictional tamarind reference document for API testing.	\N	92b677ae-7c00-4e87-be2d-b713c3de41b3	de5fd4a9-fbf1-451c-80f2-93295dcf4d28	2026-06-15	en	t	t	409ae789-523d-447e-9e94-698279c1d7e6	523d4ffa-be85-4db3-90d7-37a50efa298e	demo-publication-6	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	6	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.698	2026-06-27 13:00:46.417
2c366c39-c9ef-4a33-a676-5bfa04ab9305	Demo Guideline Publication 7	डेमो दस्तावेज़ 7	Fictional lac reference document for API testing.	यह परीक्षण हेतु काल्पनिक दस्तावेज़ है।	9465e215-1953-4ffa-8d9e-15c3200d7f23	cfb8b062-b6e6-4274-a4f7-0adddce1348c	2024-07-15	en	t	t	348358c4-448f-4c1f-b5ec-a87275f6413c	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	demo-publication-7	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	7	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.723	2026-06-27 13:00:46.425
e326d4f8-140b-4f04-b43e-8790b44b3860	Demo SOP Publication 8	\N	Fictional honey reference document for API testing.	\N	75cf4c93-903c-4002-b32b-748e614f09f0	73bfc8f4-6e96-430d-8332-94d10ebba3c9	2025-08-15	en	t	t	a7afb135-3e39-4646-b093-93d1e3c14d35	86387c48-e2fb-4c68-9de5-0a953467da42	demo-publication-8	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	8	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.743	2026-06-27 13:00:46.437
d223a5d9-ff95-4736-9292-727d62dde24a	Demo Training Material Publication 9	डेमो दस्तावेज़ 9	Fictional ragi / millets reference document for API testing.	\N	e235da17-fc10-4f9d-8457-e9fb1cfe5414	81cff119-5479-482d-83c7-a5317fbcf900	2026-09-15	hi	t	t	da77b564-874f-4703-9e58-5e10cc1652d2	d199ab88-ee7a-4503-b573-dbb8a3abf773	demo-publication-9	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	9	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.75	2026-06-27 13:00:46.445
3cd791ca-0192-4685-8332-78c2bce1ed4c	Demo Form Publication 10	\N	Fictional sal seed reference document for API testing.	यह परीक्षण हेतु काल्पनिक दस्तावेज़ है।	2bbab1d1-0202-4754-9268-e4726e950a4d	07c52317-ecee-4def-99c8-5d2976095090	2024-01-15	en	t	t	0ec3b836-f2cd-44fd-a200-36d747d669cb	523d4ffa-be85-4db3-90d7-37a50efa298e	demo-publication-10	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	10	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.757	2026-06-27 13:00:46.451
151d0a3f-bddb-4ba2-8943-d788078de702	Demo Publication Publication 11	डेमो दस्तावेज़ 11	Fictional karanj reference document for API testing.	\N	28ff47bb-d0ce-4bd6-a2d9-cb3bb7219257	c1fc235a-d72b-4a7e-affe-b1612bfd0c15	2025-02-15	en	t	t	644c06bc-eb92-403a-a9f7-e75369c08837	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	demo-publication-11	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	11	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.77	2026-06-27 13:00:46.458
82b43929-43c0-40dd-bb89-0cc1eab52785	Demo Other Publication 12	\N	Fictional tamarind reference document for API testing.	\N	f5e246ab-2490-4d40-bfd3-205a077eaf8d	30445ff8-6684-4033-8d12-b405784c427e	2026-03-15	en	t	t	6d84947e-0002-44be-90e2-c9e42058656f	86387c48-e2fb-4c68-9de5-0a953467da42	demo-publication-12	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	12	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.777	2026-06-27 13:00:46.482
01b37620-3a5f-45f5-9266-742ca492973c	Demo Circular Publication 14	\N	Fictional honey reference document for API testing.	\N	f3073fcf-426c-4716-8c4d-7e272dbdc702	6e1e1724-d6ec-4752-9ecb-c6dfe688a983	2025-05-15	en	t	f	\N	523d4ffa-be85-4db3-90d7-37a50efa298e	demo-publication-14	unpublished	t	\N	\N	\N	\N	\N	\N	14	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.789	2026-06-27 13:00:46.501
623abf9f-5986-42a1-bf2e-19ef4dd44ae4	Demo Circular Publication 2	\N	Fictional honey reference document for API testing.	\N	f3073fcf-426c-4716-8c4d-7e272dbdc702	6e1e1724-d6ec-4752-9ecb-c6dfe688a983	2025-02-15	en	t	t	0ec3b836-f2cd-44fd-a200-36d747d669cb	523d4ffa-be85-4db3-90d7-37a50efa298e	demo-publication-2	published	t	\N	2026-01-15 08:00:00	\N	latest	2026-01-15 08:00:00	2027-01-15 08:00:00	2	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.601	2026-06-27 13:00:46.335
cc5052f0-2a3b-4122-85f2-54e91fe0e409	Demo Office Order Publication 3	डेमो दस्तावेज़ 3	Fictional ragi / millets reference document for API testing.	\N	d62afb5d-5505-4207-9d4f-f8c9965444c5	78c8d293-5fee-4db9-aa09-e8ba50848dc6	2026-03-15	en	t	t	644c06bc-eb92-403a-a9f7-e75369c08837	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	demo-publication-3	published	t	\N	2026-01-15 08:00:00	\N	important	2026-01-15 08:00:00	2027-01-15 08:00:00	3	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.62	2026-06-27 13:00:46.361
5fa1f9d9-bb93-4e97-bace-309f87178155	Demo MoU Publication 4	\N	Fictional sal seed reference document for API testing.	यह परीक्षण हेतु काल्पनिक दस्तावेज़ है।	0d1f9fee-404e-4cc6-bbf0-dfb098ecc45e	149ddd8c-6d46-4f4f-925a-1bccdb033971	2024-04-15	en	t	t	6d84947e-0002-44be-90e2-c9e42058656f	86387c48-e2fb-4c68-9de5-0a953467da42	demo-publication-4	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	4	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.645	2026-06-27 13:00:46.38
14ad3aa8-b254-462f-a976-66377504499b	Demo Notice Publication 13	डेमो दस्तावेज़ 13	Fictional lac reference document for API testing.	यह परीक्षण हेतु काल्पनिक दस्तावेज़ है।	861a94c4-78f9-47ad-90e2-c97916b950f6	6536380f-9b03-46ff-85d7-4ab271ef2d17	2024-04-15	hi	t	f	\N	d199ab88-ee7a-4503-b573-dbb8a3abf773	demo-publication-13	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	13	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.783	2026-06-27 13:00:46.494
8a15342c-2f4d-416b-b06b-3cfec936d223	Demo MoU Publication 16	\N	Fictional sal seed reference document for API testing.	यह परीक्षण हेतु काल्पनिक दस्तावेज़ है।	0d1f9fee-404e-4cc6-bbf0-dfb098ecc45e	149ddd8c-6d46-4f4f-925a-1bccdb033971	2024-07-15	en	f	f	\N	86387c48-e2fb-4c68-9de5-0a953467da42	demo-publication-16	published	f	\N	2026-01-15 08:00:00	\N	\N	\N	\N	16	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.81	2026-06-27 13:00:46.52
073f9d96-b171-4a77-8d40-d66943da389c	Demo Office Order Publication 15	डेमो दस्तावेज़ 15	Fictional ragi / millets reference document for API testing.	\N	d62afb5d-5505-4207-9d4f-f8c9965444c5	78c8d293-5fee-4db9-aa09-e8ba50848dc6	2026-06-15	en	t	f	\N	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	demo-publication-15	published	t	2027-01-15 08:00:00	2026-01-15 08:00:00	\N	\N	\N	\N	15	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.796	2026-06-27 13:00:46.508
fc5c00bd-3cb6-474a-aa74-dc66033a6856	Demo Report Publication 17	डेमो दस्तावेज़ 17	Fictional karanj reference document for API testing.	\N	f987fc18-b1b0-48c7-b1c5-8f0d87103bf0	69b7fec3-5b90-4b98-9c26-b04ef0192afe	2025-08-15	hi	t	f	\N	d199ab88-ee7a-4503-b573-dbb8a3abf773	demo-publication-17	draft	t	\N	\N	\N	\N	\N	\N	17	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.816	2026-06-27 13:00:46.526
bbb19a3e-0968-405e-ae86-0c0cf75fe756	Demo Policy Publication 18	\N	Fictional tamarind reference document for API testing.	\N	92b677ae-7c00-4e87-be2d-b713c3de41b3	de5fd4a9-fbf1-451c-80f2-93295dcf4d28	2026-09-15	en	t	f	\N	523d4ffa-be85-4db3-90d7-37a50efa298e	demo-publication-18	archived	f	\N	2026-01-15 08:00:00	2026-06-27 08:00:00	\N	\N	\N	18	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.822	2026-06-27 13:00:46.532
7944c41a-0cfa-4b43-a262-d498bd509c7e	Demo Notice Publication 1	डेमो दस्तावेज़ 1	Fictional lac reference document for API testing.	यह परीक्षण हेतु काल्पनिक दस्तावेज़ है।	861a94c4-78f9-47ad-90e2-c97916b950f6	6536380f-9b03-46ff-85d7-4ab271ef2d17	2024-01-15	hi	t	t	da77b564-874f-4703-9e58-5e10cc1652d2	d199ab88-ee7a-4503-b573-dbb8a3abf773	demo-publication-1	published	t	\N	2026-01-15 08:00:00	\N	featured	2026-01-15 08:00:00	2027-01-15 08:00:00	1	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.521	2026-06-27 13:00:46.261
\.


--
-- Data for Name: enquiries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.enquiries (id, enquiry_type_id, name, mobile, email, subject, message, organization, commodity_id, programme_scheme_id, submitted_at, source_ip_hash, spam_state, internal_notes, archived_at, created_at, updated_at) FROM stdin;
3e82ef19-03d2-459f-81d0-cbbe8167733d	09e3b13a-ce17-465a-958f-eae7a9a4206d	Demo Enquirer 1	9000000001	enquirer1@example.test	Fictional enquiry about Lac	This is a fictional enquiry created for CMS administration and export testing.	Demo Cooperative 1	29abba96-aa2b-49b5-ba07-d75f2ce64932	22fcb9e5-5190-4635-ab71-825976847e51	2026-06-01 10:00:00	566ce06475b63c3e4ba49cee5c3fee651995eb5f6fe8c4f83490513cc2bede3b	clean	Fixture follow-up note.	\N	2026-06-27 12:55:03.467	2026-06-27 13:00:47.085
5729cac3-77e2-4502-9115-fc8117c9a606	d4eec28e-33e1-4363-95f2-888316d9a69e	Demo Enquirer 2	9000000002	enquirer2@example.test	Fictional enquiry about Honey	This is a fictional enquiry created for CMS administration and export testing.	\N	d5302db1-d57e-4d7c-85ad-bf3dbc6db6e5	d89d19c1-31ed-488f-a792-88de2325f352	2026-06-02 10:00:00	0696a19ce8536f37b128645537a9e01384c43131360ddf66cea7dc7343474700	clean	\N	\N	2026-06-27 12:55:03.473	2026-06-27 13:00:47.087
d788ba30-92ef-459c-8c75-6430432885c4	fa28a9c7-208c-4a9f-805e-e79718c0dcf6	Demo Enquirer 3	9000000003	enquirer3@example.test	Fictional enquiry about Ragi / Millets	This is a fictional enquiry created for CMS administration and export testing.	Demo Cooperative 3	b4873f7f-544f-42c3-855e-2810c7970236	9867c29c-3ebf-41b0-98a8-221efcd86aca	2026-06-03 10:00:00	fc074ca222fd7a1cb8676dff65db1814fc9c62edf169e4615b433bc21bdb4d88	clean	\N	\N	2026-06-27 12:55:03.474	2026-06-27 13:00:47.089
05e2fd2d-008d-4f64-9cd0-97807fed2c7c	43dfef2f-755d-42c0-be2e-bbfd7320d57a	Demo Enquirer 4	9000000004	enquirer4@example.test	Fictional enquiry about Sal Seed	This is a fictional enquiry created for CMS administration and export testing.	\N	cffc6a8c-ed36-4163-aab4-2417904ca859	27a6b58a-a27a-4445-9ae4-1db0f6c6c223	2026-06-04 10:00:00	2d017feb4cce285c5913339e884d9de57540d71d7d2d7b351a69a05b3b239304	clean	\N	\N	2026-06-27 12:55:03.476	2026-06-27 13:00:47.09
22cbf10e-ab9f-498f-b235-a2c106459e16	eb3173d6-01b3-4548-a8d3-db877561f728	Demo Enquirer 5	9000000005	enquirer5@example.test	Fictional enquiry about Karanj	This is a fictional enquiry created for CMS administration and export testing.	Demo Cooperative 5	df849f1b-b168-45a9-a1cb-40139f8d225d	cf87cfda-4657-46ab-8dc3-5f2c288b52a1	2026-06-05 10:00:00	523ab5794167837b672d170eb3ef72e3b5fcd2dd951ffd1fb435b9a3e34db8b3	clean	\N	\N	2026-06-27 12:55:03.478	2026-06-27 13:00:47.091
192282f3-720d-417e-95a3-007f7af4b751	0141dab7-3661-4d68-a789-54c41e591323	Demo Enquirer 6	9000000006	enquirer6@example.test	Fictional enquiry about Tamarind	This is a fictional enquiry created for CMS administration and export testing.	\N	4f276af1-d981-4294-9f50-fbcdf2c979c2	edf6864c-2bd3-4a15-8a3c-7b23c3407be0	2026-06-06 10:00:00	8d9851fcc944949a56b71dadd90c202e69d80afccf896d119186d7d881b47c2d	clean	Fixture follow-up note.	\N	2026-06-27 12:55:03.479	2026-06-27 13:00:47.092
7b3cb71b-c305-431d-a52e-5c80d38a4c64	09e3b13a-ce17-465a-958f-eae7a9a4206d	Demo Enquirer 7	9000000007	enquirer7@example.test	Fictional enquiry about Lac	This is a fictional enquiry created for CMS administration and export testing.	Demo Cooperative 7	29abba96-aa2b-49b5-ba07-d75f2ce64932	f2418002-8794-4079-a380-4dc3f810aafa	2026-06-07 10:00:00	2df728a7da3b3df738b89e145e72eded979445aeedc7a3b2bf8c38440786aece	clean	\N	\N	2026-06-27 12:55:03.481	2026-06-27 13:00:47.093
f220574d-b18c-444d-b901-63a977d6012a	d4eec28e-33e1-4363-95f2-888316d9a69e	Demo Enquirer 8	9000000008	enquirer8@example.test	Fictional enquiry about Honey	This is a fictional enquiry created for CMS administration and export testing.	\N	d5302db1-d57e-4d7c-85ad-bf3dbc6db6e5	fbbc4562-43a7-4015-9d4d-31ec23f1fcd0	2026-06-08 10:00:00	f2bd0e83c10f9b2c00605bb7da8ec47a82d583cb5ddba90506eb5d6cf5bbd2f1	clean	\N	\N	2026-06-27 12:55:03.482	2026-06-27 13:00:47.094
4cb3028e-1e24-4809-aa82-d659351d3548	fa28a9c7-208c-4a9f-805e-e79718c0dcf6	Demo Enquirer 9	9000000009	enquirer9@example.test	Fictional enquiry about Ragi / Millets	This is a fictional enquiry created for CMS administration and export testing.	Demo Cooperative 9	b4873f7f-544f-42c3-855e-2810c7970236	d6dcdc56-84dc-4d87-990a-986e8ded46fb	2026-06-09 10:00:00	1bcfc95b199092daa07b4d315f28031ff4d57bc55389395482081369e09f501a	clean	\N	\N	2026-06-27 12:55:03.483	2026-06-27 13:00:47.096
7cccb781-1aeb-4bdc-8dd2-49296d03dc57	43dfef2f-755d-42c0-be2e-bbfd7320d57a	Demo Enquirer 10	9000000010	enquirer10@example.test	Fictional enquiry about Sal Seed	This is a fictional enquiry created for CMS administration and export testing.	\N	cffc6a8c-ed36-4163-aab4-2417904ca859	e5427a51-68a7-4fbe-b618-3378361218a7	2026-06-10 10:00:00	6c8168f09bef8ca51bbbe18caa00a002fa07665dc0e0573c2320810baed5acba	clean	\N	\N	2026-06-27 12:55:03.485	2026-06-27 13:00:47.097
fd871715-e515-45e3-a6ad-af4417cc3bac	eb3173d6-01b3-4548-a8d3-db877561f728	Demo Enquirer 11	9000000011	enquirer11@example.test	Fictional enquiry about Karanj	This is a fictional enquiry created for CMS administration and export testing.	Demo Cooperative 11	df849f1b-b168-45a9-a1cb-40139f8d225d	22fcb9e5-5190-4635-ab71-825976847e51	2026-06-11 10:00:00	2aac8beb695bf13b3de649938908ff8aeeda89c040f9a4587717f12159650595	clean	Fixture follow-up note.	\N	2026-06-27 12:55:03.486	2026-06-27 13:00:47.098
3761db68-e0e8-4391-8f52-f78ed4e18185	0141dab7-3661-4d68-a789-54c41e591323	Demo Enquirer 12	9000000012	enquirer12@example.test	Fictional enquiry about Tamarind	This is a fictional enquiry created for CMS administration and export testing.	\N	4f276af1-d981-4294-9f50-fbcdf2c979c2	d89d19c1-31ed-488f-a792-88de2325f352	2026-06-12 10:00:00	0bd1de3c8d022aa5f2f93cfa2c9ebe7ae7906b8d8545444e5b6d8ec5aecf8ed2	clean	\N	\N	2026-06-27 12:55:03.487	2026-06-27 13:00:47.099
9bc97e93-a383-4df8-b11c-4d874c44ab8d	09e3b13a-ce17-465a-958f-eae7a9a4206d	Demo Enquirer 13	9000000013	enquirer13@example.test	Fictional enquiry about Lac	This is a fictional enquiry created for CMS administration and export testing.	Demo Cooperative 13	29abba96-aa2b-49b5-ba07-d75f2ce64932	9867c29c-3ebf-41b0-98a8-221efcd86aca	2026-06-13 10:00:00	87469b76198e84d41ba6fc290226835b61512d39a6452098b2b80e64d03f3683	clean	\N	2026-06-27 08:00:00	2026-06-27 12:55:03.488	2026-06-27 13:00:47.1
faf20f03-7fb2-4c1b-a690-f8cc7c560bde	d4eec28e-33e1-4363-95f2-888316d9a69e	Demo Enquirer 14	9000000014	enquirer14@example.test	Fictional enquiry about Honey	This is a fictional enquiry created for CMS administration and export testing.	\N	d5302db1-d57e-4d7c-85ad-bf3dbc6db6e5	27a6b58a-a27a-4445-9ae4-1db0f6c6c223	2026-06-14 10:00:00	79711d6e650a876c3c489cb585034e13d34f56ceec9a1044fd8fd8e57ff23346	suspected	\N	\N	2026-06-27 12:55:03.489	2026-06-27 13:00:47.102
df288fb1-6577-413d-b792-5ee867ea6822	fa28a9c7-208c-4a9f-805e-e79718c0dcf6	Demo Enquirer 15	9000000015	enquirer15@example.test	Fictional enquiry about Ragi / Millets	This is a fictional enquiry created for CMS administration and export testing.	Demo Cooperative 15	b4873f7f-544f-42c3-855e-2810c7970236	cf87cfda-4657-46ab-8dc3-5f2c288b52a1	2026-06-15 10:00:00	06f8e1c1e04ae45f553eac83b68d8ab445c80f8307a2ec6a3be91395ee81d8ae	spam	\N	\N	2026-06-27 12:55:03.491	2026-06-27 13:00:47.103
\.


--
-- Data for Name: enquiry_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.enquiry_types (id, name_en, name_hi, slug, is_active, display_order, created_at, updated_at) FROM stdin;
09e3b13a-ce17-465a-958f-eae7a9a4206d	General Enquiry	\N	general-enquiry	t	1	2026-06-27 12:55:01.982	2026-06-27 13:00:45.787
d4eec28e-33e1-4363-95f2-888316d9a69e	Buyer Enquiry	\N	buyer-enquiry	t	2	2026-06-27 12:55:01.985	2026-06-27 13:00:45.788
fa28a9c7-208c-4a9f-805e-e79718c0dcf6	Seller Enquiry	\N	seller-enquiry	t	3	2026-06-27 12:55:01.985	2026-06-27 13:00:45.789
43dfef2f-755d-42c0-be2e-bbfd7320d57a	Storage / Godown Enquiry	\N	storage-godown-enquiry	t	4	2026-06-27 12:55:01.986	2026-06-27 13:00:45.79
eb3173d6-01b3-4548-a8d3-db877561f728	Membership Enquiry	\N	membership-enquiry	t	5	2026-06-27 12:55:01.987	2026-06-27 13:00:45.791
0141dab7-3661-4d68-a789-54c41e591323	Partnership Enquiry	\N	partnership-enquiry	t	6	2026-06-27 12:55:01.989	2026-06-27 13:00:45.791
\.


--
-- Data for Name: event_commodities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.event_commodities (id, event_id, commodity_id) FROM stdin;
79252236-8fe3-4b81-aa73-d9c765f4bcd8	90816975-fff8-4e41-914c-4a434b87fbdf	29abba96-aa2b-49b5-ba07-d75f2ce64932
3c2eb08b-869b-4170-83d6-fde2ee2a77e2	24f83e40-7156-4ee4-ab8a-ec2925392ca9	d5302db1-d57e-4d7c-85ad-bf3dbc6db6e5
46f2e33a-0809-42ab-9e8a-20e9ab9519b3	8424284e-5a82-451c-8863-baffeeb71f2b	b4873f7f-544f-42c3-855e-2810c7970236
f63f5dc3-45e5-4d7b-94e7-981fdc4b6ab8	c3a7c7ac-27c3-4c66-a7f0-79d0907d5272	cffc6a8c-ed36-4163-aab4-2417904ca859
a710fa2e-552b-4d99-ac1a-1ff3a3aa325e	973f4234-e445-424a-8053-9490f7fcc956	df849f1b-b168-45a9-a1cb-40139f8d225d
39e4a9ce-8240-45b4-b3a7-b31668aee6c8	82cf3be5-7fa5-45b9-8d71-08b15cab4642	4f276af1-d981-4294-9f50-fbcdf2c979c2
99eb8c06-4993-438e-96c8-c969c837a5a8	3484093c-ee25-4a22-a2d2-e7c870c200df	29abba96-aa2b-49b5-ba07-d75f2ce64932
907c106e-5751-4954-89f6-0f310b9fe2a3	f20b1cdf-e8a9-43e4-a23b-f1a1783e0d2c	d5302db1-d57e-4d7c-85ad-bf3dbc6db6e5
3d11f863-953a-41ec-a367-e41c5211faf5	e30b279f-fd18-497a-bd1a-a0b5beaafb63	b4873f7f-544f-42c3-855e-2810c7970236
3753f1b1-d7b6-4bd3-ab55-fd6ebb4cf63f	5e20a76d-7323-4bd8-b6ba-234b3aa33141	cffc6a8c-ed36-4163-aab4-2417904ca859
db84a10f-718a-48ac-9369-53473e31a4ae	b49ec2d0-2c30-4f6e-bd35-871a2f281eb7	df849f1b-b168-45a9-a1cb-40139f8d225d
54e5ee43-c18c-4448-8a6c-2df810417327	73acb719-a481-4f93-9edb-395bcd8fafc5	4f276af1-d981-4294-9f50-fbcdf2c979c2
85044b08-1990-4ce3-9542-a93230416ccc	476da260-931a-40a1-9242-44b81f0d4620	29abba96-aa2b-49b5-ba07-d75f2ce64932
36738b26-36b7-48ac-a361-8f5e7fe6411f	eeeb1b36-e943-420c-835b-654d5300a00c	d5302db1-d57e-4d7c-85ad-bf3dbc6db6e5
97ac1cca-a535-426d-96e7-48cc210a3884	cca553d4-a3ca-4270-b166-adff9f3e1614	b4873f7f-544f-42c3-855e-2810c7970236
f2d3219c-71c4-4b62-9e01-6a5f8aa5e0dd	46865834-4135-41ef-9a93-df11593deb78	cffc6a8c-ed36-4163-aab4-2417904ca859
d4dbb5f6-4b52-4ab9-b473-df51c9fb4a9a	4e88a410-6772-4053-97f6-5664a8721c46	df849f1b-b168-45a9-a1cb-40139f8d225d
21aa0846-8e90-4841-8393-f7ce3e655ff1	797f6ea6-1380-4878-aa72-a5a478a272f0	4f276af1-d981-4294-9f50-fbcdf2c979c2
53c0299c-50a8-4054-bb3e-f4fa3cb828de	da12f740-3f3c-4998-992b-70f049762e9d	29abba96-aa2b-49b5-ba07-d75f2ce64932
c7773dcd-f3a3-42c7-8ffa-b6d139f1f0ca	035a951d-39e7-41b6-a6e9-d88e8a69aef3	d5302db1-d57e-4d7c-85ad-bf3dbc6db6e5
87defc56-bf2e-4381-b6ad-87693c5ebc4c	b9404cc6-355d-4a30-8fd0-732236b1d762	b4873f7f-544f-42c3-855e-2810c7970236
b8ee0005-baff-46b8-9137-6cac741c1089	118075dd-8c9b-4a71-ac35-3974fe107a57	cffc6a8c-ed36-4163-aab4-2417904ca859
687b94dd-cd5d-46b8-9eba-06dfc538954a	29ef0b76-98de-438d-83b3-744e1a68d13a	df849f1b-b168-45a9-a1cb-40139f8d225d
8b26fa80-9648-4953-8c17-e9faab194163	03ce842e-931e-46d8-b33d-fa2c8d6f2628	4f276af1-d981-4294-9f50-fbcdf2c979c2
\.


--
-- Data for Name: event_documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.event_documents (id, event_id, document_id) FROM stdin;
5229b862-cc7d-40f7-a131-186f60489f9d	90816975-fff8-4e41-914c-4a434b87fbdf	7944c41a-0cfa-4b43-a262-d498bd509c7e
845654cd-28c8-4466-9749-ac374f69c432	24f83e40-7156-4ee4-ab8a-ec2925392ca9	623abf9f-5986-42a1-bf2e-19ef4dd44ae4
3967b48a-f0d5-4469-b481-434d4000ccf9	8424284e-5a82-451c-8863-baffeeb71f2b	cc5052f0-2a3b-4122-85f2-54e91fe0e409
37548610-41fc-4e6e-9cf5-25007de55aec	c3a7c7ac-27c3-4c66-a7f0-79d0907d5272	5fa1f9d9-bb93-4e97-bace-309f87178155
46762a83-42ca-42e2-bad7-88db2019d497	973f4234-e445-424a-8053-9490f7fcc956	a718689f-92f0-4279-ae77-a975a854d6db
ffa51e5d-ce78-468e-9500-3a8ed5c25ddc	82cf3be5-7fa5-45b9-8d71-08b15cab4642	16a09d86-3153-4a7a-8071-b2d5968e80dd
237b3f1f-3ce3-4eaf-95a6-2650fa868628	3484093c-ee25-4a22-a2d2-e7c870c200df	2c366c39-c9ef-4a33-a676-5bfa04ab9305
c7600329-f8d2-423b-b88c-16645fcb935e	f20b1cdf-e8a9-43e4-a23b-f1a1783e0d2c	e326d4f8-140b-4f04-b43e-8790b44b3860
7fbcc2fe-d256-4918-9529-543248b9958a	e30b279f-fd18-497a-bd1a-a0b5beaafb63	d223a5d9-ff95-4736-9292-727d62dde24a
f9128c0a-76e6-46cc-a34b-976319148ee5	5e20a76d-7323-4bd8-b6ba-234b3aa33141	3cd791ca-0192-4685-8332-78c2bce1ed4c
eb8bef0a-ecbd-4978-9977-e1262fc3a519	b49ec2d0-2c30-4f6e-bd35-871a2f281eb7	151d0a3f-bddb-4ba2-8943-d788078de702
de39795c-75b5-42fb-a971-e2c6dd68a6ba	73acb719-a481-4f93-9edb-395bcd8fafc5	82b43929-43c0-40dd-bb89-0cc1eab52785
cb2e20b0-14f2-496f-ab65-b3b3e1a51a7c	476da260-931a-40a1-9242-44b81f0d4620	14ad3aa8-b254-462f-a976-66377504499b
407975c4-394c-46d4-ba67-4d001e9f7095	eeeb1b36-e943-420c-835b-654d5300a00c	01b37620-3a5f-45f5-9266-742ca492973c
5a146bf6-8692-49f9-81ca-621a58097ce2	cca553d4-a3ca-4270-b166-adff9f3e1614	073f9d96-b171-4a77-8d40-d66943da389c
79164cfd-83be-4c68-abb3-ebd4f390ac78	46865834-4135-41ef-9a93-df11593deb78	8a15342c-2f4d-416b-b06b-3cfec936d223
313c4653-23a0-4c03-bbc7-38bdfe1a079c	4e88a410-6772-4053-97f6-5664a8721c46	fc5c00bd-3cb6-474a-aa74-dc66033a6856
30ef1819-d597-4243-b445-56669cb3f1a4	797f6ea6-1380-4878-aa72-a5a478a272f0	bbb19a3e-0968-405e-ae86-0c0cf75fe756
f5b473bd-d5fd-4f6a-98d4-ac79098cacef	da12f740-3f3c-4998-992b-70f049762e9d	7944c41a-0cfa-4b43-a262-d498bd509c7e
81561167-8934-4a12-9c0b-c795de00d0b5	035a951d-39e7-41b6-a6e9-d88e8a69aef3	623abf9f-5986-42a1-bf2e-19ef4dd44ae4
4d849ddd-8c2a-4161-b2d6-8d2d07e85ef8	b9404cc6-355d-4a30-8fd0-732236b1d762	cc5052f0-2a3b-4122-85f2-54e91fe0e409
8f1132e9-15a4-428a-abd2-0ed944207ca0	118075dd-8c9b-4a71-ac35-3974fe107a57	5fa1f9d9-bb93-4e97-bace-309f87178155
76f79621-723c-4ab2-b7be-90210d52fb0c	29ef0b76-98de-438d-83b3-744e1a68d13a	a718689f-92f0-4279-ae77-a975a854d6db
a0ff870e-6328-4164-80b1-8d38460cc77d	03ce842e-931e-46d8-b33d-fa2c8d6f2628	16a09d86-3153-4a7a-8071-b2d5968e80dd
\.


--
-- Data for Name: event_field_definitions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.event_field_definitions (id, event_type_id, field_key, label_en, label_hi, data_type, is_required, options, display_order, is_active, created_at, updated_at) FROM stdin;
ea451989-cd40-4dbc-921e-dc12c8a03d2b	74b722ba-de0a-4313-9ec9-af30eec2825f	fixture_field_1	Fixture field 1	परीक्षण फ़ील्ड 1	text	t	null	1	t	2026-06-27 13:00:46.846	2026-06-27 13:00:46.846
94390c1a-cfae-4e92-bb21-931c41afbf60	298679b8-df0f-4c14-ac32-3cac97092cb9	fixture_field_1	Fixture field 2	\N	number	f	null	2	t	2026-06-27 13:00:46.846	2026-06-27 13:00:46.846
0f564b4a-b67d-46ec-a14f-040dee9669de	f97dd2ef-a73d-4fc9-9304-59500cd86d68	fixture_field_1	Fixture field 3	परीक्षण फ़ील्ड 3	boolean	f	null	3	t	2026-06-27 13:00:46.846	2026-06-27 13:00:46.846
52a84450-448a-44e8-9c16-eb40f9b15d0d	19b90ce0-b6c1-4413-91ce-6dbcabe73ee5	fixture_field_1	Fixture field 4	\N	select	t	["Option A", "Option B"]	4	t	2026-06-27 13:00:46.846	2026-06-27 13:00:46.846
5e23f25a-6217-452e-908f-c2da69ec37da	4a0b12df-466c-4078-b1a7-42a4c944218f	fixture_field_1	Fixture field 5	परीक्षण फ़ील्ड 5	text	f	null	5	t	2026-06-27 13:00:46.846	2026-06-27 13:00:46.846
0ae3bc34-533d-4f15-8d4a-ca56090063ee	ba39876c-1339-4409-ba6e-abd2843d854d	fixture_field_1	Fixture field 6	\N	number	f	null	6	t	2026-06-27 13:00:46.846	2026-06-27 13:00:46.846
1959105d-a31a-467b-9881-8689b5b8413b	f957bcc4-9414-4d6c-8d2c-d3502cd470e7	fixture_field_1	Fixture field 7	परीक्षण फ़ील्ड 7	boolean	t	null	7	t	2026-06-27 13:00:46.846	2026-06-27 13:00:46.846
9846ac56-5b86-4f8a-acbc-1a01f6b6eee2	3c2ed304-3ec7-4e0b-9c35-4c51c8e0a571	fixture_field_1	Fixture field 8	\N	select	f	["Option A", "Option B"]	8	t	2026-06-27 13:00:46.846	2026-06-27 13:00:46.846
9d75754c-1c9a-4cc7-8626-61268ec091ec	00c77880-4eca-48b6-af3b-200787ca67ac	fixture_field_1	Fixture field 9	परीक्षण फ़ील्ड 9	text	f	null	9	t	2026-06-27 13:00:46.846	2026-06-27 13:00:46.846
2e70b857-a661-4cdf-8233-a5a642021042	74b722ba-de0a-4313-9ec9-af30eec2825f	fixture_field_2	Fixture field 10	\N	number	t	null	10	t	2026-06-27 13:00:46.846	2026-06-27 13:00:46.846
9d94923d-aa17-4ee9-b51b-8b0c6bedf96b	298679b8-df0f-4c14-ac32-3cac97092cb9	fixture_field_2	Fixture field 11	परीक्षण फ़ील्ड 11	boolean	f	null	11	t	2026-06-27 13:00:46.846	2026-06-27 13:00:46.846
bbcf33b8-b68f-4dfa-804b-6b90e9296283	f97dd2ef-a73d-4fc9-9304-59500cd86d68	fixture_field_2	Fixture field 12	\N	select	f	["Option A", "Option B"]	12	t	2026-06-27 13:00:46.846	2026-06-27 13:00:46.846
\.


--
-- Data for Name: event_galleries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.event_galleries (id, event_id, gallery_id) FROM stdin;
ba05b6a1-ffb5-4e46-9d96-513096343667	90816975-fff8-4e41-914c-4a434b87fbdf	efe870eb-3011-4988-8d3f-b852082e623e
b1a9af07-c11a-4438-8d43-0ebf89eb7f8b	24f83e40-7156-4ee4-ab8a-ec2925392ca9	85fab47f-42a1-4bd4-8d52-081d94c70485
703bddb9-14f1-457d-8d8c-ea119304dd90	8424284e-5a82-451c-8863-baffeeb71f2b	39849df0-72ac-4788-b87c-4836168527c7
bce1bde9-d342-4562-80c4-78c5076848e8	c3a7c7ac-27c3-4c66-a7f0-79d0907d5272	05429ae9-b181-4e6c-9e03-2e74f0f36281
cc142bf6-feac-46b1-93c0-f42c1801ed50	973f4234-e445-424a-8053-9490f7fcc956	92623dd4-dec8-4416-8953-d8101fe2731b
7f35ff5e-6641-431c-9d2c-986fab1f500c	82cf3be5-7fa5-45b9-8d71-08b15cab4642	f31b6048-4e3b-4d60-a906-cd469e2eb208
da34efe9-f3dd-4eed-ac7f-d70f4f88641e	3484093c-ee25-4a22-a2d2-e7c870c200df	6a54114c-6059-4bf2-87b6-db3b1ea5639d
1e2986e3-6574-425e-96d8-87262cbd14a7	f20b1cdf-e8a9-43e4-a23b-f1a1783e0d2c	5732a81f-6f2b-456b-89f8-242e3dafc01b
b3a46ce9-87f4-4dbd-b527-b581722c17f6	e30b279f-fd18-497a-bd1a-a0b5beaafb63	7a44f5a2-ec5c-4799-8e40-2fddaa561c42
c3c7a934-79b1-403f-8cf0-95892d5fe5b4	5e20a76d-7323-4bd8-b6ba-234b3aa33141	3da241ad-da2b-4b23-b7bb-dac0cb6570cf
d7c68e35-1940-4ab1-894b-9579c5119cbd	b49ec2d0-2c30-4f6e-bd35-871a2f281eb7	efe870eb-3011-4988-8d3f-b852082e623e
05ae2435-f4e7-4f97-ae6c-4da567d20114	73acb719-a481-4f93-9edb-395bcd8fafc5	85fab47f-42a1-4bd4-8d52-081d94c70485
cbc79f1f-902d-46c4-ae5f-45633f126632	476da260-931a-40a1-9242-44b81f0d4620	39849df0-72ac-4788-b87c-4836168527c7
d5e22d9b-e79e-4a9f-b705-fcbffd80d288	eeeb1b36-e943-420c-835b-654d5300a00c	05429ae9-b181-4e6c-9e03-2e74f0f36281
34fa32eb-42d5-4c12-8b4f-842f2b8a516f	cca553d4-a3ca-4270-b166-adff9f3e1614	92623dd4-dec8-4416-8953-d8101fe2731b
a3ec3d6f-4f12-458e-8116-0e8ffd9d8c77	46865834-4135-41ef-9a93-df11593deb78	f31b6048-4e3b-4d60-a906-cd469e2eb208
15d460c3-e896-4a0e-9c4f-026571a2d555	4e88a410-6772-4053-97f6-5664a8721c46	6a54114c-6059-4bf2-87b6-db3b1ea5639d
8e7c0888-231c-4f10-9380-9618eae9a0d9	797f6ea6-1380-4878-aa72-a5a478a272f0	5732a81f-6f2b-456b-89f8-242e3dafc01b
30658b99-3d34-481a-b99e-c6f111a966c7	da12f740-3f3c-4998-992b-70f049762e9d	7a44f5a2-ec5c-4799-8e40-2fddaa561c42
85975b13-7484-473f-957d-31cba174b59e	035a951d-39e7-41b6-a6e9-d88e8a69aef3	3da241ad-da2b-4b23-b7bb-dac0cb6570cf
dfe69264-211f-41a7-9c38-8db110c23958	b9404cc6-355d-4a30-8fd0-732236b1d762	efe870eb-3011-4988-8d3f-b852082e623e
d2d3712c-156e-4547-a865-57213f3df96c	118075dd-8c9b-4a71-ac35-3974fe107a57	85fab47f-42a1-4bd4-8d52-081d94c70485
92e00c4f-fa6d-4add-9693-3bcfa7590641	29ef0b76-98de-438d-83b3-744e1a68d13a	39849df0-72ac-4788-b87c-4836168527c7
a5b13825-88a0-4ca6-b8b4-0322401777df	03ce842e-931e-46d8-b33d-fa2c8d6f2628	05429ae9-b181-4e6c-9e03-2e74f0f36281
\.


--
-- Data for Name: event_institutions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.event_institutions (id, event_id, institution_id) FROM stdin;
cf74b5e1-f7fc-4b15-be51-cd7c2e750eb9	90816975-fff8-4e41-914c-4a434b87fbdf	a7882c7b-b339-405a-98ff-787ea22af71e
25dffcf3-29d9-43c8-ad59-eb7597bf14f4	24f83e40-7156-4ee4-ab8a-ec2925392ca9	76216f41-cbea-4f28-af6e-325511eec36b
f9059e91-6a3b-44c5-9c95-17e6ed01f450	8424284e-5a82-451c-8863-baffeeb71f2b	4a4f9cba-ad6a-42ca-a33a-51c237b24959
bcb7d9bd-a7d2-4081-9f0b-1f1f8e94d3c9	c3a7c7ac-27c3-4c66-a7f0-79d0907d5272	eb467702-6b19-4e1a-91bb-8e0b6f8846b5
31c4807e-1370-415c-bd34-26dde9572e43	973f4234-e445-424a-8053-9490f7fcc956	1ba549fe-161d-41c1-8df5-6ac141b9a203
f69e8112-71bf-4788-8ad4-1a44c60bfc8c	82cf3be5-7fa5-45b9-8d71-08b15cab4642	8e19a717-50c2-4a26-b973-a6886b536573
00fb97c6-66a1-43a9-b908-b3edb0b37ec8	3484093c-ee25-4a22-a2d2-e7c870c200df	0e9b51f2-f393-4f8d-a004-2d22190ab744
42430143-a5ae-441b-90e1-c6db0a6dab40	f20b1cdf-e8a9-43e4-a23b-f1a1783e0d2c	aaaf27d6-9868-4bff-b595-e86bf092a2f1
a06384f5-9443-4cd0-8c76-338dd10e6afc	e30b279f-fd18-497a-bd1a-a0b5beaafb63	ae84e287-f81d-44ed-86ce-129141d2f407
0495fe11-7e37-4e10-a373-fef6a5f252ad	5e20a76d-7323-4bd8-b6ba-234b3aa33141	bff1ae9a-2a5e-4ade-970a-2b2e5d2b66e3
69bb4755-2e98-4a6d-8129-ded3631e8a52	b49ec2d0-2c30-4f6e-bd35-871a2f281eb7	4eb59158-f8ac-44c5-aa57-21c73ace31b2
36f1654d-710b-411c-8a76-6d2e9338debf	73acb719-a481-4f93-9edb-395bcd8fafc5	a7934626-a21d-48ad-967c-7cb38d69d4b3
614d6451-a69e-4bc5-b2ea-3accda83c94e	476da260-931a-40a1-9242-44b81f0d4620	a7882c7b-b339-405a-98ff-787ea22af71e
6c533342-927c-40a4-ba19-b2455a794c40	eeeb1b36-e943-420c-835b-654d5300a00c	76216f41-cbea-4f28-af6e-325511eec36b
d4fd54da-cfb6-45c2-b210-158a7b3f20c1	cca553d4-a3ca-4270-b166-adff9f3e1614	4a4f9cba-ad6a-42ca-a33a-51c237b24959
b5ed8165-3720-405c-bc96-892fc8b27ef9	46865834-4135-41ef-9a93-df11593deb78	eb467702-6b19-4e1a-91bb-8e0b6f8846b5
857990c1-4fac-4465-9c9f-ed86ee6159e5	4e88a410-6772-4053-97f6-5664a8721c46	1ba549fe-161d-41c1-8df5-6ac141b9a203
5bc473ea-93c3-42aa-8b56-61dd2f2062e8	797f6ea6-1380-4878-aa72-a5a478a272f0	8e19a717-50c2-4a26-b973-a6886b536573
4cb4e5ba-6661-438e-86ee-4c31a52a0639	da12f740-3f3c-4998-992b-70f049762e9d	0e9b51f2-f393-4f8d-a004-2d22190ab744
5b861283-bb87-4aad-a284-99ad9f6bcf56	035a951d-39e7-41b6-a6e9-d88e8a69aef3	aaaf27d6-9868-4bff-b595-e86bf092a2f1
ec1b8a03-b075-4e31-ad03-dec198d76d58	b9404cc6-355d-4a30-8fd0-732236b1d762	ae84e287-f81d-44ed-86ce-129141d2f407
32d662fc-1e76-447e-b52b-8fa4208caca9	118075dd-8c9b-4a71-ac35-3974fe107a57	bff1ae9a-2a5e-4ade-970a-2b2e5d2b66e3
fc3a243e-ce1d-41de-87a5-60fca6194152	29ef0b76-98de-438d-83b3-744e1a68d13a	4eb59158-f8ac-44c5-aa57-21c73ace31b2
d075b012-6826-45a2-a4b4-5614b1500b1b	03ce842e-931e-46d8-b33d-fa2c8d6f2628	a7934626-a21d-48ad-967c-7cb38d69d4b3
\.


--
-- Data for Name: event_news; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.event_news (id, event_id, title_en, title_hi, summary_en, summary_hi, body_en, body_hi, cover_media_id, news_published_at, slug, publication_state, public_visibility, publish_start_at, published_at, archived_at, highlight_type, highlight_start_at, highlight_end_at, display_order, show_on_homepage, created_by, updated_by, created_at, updated_at) FROM stdin;
c1bc484f-ca06-49d7-9515-b3f079e5e853	973f4234-e445-424a-8053-9490f7fcc956	Demo News: Cooperative Activity 5 Completed	डेमो समाचार 5	Fictional news projection from a completed event.	\N	This story exists to test event-to-news projection and public news detail pages.	\N	eb3877af-dd51-4f3c-8b6b-57570d63c33c	2025-05-15 08:00:00	demo-activity-news-5	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	5	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.141	2026-06-27 13:00:46.829
93951408-8b4a-42b9-8fb5-163ec2396173	82cf3be5-7fa5-45b9-8d71-08b15cab4642	Demo News: Cooperative Activity 6 Completed	\N	Fictional news projection from a completed event.	\N	This story exists to test event-to-news projection and public news detail pages.	\N	18620944-e2bc-4e06-811d-f2c33d22ae84	2025-06-15 08:00:00	demo-activity-news-6	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	6	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.142	2026-06-27 13:00:46.831
e4daa8e9-fb09-48cd-8d8d-5a947587be8f	3484093c-ee25-4a22-a2d2-e7c870c200df	Demo News: Cooperative Activity 7 Completed	डेमो समाचार 7	Fictional news projection from a completed event.	\N	This story exists to test event-to-news projection and public news detail pages.	\N	bf9358c7-960b-4365-8b61-74f8788a7ad3	2025-07-15 08:00:00	demo-activity-news-7	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	7	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.144	2026-06-27 13:00:46.833
e356791e-8a31-4beb-ba73-e2276b461086	f20b1cdf-e8a9-43e4-a23b-f1a1783e0d2c	Demo News: Cooperative Activity 8 Completed	\N	Fictional news projection from a completed event.	\N	This story exists to test event-to-news projection and public news detail pages.	\N	84e59f6d-0311-404d-beaa-cf2172b47897	2025-08-15 08:00:00	demo-activity-news-8	unpublished	t	\N	\N	\N	\N	\N	\N	8	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.146	2026-06-27 13:00:46.835
688bef95-7907-46e0-86c8-5582e42bce9c	e30b279f-fd18-497a-bd1a-a0b5beaafb63	Demo News: Cooperative Activity 9 Completed	डेमो समाचार 9	Fictional news projection from a completed event.	\N	This story exists to test event-to-news projection and public news detail pages.	\N	4e8d90dc-7a13-4084-addf-b476da99f4e6	2025-09-15 08:00:00	demo-activity-news-9	published	t	2027-01-15 08:00:00	2026-01-15 08:00:00	\N	\N	\N	\N	9	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.148	2026-06-27 13:00:46.836
c70785fb-ba1a-4c3d-8f66-558900da38d1	5e20a76d-7323-4bd8-b6ba-234b3aa33141	Demo News: Cooperative Activity 10 Completed	\N	Fictional news projection from a completed event.	\N	This story exists to test event-to-news projection and public news detail pages.	\N	1556504e-8fcc-4269-9d95-c388657993f5	2025-01-15 08:00:00	demo-activity-news-10	published	f	\N	2026-01-15 08:00:00	\N	\N	\N	\N	10	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.149	2026-06-27 13:00:46.838
b0bd9d25-4c15-4885-92b2-c67cb2a84a38	b49ec2d0-2c30-4f6e-bd35-871a2f281eb7	Demo News: Cooperative Activity 11 Completed	डेमो समाचार 11	Fictional news projection from a completed event.	\N	This story exists to test event-to-news projection and public news detail pages.	\N	4c222680-3614-4531-8764-4c832b5f850b	2025-02-15 08:00:00	demo-activity-news-11	draft	t	\N	\N	\N	\N	\N	\N	11	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.151	2026-06-27 13:00:46.84
c677ac80-ba92-4e2e-b261-40609a6562a2	24f83e40-7156-4ee4-ab8a-ec2925392ca9	Demo News: Cooperative Activity 2 Completed	\N	Fictional news projection from a completed event.	\N	This story exists to test event-to-news projection and public news detail pages.	\N	cd1634aa-09ca-471d-a8b8-94968c0b7c9d	2025-02-15 08:00:00	demo-activity-news-2	published	t	\N	2026-01-15 08:00:00	\N	latest	2026-01-15 08:00:00	2027-01-15 08:00:00	2	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.134	2026-06-27 13:00:46.823
64b53f83-c15f-450f-8ca8-a4f62f336734	8424284e-5a82-451c-8863-baffeeb71f2b	Demo News: Cooperative Activity 3 Completed	डेमो समाचार 3	Fictional news projection from a completed event.	\N	This story exists to test event-to-news projection and public news detail pages.	\N	e572b312-06c9-47e3-b150-4fd9c2b4e59c	2025-03-15 08:00:00	demo-activity-news-3	published	t	\N	2026-01-15 08:00:00	\N	important	2026-01-15 08:00:00	2027-01-15 08:00:00	3	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.136	2026-06-27 13:00:46.825
c6984ccb-9ce7-4122-8897-31a0dcf75159	c3a7c7ac-27c3-4c66-a7f0-79d0907d5272	Demo News: Cooperative Activity 4 Completed	\N	Fictional news projection from a completed event.	\N	This story exists to test event-to-news projection and public news detail pages.	\N	cc4f583c-bd55-44e8-a408-9af5aa951372	2025-04-15 08:00:00	demo-activity-news-4	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	4	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.138	2026-06-27 13:00:46.827
bcad0376-86be-4849-8f1d-7e6bd683039c	90816975-fff8-4e41-914c-4a434b87fbdf	Demo News: Cooperative Activity 1 Completed	डेमो समाचार 1	Fictional news projection from a completed event.	\N	This story exists to test event-to-news projection and public news detail pages.	\N	6853eb6c-ba01-4312-b751-b608641a94f5	2025-01-15 08:00:00	demo-activity-news-1	published	t	\N	2026-01-15 08:00:00	\N	featured	2026-01-15 08:00:00	2027-01-15 08:00:00	1	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.128	2026-06-27 13:00:46.821
22b832d4-9b42-4459-8ee6-d5f3c03e6aa1	73acb719-a481-4f93-9edb-395bcd8fafc5	Demo News: Cooperative Activity 12 Completed	\N	Fictional news projection from a completed event.	\N	This story exists to test event-to-news projection and public news detail pages.	\N	ffdd7879-2936-44f4-9e85-590ef7f5c988	2025-03-15 08:00:00	demo-activity-news-12	archived	f	\N	2026-01-15 08:00:00	2026-06-27 08:00:00	\N	\N	\N	12	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.153	2026-06-27 13:00:46.841
\.


--
-- Data for Name: event_programmes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.event_programmes (id, event_id, programme_scheme_id) FROM stdin;
7a6aa79a-2b17-46f8-b96e-5371155bf7ac	90816975-fff8-4e41-914c-4a434b87fbdf	22fcb9e5-5190-4635-ab71-825976847e51
8e3338e7-bcce-4494-b284-ae3d777fc01f	24f83e40-7156-4ee4-ab8a-ec2925392ca9	d89d19c1-31ed-488f-a792-88de2325f352
6fa5883d-2319-4b9c-93f4-7ec2282d326d	8424284e-5a82-451c-8863-baffeeb71f2b	9867c29c-3ebf-41b0-98a8-221efcd86aca
f59becce-4d23-4697-840f-0ec9823956e8	c3a7c7ac-27c3-4c66-a7f0-79d0907d5272	27a6b58a-a27a-4445-9ae4-1db0f6c6c223
4a801ad7-781a-4b2b-8c4d-eb9e983f4117	973f4234-e445-424a-8053-9490f7fcc956	cf87cfda-4657-46ab-8dc3-5f2c288b52a1
5977f202-948e-4fc7-b5ab-f1644af0ebbe	82cf3be5-7fa5-45b9-8d71-08b15cab4642	edf6864c-2bd3-4a15-8a3c-7b23c3407be0
7d23f7ec-a9b2-4da1-abfd-025187034445	3484093c-ee25-4a22-a2d2-e7c870c200df	f2418002-8794-4079-a380-4dc3f810aafa
3f94abc8-12ee-46ae-a738-92bb90dedb53	f20b1cdf-e8a9-43e4-a23b-f1a1783e0d2c	fbbc4562-43a7-4015-9d4d-31ec23f1fcd0
c60ffa2e-502d-4fa9-8065-ed491a76b979	e30b279f-fd18-497a-bd1a-a0b5beaafb63	d6dcdc56-84dc-4d87-990a-986e8ded46fb
04292791-13c6-4231-a4ec-d711f7f9353d	5e20a76d-7323-4bd8-b6ba-234b3aa33141	e5427a51-68a7-4fbe-b618-3378361218a7
8f96b866-2bcb-4858-a6ce-6b1922fe3995	b49ec2d0-2c30-4f6e-bd35-871a2f281eb7	22fcb9e5-5190-4635-ab71-825976847e51
ecde259d-e7f8-41ba-bb7e-50f3b4d25a25	73acb719-a481-4f93-9edb-395bcd8fafc5	d89d19c1-31ed-488f-a792-88de2325f352
101bbb9e-b39a-4dd9-a737-d387d5b4affa	476da260-931a-40a1-9242-44b81f0d4620	9867c29c-3ebf-41b0-98a8-221efcd86aca
edd2a24f-a4c2-4b5b-b8da-92d0e9f9ad25	eeeb1b36-e943-420c-835b-654d5300a00c	27a6b58a-a27a-4445-9ae4-1db0f6c6c223
db54ef3a-6374-4d39-b214-3dfa7b246fc2	cca553d4-a3ca-4270-b166-adff9f3e1614	cf87cfda-4657-46ab-8dc3-5f2c288b52a1
bf05c1e9-c9f2-43e2-a88b-ce9b5887328b	46865834-4135-41ef-9a93-df11593deb78	edf6864c-2bd3-4a15-8a3c-7b23c3407be0
7de11247-3518-40ba-a245-d58aa71d1d96	4e88a410-6772-4053-97f6-5664a8721c46	f2418002-8794-4079-a380-4dc3f810aafa
49d1c89b-3409-4cf3-8bf0-82d0ec57d457	797f6ea6-1380-4878-aa72-a5a478a272f0	fbbc4562-43a7-4015-9d4d-31ec23f1fcd0
139feb66-1a6a-4b16-afa1-7a6ea716c6cb	da12f740-3f3c-4998-992b-70f049762e9d	d6dcdc56-84dc-4d87-990a-986e8ded46fb
a66271ed-3176-444e-9498-92d99ae6bd95	035a951d-39e7-41b6-a6e9-d88e8a69aef3	e5427a51-68a7-4fbe-b618-3378361218a7
fee42f28-55aa-42e2-b786-88eb2d9bf87a	b9404cc6-355d-4a30-8fd0-732236b1d762	22fcb9e5-5190-4635-ab71-825976847e51
9a6d2f48-90ac-4552-a228-1e9d44fbc309	118075dd-8c9b-4a71-ac35-3974fe107a57	d89d19c1-31ed-488f-a792-88de2325f352
d8fb2504-7e16-4ca6-bbbe-a3c454050f74	29ef0b76-98de-438d-83b3-744e1a68d13a	9867c29c-3ebf-41b0-98a8-221efcd86aca
053ba44b-9767-4c3f-891a-da06d8f1fbc9	03ce842e-931e-46d8-b33d-fa2c8d6f2628	27a6b58a-a27a-4445-9ae4-1db0f6c6c223
\.


--
-- Data for Name: event_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.event_types (id, name_en, name_hi, slug, is_active, display_order, created_at, updated_at) FROM stdin;
74b722ba-de0a-4313-9ec9-af30eec2825f	Training	\N	training	t	1	2026-06-27 12:55:01.908	2026-06-27 13:00:45.731
298679b8-df0f-4c14-ac32-3cac97092cb9	Workshop	\N	workshop	t	2	2026-06-27 12:55:01.911	2026-06-27 13:00:45.732
f97dd2ef-a73d-4fc9-9304-59500cd86d68	Meeting	\N	meeting	t	3	2026-06-27 12:55:01.912	2026-06-27 13:00:45.733
19b90ce0-b6c1-4413-91ce-6dbcabe73ee5	MoU Signing	\N	mou-signing	t	4	2026-06-27 12:55:01.913	2026-06-27 13:00:45.734
4a0b12df-466c-4078-b1a7-42a4c944218f	Exposure Visit	\N	exposure-visit	t	5	2026-06-27 12:55:01.914	2026-06-27 13:00:45.734
ba39876c-1339-4409-ba6e-abd2843d854d	Field Visit	\N	field-visit	t	6	2026-06-27 12:55:01.914	2026-06-27 13:00:45.735
f957bcc4-9414-4d6c-8d2c-d3502cd470e7	Conference	\N	conference	t	7	2026-06-27 12:55:01.915	2026-06-27 13:00:45.736
3c2ed304-3ec7-4e0b-9c35-4c51c8e0a571	Awareness Programme	\N	awareness-programme	t	8	2026-06-27 12:55:01.915	2026-06-27 13:00:45.736
00c77880-4eca-48b6-af3b-200787ca67ac	Other Institutional Activity	\N	other-institutional-activity	t	9	2026-06-27 12:55:01.916	2026-06-27 13:00:45.737
\.


--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.events (id, event_type_id, training_type_id, title_en, title_hi, summary_en, summary_hi, description_en, description_hi, date_mode, start_date, end_date, location_text, district_id, block_id, cover_media_id, event_status, status_override, cancellation_reason, revised_start_date, dynamic_values, outcome_summary_en, outcome_summary_hi, key_highlights, final_participant_count, participant_male_count, participant_female_count, participant_other_count, completion_remarks_en, completion_remarks_hi, completed_date, translation_source, slug, publication_state, public_visibility, publish_start_at, published_at, archived_at, highlight_type, highlight_start_at, highlight_end_at, display_order, show_on_homepage, created_by, updated_by, created_at, updated_at) FROM stdin;
24f83e40-7156-4ee4-ab8a-ec2925392ca9	298679b8-df0f-4c14-ac32-3cac97092cb9	\N	Demo Honey Cooperative Activity 2	\N	Fictional completed event in Chatra for listing, filter, and detail tests.	\N	Includes linked programmes, institutions, documents, galleries, and commodities.	\N	single	2025-02-10	\N	Demo Community Hall, Chatra	d0e08c0c-31f8-4518-a427-283419fdd90e	\N	6853eb6c-ba01-4312-b751-b608641a94f5	completed	f	\N	\N	{"batch_number": 2, "test_fixture": true, "demonstration_topic": "Honey"}	Demo activity completed with positive fictional outcomes.	\N	Training; demonstration; cooperative planning	33	13	20	0	Fixture completion record.	\N	2025-02-12	missing	demo-cooperative-activity-2	published	t	\N	2026-01-15 08:00:00	\N	latest	2026-01-15 08:00:00	2027-01-15 08:00:00	2	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.898	2026-06-27 13:00:46.6
8424284e-5a82-451c-8863-baffeeb71f2b	f97dd2ef-a73d-4fc9-9304-59500cd86d68	\N	Demo Ragi / Millets Cooperative Activity 3	डेमो सहकारी गतिविधि 3	Fictional completed event in Deoghar for listing, filter, and detail tests.	\N	Includes linked programmes, institutions, documents, galleries, and commodities.	\N	single	2025-03-10	\N	Demo Community Hall, Deoghar	12b13393-e044-48ad-b999-7c6084714e9d	\N	cd1634aa-09ca-471d-a8b8-94968c0b7c9d	completed	f	\N	\N	{"batch_number": 3, "test_fixture": true, "demonstration_topic": "Ragi / Millets"}	Demo activity completed with positive fictional outcomes.	\N	Training; demonstration; cooperative planning	36	14	22	0	Fixture completion record.	\N	2025-03-12	manual	demo-cooperative-activity-3	published	t	\N	2026-01-15 08:00:00	\N	important	2026-01-15 08:00:00	2027-01-15 08:00:00	3	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.915	2026-06-27 13:00:46.62
c3a7c7ac-27c3-4c66-a7f0-79d0907d5272	19b90ce0-b6c1-4413-91ce-6dbcabe73ee5	5e1cc670-720c-4294-89fd-54bc49b2e7a7	Demo Sal Seed Cooperative Activity 4	\N	Fictional completed event in Dhanbad for listing, filter, and detail tests.	\N	Includes linked programmes, institutions, documents, galleries, and commodities.	\N	single	2025-04-10	\N	Demo Community Hall, Dhanbad	09fe9edc-6f60-4529-b959-8484f092de7e	\N	e572b312-06c9-47e3-b150-4fd9c2b4e59c	completed	f	\N	\N	{"batch_number": 4, "test_fixture": true, "demonstration_topic": "Sal Seed"}	Demo activity completed with positive fictional outcomes.	\N	Training; demonstration; cooperative planning	39	15	24	0	Fixture completion record.	\N	2025-04-12	missing	demo-cooperative-activity-4	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	4	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.936	2026-06-27 13:00:46.636
973f4234-e445-424a-8053-9490f7fcc956	4a0b12df-466c-4078-b1a7-42a4c944218f	\N	Demo Karanj Cooperative Activity 5	डेमो सहकारी गतिविधि 5	Fictional completed event in Dumka for listing, filter, and detail tests.	\N	Includes linked programmes, institutions, documents, galleries, and commodities.	\N	range	2025-05-10	2025-05-12	Demo Community Hall, Dumka	3a1ea0fb-f4dd-46ea-bcd9-4c1e8f3650f6	\N	cc4f583c-bd55-44e8-a408-9af5aa951372	completed	f	\N	\N	{"batch_number": 5, "test_fixture": true, "demonstration_topic": "Karanj"}	Demo activity completed with positive fictional outcomes.	\N	Training; demonstration; cooperative planning	42	16	26	0	Fixture completion record.	\N	2025-05-12	manual	demo-cooperative-activity-5	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	5	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.948	2026-06-27 13:00:46.646
82cf3be5-7fa5-45b9-8d71-08b15cab4642	ba39876c-1339-4409-ba6e-abd2843d854d	\N	Demo Tamarind Cooperative Activity 6	\N	Fictional completed event in East Singhbhum for listing, filter, and detail tests.	\N	Includes linked programmes, institutions, documents, galleries, and commodities.	\N	single	2025-06-10	\N	Demo Community Hall, East Singhbhum	3915d156-ef49-420d-a645-0f8d521cbe9d	\N	eb3877af-dd51-4f3c-8b6b-57570d63c33c	completed	f	\N	\N	{"batch_number": 6, "test_fixture": true, "demonstration_topic": "Tamarind"}	Demo activity completed with positive fictional outcomes.	\N	Training; demonstration; cooperative planning	45	17	28	0	Fixture completion record.	\N	2025-06-12	missing	demo-cooperative-activity-6	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	6	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.966	2026-06-27 13:00:46.663
3484093c-ee25-4a22-a2d2-e7c870c200df	f957bcc4-9414-4d6c-8d2c-d3502cd470e7	8420d28b-1cf4-4e30-9d75-1412e79ba349	Demo Lac Cooperative Activity 7	डेमो सहकारी गतिविधि 7	Fictional completed event in Garhwa for listing, filter, and detail tests.	\N	Includes linked programmes, institutions, documents, galleries, and commodities.	\N	single	2025-07-10	\N	Demo Community Hall, Garhwa	a65e8a15-c344-4895-8329-9bd0d816efbf	\N	18620944-e2bc-4e06-811d-f2c33d22ae84	completed	f	\N	\N	{"batch_number": 7, "test_fixture": true, "demonstration_topic": "Lac"}	Demo activity completed with positive fictional outcomes.	\N	Training; demonstration; cooperative planning	48	18	30	0	Fixture completion record.	\N	2025-07-12	manual	demo-cooperative-activity-7	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	7	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.977	2026-06-27 13:00:46.674
f20b1cdf-e8a9-43e4-a23b-f1a1783e0d2c	3c2ed304-3ec7-4e0b-9c35-4c51c8e0a571	\N	Demo Honey Cooperative Activity 8	\N	Fictional completed event in Giridih for listing, filter, and detail tests.	\N	Includes linked programmes, institutions, documents, galleries, and commodities.	\N	single	2025-08-10	\N	Demo Community Hall, Giridih	33e25b83-3af1-46ee-b50a-17f1eaf47a66	\N	bf9358c7-960b-4365-8b61-74f8788a7ad3	completed	f	\N	\N	{"batch_number": 8, "test_fixture": true, "demonstration_topic": "Honey"}	Demo activity completed with positive fictional outcomes.	\N	Training; demonstration; cooperative planning	51	19	32	0	Fixture completion record.	\N	2025-08-12	missing	demo-cooperative-activity-8	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	8	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.988	2026-06-27 13:00:46.683
118075dd-8c9b-4a71-ac35-3974fe107a57	19b90ce0-b6c1-4413-91ce-6dbcabe73ee5	8420d28b-1cf4-4e30-9d75-1412e79ba349	Demo Sal Seed Cooperative Activity 22	\N	Fictional cancelled event in Seraikela Kharsawan for listing, filter, and detail tests.	\N	Includes linked programmes, institutions, documents, galleries, and commodities.	\N	single	2026-10-10	\N	Demo Community Hall, Seraikela Kharsawan	b046ca98-5a72-48e6-a3d6-8605c68f2eeb	\N	6853eb6c-ba01-4312-b751-b608641a94f5	cancelled	t	Fictional cancellation for filter testing.	\N	{"batch_number": 22, "test_fixture": true, "demonstration_topic": "Sal Seed"}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	missing	demo-cooperative-activity-22	published	f	\N	2026-01-15 08:00:00	\N	\N	\N	\N	22	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.106	2026-06-27 13:00:46.8
46865834-4135-41ef-9a93-df11593deb78	f957bcc4-9414-4d6c-8d2c-d3502cd470e7	709c6b77-e169-474e-a370-2f2561fc3c8e	Demo Sal Seed Cooperative Activity 16	\N	Fictional scheduled event in Lohardaga for listing, filter, and detail tests.	\N	Includes linked programmes, institutions, documents, galleries, and commodities.	\N	single	2026-10-10	\N	Demo Community Hall, Lohardaga	14c04e14-a4be-404c-a2af-c306add55b0d	\N	e2271e6c-b88e-4a53-a4b0-41e888954ced	scheduled	f	\N	\N	{"batch_number": 16, "test_fixture": true, "demonstration_topic": "Sal Seed"}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	missing	demo-cooperative-activity-16	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	16	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.062	2026-06-27 13:00:46.754
e30b279f-fd18-497a-bd1a-a0b5beaafb63	00c77880-4eca-48b6-af3b-200787ca67ac	\N	Demo Ragi / Millets Cooperative Activity 9	डेमो सहकारी गतिविधि 9	Fictional completed event in Godda for listing, filter, and detail tests.	\N	Includes linked programmes, institutions, documents, galleries, and commodities.	\N	range	2025-09-10	2025-09-12	Demo Community Hall, Godda	5ea7f0c7-cd37-4360-ac58-de95d7eec88f	\N	84e59f6d-0311-404d-beaa-cf2172b47897	completed	f	\N	\N	{"batch_number": 9, "test_fixture": true, "demonstration_topic": "Ragi / Millets"}	Demo activity completed with positive fictional outcomes.	\N	Training; demonstration; cooperative planning	54	20	34	0	Fixture completion record.	\N	2025-09-12	manual	demo-cooperative-activity-9	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	9	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.998	2026-06-27 13:00:46.699
4e88a410-6772-4053-97f6-5664a8721c46	3c2ed304-3ec7-4e0b-9c35-4c51c8e0a571	\N	Demo Karanj Cooperative Activity 17	डेमो सहकारी गतिविधि 17	Fictional ongoing event in Pakur for listing, filter, and detail tests.	\N	Includes linked programmes, institutions, documents, galleries, and commodities.	\N	range	2026-11-10	2026-11-12	Demo Community Hall, Pakur	34adfbeb-9da7-40df-beae-6efef59458e6	\N	396777b0-30cb-446a-881f-7b71bb378d49	ongoing	f	\N	\N	{"batch_number": 17, "test_fixture": true, "demonstration_topic": "Karanj"}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	manual	demo-cooperative-activity-17	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	17	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.072	2026-06-27 13:00:46.762
29ef0b76-98de-438d-83b3-744e1a68d13a	4a0b12df-466c-4078-b1a7-42a4c944218f	\N	Demo Karanj Cooperative Activity 23	डेमो सहकारी गतिविधि 23	Fictional cancelled event in Simdega for listing, filter, and detail tests.	\N	Includes linked programmes, institutions, documents, galleries, and commodities.	\N	single	2026-11-10	\N	Demo Community Hall, Simdega	78b8972a-2db3-40bb-b8ba-4cefb357aff7	\N	cd1634aa-09ca-471d-a8b8-94968c0b7c9d	cancelled	t	Fictional cancellation for filter testing.	\N	{"batch_number": 23, "test_fixture": true, "demonstration_topic": "Karanj"}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	manual	demo-cooperative-activity-23	draft	t	\N	\N	\N	\N	\N	\N	23	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.113	2026-06-27 13:00:46.807
5e20a76d-7323-4bd8-b6ba-234b3aa33141	74b722ba-de0a-4313-9ec9-af30eec2825f	43b6fabc-eae3-4525-b729-738070046dd5	Demo Sal Seed Cooperative Activity 10	\N	Fictional completed event in Gumla for listing, filter, and detail tests.	\N	Includes linked programmes, institutions, documents, galleries, and commodities.	\N	single	2025-01-10	\N	Demo Community Hall, Gumla	a7f3f827-3863-4cb3-8ab8-2a8df83147df	\N	4e8d90dc-7a13-4084-addf-b476da99f4e6	completed	f	\N	\N	{"batch_number": 10, "test_fixture": true, "demonstration_topic": "Sal Seed"}	Demo activity completed with positive fictional outcomes.	\N	Training; demonstration; cooperative planning	57	21	36	0	Fixture completion record.	\N	2025-01-12	missing	demo-cooperative-activity-10	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	10	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.013	2026-06-27 13:00:46.708
73acb719-a481-4f93-9edb-395bcd8fafc5	f97dd2ef-a73d-4fc9-9304-59500cd86d68	\N	Demo Tamarind Cooperative Activity 12	\N	Fictional completed event in Jamtara for listing, filter, and detail tests.	\N	Includes linked programmes, institutions, documents, galleries, and commodities.	\N	single	2025-03-10	\N	Demo Community Hall, Jamtara	cf0d98e7-4f40-4426-9c27-3b41649469f1	\N	4c222680-3614-4531-8764-4c832b5f850b	completed	f	\N	\N	{"batch_number": 12, "test_fixture": true, "demonstration_topic": "Tamarind"}	Demo activity completed with positive fictional outcomes.	\N	Training; demonstration; cooperative planning	63	23	40	0	Fixture completion record.	\N	2025-03-12	missing	demo-cooperative-activity-12	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	12	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.03	2026-06-27 13:00:46.726
035a951d-39e7-41b6-a6e9-d88e8a69aef3	298679b8-df0f-4c14-ac32-3cac97092cb9	\N	Demo Honey Cooperative Activity 20	\N	Fictional postponed event in Ranchi for listing, filter, and detail tests.	\N	Includes linked programmes, institutions, documents, galleries, and commodities.	\N	single	2026-08-10	\N	Demo Community Hall, Ranchi	7e07b268-f055-4f23-9a1c-2a9923e08f67	\N	b0c9b33a-5ad2-450b-95b7-38ab448dfc01	postponed	t	\N	2027-02-15	{"batch_number": 20, "test_fixture": true, "demonstration_topic": "Honey"}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	missing	demo-cooperative-activity-20	unpublished	t	\N	\N	\N	\N	\N	\N	20	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.092	2026-06-27 13:00:46.786
eeeb1b36-e943-420c-835b-654d5300a00c	4a0b12df-466c-4078-b1a7-42a4c944218f	\N	Demo Honey Cooperative Activity 14	\N	Fictional scheduled event in Koderma for listing, filter, and detail tests.	\N	Includes linked programmes, institutions, documents, galleries, and commodities.	\N	single	2026-08-10	\N	Demo Community Hall, Koderma	14a0996f-885f-4f55-9dc0-3ceb5bc84d31	\N	0968939c-7d8e-44fa-b682-e301befe10d4	scheduled	f	\N	\N	{"batch_number": 14, "test_fixture": true, "demonstration_topic": "Honey"}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	missing	demo-cooperative-activity-14	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	14	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.044	2026-06-27 13:00:46.74
03ce842e-931e-46d8-b33d-fa2c8d6f2628	ba39876c-1339-4409-ba6e-abd2843d854d	\N	Demo Tamarind Cooperative Activity 24	\N	Fictional cancelled event in West Singhbhum for listing, filter, and detail tests.	\N	Includes linked programmes, institutions, documents, galleries, and commodities.	\N	single	2026-12-10	\N	Demo Community Hall, West Singhbhum	ed28dfdf-d0ae-46b7-a3e4-20d001079088	\N	e572b312-06c9-47e3-b150-4fd9c2b4e59c	cancelled	t	Fictional cancellation for filter testing.	\N	{"batch_number": 24, "test_fixture": true, "demonstration_topic": "Tamarind"}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	missing	demo-cooperative-activity-24	archived	f	\N	2026-01-15 08:00:00	2026-06-27 08:00:00	\N	\N	\N	24	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.12	2026-06-27 13:00:46.814
cca553d4-a3ca-4270-b166-adff9f3e1614	ba39876c-1339-4409-ba6e-abd2843d854d	\N	Demo Ragi / Millets Cooperative Activity 15	डेमो सहकारी गतिविधि 15	Fictional scheduled event in Latehar for listing, filter, and detail tests.	\N	Includes linked programmes, institutions, documents, galleries, and commodities.	\N	single	2026-09-10	\N	Demo Community Hall, Latehar	07f531b5-9897-440b-9083-6053fd25d936	\N	e2c4def6-a80f-493c-ac02-f98a476978f6	scheduled	f	\N	\N	{"batch_number": 15, "test_fixture": true, "demonstration_topic": "Ragi / Millets"}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	manual	demo-cooperative-activity-15	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	15	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.053	2026-06-27 13:00:46.747
797f6ea6-1380-4878-aa72-a5a478a272f0	00c77880-4eca-48b6-af3b-200787ca67ac	\N	Demo Tamarind Cooperative Activity 18	\N	Fictional ongoing event in Palamu for listing, filter, and detail tests.	\N	Includes linked programmes, institutions, documents, galleries, and commodities.	\N	single	2026-12-10	\N	Demo Community Hall, Palamu	8d81689c-b74b-44fb-bedb-3e07ec044ef4	\N	5098ef8f-1b93-429c-b6f4-c1311d6eedd3	ongoing	f	\N	\N	{"batch_number": 18, "test_fixture": true, "demonstration_topic": "Tamarind"}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	missing	demo-cooperative-activity-18	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	18	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.078	2026-06-27 13:00:46.771
b9404cc6-355d-4a30-8fd0-732236b1d762	f97dd2ef-a73d-4fc9-9304-59500cd86d68	\N	Demo Ragi / Millets Cooperative Activity 21	डेमो सहकारी गतिविधि 21	Fictional postponed event in Sahibganj for listing, filter, and detail tests.	\N	Includes linked programmes, institutions, documents, galleries, and commodities.	\N	range	2026-09-10	2026-09-12	Demo Community Hall, Sahibganj	2eb8b17a-4c52-4c7e-a2b0-fffe9aabb3e5	\N	3f24f935-ecf7-4c53-bd05-2d673cef6692	postponed	t	\N	2027-02-15	{"batch_number": 21, "test_fixture": true, "demonstration_topic": "Ragi / Millets"}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	manual	demo-cooperative-activity-21	published	t	2027-01-15 08:00:00	2026-01-15 08:00:00	\N	\N	\N	\N	21	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.099	2026-06-27 13:00:46.793
90816975-fff8-4e41-914c-4a434b87fbdf	74b722ba-de0a-4313-9ec9-af30eec2825f	709c6b77-e169-474e-a370-2f2561fc3c8e	Demo Lac Cooperative Activity 1	डेमो सहकारी गतिविधि 1	Fictional completed event in Bokaro for listing, filter, and detail tests.	\N	Includes linked programmes, institutions, documents, galleries, and commodities.	\N	range	2025-01-10	2025-01-12	Demo Community Hall, Bokaro	8d3043ee-820f-4ebc-ac56-8879f8e937f4	\N	3f24f935-ecf7-4c53-bd05-2d673cef6692	completed	f	\N	\N	{"batch_number": 1, "test_fixture": true, "demonstration_topic": "Lac"}	Demo activity completed with positive fictional outcomes.	\N	Training; demonstration; cooperative planning	30	12	18	0	Fixture completion record.	\N	2025-01-12	manual	demo-cooperative-activity-1	published	t	\N	2026-01-15 08:00:00	\N	featured	2026-01-15 08:00:00	2027-01-15 08:00:00	1	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.867	2026-06-27 13:00:46.578
b49ec2d0-2c30-4f6e-bd35-871a2f281eb7	298679b8-df0f-4c14-ac32-3cac97092cb9	\N	Demo Karanj Cooperative Activity 11	डेमो सहकारी गतिविधि 11	Fictional completed event in Hazaribagh for listing, filter, and detail tests.	\N	Includes linked programmes, institutions, documents, galleries, and commodities.	\N	single	2025-02-10	\N	Demo Community Hall, Hazaribagh	55db93f2-cda9-44ec-a882-4a8072f755ce	\N	1556504e-8fcc-4269-9d95-c388657993f5	completed	f	\N	\N	{"batch_number": 11, "test_fixture": true, "demonstration_topic": "Karanj"}	Demo activity completed with positive fictional outcomes.	\N	Training; demonstration; cooperative planning	60	22	38	0	Fixture completion record.	\N	2025-02-12	manual	demo-cooperative-activity-11	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	11	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.023	2026-06-27 13:00:46.717
476da260-931a-40a1-9242-44b81f0d4620	19b90ce0-b6c1-4413-91ce-6dbcabe73ee5	2575a66d-6984-4be7-a068-b5d1cf215abf	Demo Lac Cooperative Activity 13	डेमो सहकारी गतिविधि 13	Fictional scheduled event in Khunti for listing, filter, and detail tests.	\N	Includes linked programmes, institutions, documents, galleries, and commodities.	\N	range	2026-07-10	2026-07-12	Demo Community Hall, Khunti	c55140f4-a206-4bb4-9e40-cea4a362d3f6	\N	ffdd7879-2936-44f4-9e85-590ef7f5c988	scheduled	f	\N	\N	{"batch_number": 13, "test_fixture": true, "demonstration_topic": "Lac"}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	manual	demo-cooperative-activity-13	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	13	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.036	2026-06-27 13:00:46.733
da12f740-3f3c-4998-992b-70f049762e9d	74b722ba-de0a-4313-9ec9-af30eec2825f	5e1cc670-720c-4294-89fd-54bc49b2e7a7	Demo Lac Cooperative Activity 19	डेमो सहकारी गतिविधि 19	Fictional ongoing event in Ramgarh for listing, filter, and detail tests.	\N	Includes linked programmes, institutions, documents, galleries, and commodities.	\N	single	2026-07-10	\N	Demo Community Hall, Ramgarh	064a1b93-7c4c-4357-a140-d06d7b378b2b	\N	4268af2d-2e9d-49d9-8253-80bab0f71ce0	ongoing	f	\N	\N	{"batch_number": 19, "test_fixture": true, "demonstration_topic": "Lac"}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	manual	demo-cooperative-activity-19	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	19	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.085	2026-06-27 13:00:46.779
\.


--
-- Data for Name: faq_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.faq_categories (id, name_en, name_hi, slug, is_active, display_order, created_at, updated_at) FROM stdin;
72554db1-44d9-4cf5-ad8a-6ed520f2147c	General	\N	general	t	1	2026-06-27 12:55:01.975	2026-06-27 13:00:45.782
74a20759-3fb6-4da5-a8de-6d57f12d1e79	Membership	\N	membership	t	2	2026-06-27 12:55:01.978	2026-06-27 13:00:45.783
36b90199-caa0-44c7-8752-1659166ce9fb	Training	\N	training	t	3	2026-06-27 12:55:01.979	2026-06-27 13:00:45.784
e780d0be-937d-435f-a11c-6e17f3f69cdf	Procurement	\N	procurement	t	4	2026-06-27 12:55:01.979	2026-06-27 13:00:45.785
8bd4d007-11a8-4fde-b7b4-70cc0ab8d988	Schemes	\N	schemes	t	5	2026-06-27 12:55:01.98	2026-06-27 13:00:45.785
aa7afb73-8902-4713-a811-54f82897eadd	Digital Services	\N	digital-services	t	6	2026-06-27 12:55:01.98	2026-06-27 13:00:45.786
\.


--
-- Data for Name: faqs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.faqs (id, faq_category_id, question_en, question_hi, answer_en, answer_hi, slug, publication_state, public_visibility, publish_start_at, published_at, archived_at, highlight_type, highlight_start_at, highlight_end_at, display_order, show_on_homepage, created_by, updated_by, created_at, updated_at) FROM stdin;
b1ea9440-00cf-4d88-94f7-b82e35b97bd4	74a20759-3fb6-4da5-a8de-6d57f12d1e79	How does fictional CMS feature 2 work?	\N	This answer is fictional and exists only to test FAQ listing, search, categories, and visibility.	\N	demo-faq-2	published	t	\N	2026-01-15 08:00:00	\N	latest	2026-01-15 08:00:00	2027-01-15 08:00:00	2	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.361	2026-06-27 13:00:47.007
9ed28ef6-957f-4389-a5ab-8d35b25432a9	36b90199-caa0-44c7-8752-1659166ce9fb	How does fictional CMS feature 3 work?	डेमो प्रश्न 3?	This answer is fictional and exists only to test FAQ listing, search, categories, and visibility.	यह केवल परीक्षण उत्तर है।	demo-faq-3	published	t	\N	2026-01-15 08:00:00	\N	important	2026-01-15 08:00:00	2027-01-15 08:00:00	3	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.362	2026-06-27 13:00:47.008
25078330-d1b6-4a41-ac09-c40d2de0f76a	e780d0be-937d-435f-a11c-6e17f3f69cdf	How does fictional CMS feature 4 work?	\N	This answer is fictional and exists only to test FAQ listing, search, categories, and visibility.	\N	demo-faq-4	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	4	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.364	2026-06-27 13:00:47.009
55ee1b47-2848-4c22-bbd0-3716fe6971c4	8bd4d007-11a8-4fde-b7b4-70cc0ab8d988	How does fictional CMS feature 5 work?	डेमो प्रश्न 5?	This answer is fictional and exists only to test FAQ listing, search, categories, and visibility.	यह केवल परीक्षण उत्तर है।	demo-faq-5	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	5	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.365	2026-06-27 13:00:47.011
eac1023f-2b84-4485-b4d5-bbcc473344ff	aa7afb73-8902-4713-a811-54f82897eadd	How does fictional CMS feature 6 work?	\N	This answer is fictional and exists only to test FAQ listing, search, categories, and visibility.	\N	demo-faq-6	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	6	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.367	2026-06-27 13:00:47.012
6f111ce9-d7a2-4416-9853-4ef7aa549a64	72554db1-44d9-4cf5-ad8a-6ed520f2147c	How does fictional CMS feature 7 work?	डेमो प्रश्न 7?	This answer is fictional and exists only to test FAQ listing, search, categories, and visibility.	यह केवल परीक्षण उत्तर है।	demo-faq-7	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	7	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.368	2026-06-27 13:00:47.014
f1980a85-d424-4157-aeb8-4423415a145b	aa7afb73-8902-4713-a811-54f82897eadd	How does fictional CMS feature 12 work?	\N	This answer is fictional and exists only to test FAQ listing, search, categories, and visibility.	\N	demo-faq-12	archived	f	\N	2026-01-15 08:00:00	2026-06-27 08:00:00	\N	\N	\N	12	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.375	2026-06-27 13:00:47.021
bc612f54-7ff6-43ab-a899-ab05258c4847	74a20759-3fb6-4da5-a8de-6d57f12d1e79	How does fictional CMS feature 8 work?	\N	This answer is fictional and exists only to test FAQ listing, search, categories, and visibility.	\N	demo-faq-8	unpublished	t	\N	\N	\N	\N	\N	\N	8	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.37	2026-06-27 13:00:47.015
d812f5f5-2ee3-4278-b731-1716bb0c6c2f	36b90199-caa0-44c7-8752-1659166ce9fb	How does fictional CMS feature 9 work?	डेमो प्रश्न 9?	This answer is fictional and exists only to test FAQ listing, search, categories, and visibility.	यह केवल परीक्षण उत्तर है।	demo-faq-9	published	t	2027-01-15 08:00:00	2026-01-15 08:00:00	\N	\N	\N	\N	9	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.371	2026-06-27 13:00:47.016
e65ac6ab-c8e2-490e-a7b5-f7137e015c78	e780d0be-937d-435f-a11c-6e17f3f69cdf	How does fictional CMS feature 10 work?	\N	This answer is fictional and exists only to test FAQ listing, search, categories, and visibility.	\N	demo-faq-10	published	f	\N	2026-01-15 08:00:00	\N	\N	\N	\N	10	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.373	2026-06-27 13:00:47.018
df9aed3d-23dc-44e1-85eb-af9b5c9b6195	8bd4d007-11a8-4fde-b7b4-70cc0ab8d988	How does fictional CMS feature 11 work?	डेमो प्रश्न 11?	This answer is fictional and exists only to test FAQ listing, search, categories, and visibility.	यह केवल परीक्षण उत्तर है।	demo-faq-11	draft	t	\N	\N	\N	\N	\N	\N	11	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.374	2026-06-27 13:00:47.019
b7825f1b-4422-4602-8ba9-f8dc855a2db1	72554db1-44d9-4cf5-ad8a-6ed520f2147c	How does fictional CMS feature 1 work?	डेमो प्रश्न 1?	This answer is fictional and exists only to test FAQ listing, search, categories, and visibility.	यह केवल परीक्षण उत्तर है।	demo-faq-1	published	t	\N	2026-01-15 08:00:00	\N	featured	2026-01-15 08:00:00	2027-01-15 08:00:00	1	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.355	2026-06-27 13:00:47.005
\.


--
-- Data for Name: financial_years; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.financial_years (id, label, start_date, end_date, is_active, created_at, updated_at) FROM stdin;
d199ab88-ee7a-4503-b573-dbb8a3abf773	2023-2024	2023-04-01	2024-03-31	t	2026-06-27 12:55:02.087	2026-06-27 13:00:45.852
523d4ffa-be85-4db3-90d7-37a50efa298e	2024-2025	2024-04-01	2025-03-31	t	2026-06-27 12:55:02.052	2026-06-27 13:00:45.854
f5f4e2cd-face-4f7c-94df-0f2c64f8a931	2025-2026	2025-04-01	2026-03-31	t	2026-06-27 12:55:02.055	2026-06-27 13:00:45.855
86387c48-e2fb-4c68-9de5-0a953467da42	2026-2027	2026-04-01	2027-03-31	t	2026-06-27 12:55:02.056	2026-06-27 13:00:45.855
\.


--
-- Data for Name: galleries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.galleries (id, title_en, title_hi, description_en, description_hi, cover_media_id, slug, publication_state, public_visibility, publish_start_at, published_at, archived_at, highlight_type, highlight_start_at, highlight_end_at, display_order, show_on_homepage, created_by, updated_by, created_at, updated_at) FROM stdin;
39849df0-72ac-4788-b87c-4836168527c7	Demo Field Activity Gallery 3	डेमो गतिविधि गैलरी 3	Fictional gallery using compact reusable fixture images.	\N	cd1634aa-09ca-471d-a8b8-94968c0b7c9d	demo-field-gallery-3	published	t	\N	2026-01-15 08:00:00	\N	important	2026-01-15 08:00:00	2027-01-15 08:00:00	3	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.841	2026-06-27 13:00:46.549
05429ae9-b181-4e6c-9e03-2e74f0f36281	Demo Field Activity Gallery 4	\N	Fictional gallery using compact reusable fixture images.	\N	e572b312-06c9-47e3-b150-4fd9c2b4e59c	demo-field-gallery-4	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	4	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.845	2026-06-27 13:00:46.552
92623dd4-dec8-4416-8953-d8101fe2731b	Demo Field Activity Gallery 5	डेमो गतिविधि गैलरी 5	Fictional gallery using compact reusable fixture images.	\N	cc4f583c-bd55-44e8-a408-9af5aa951372	demo-field-gallery-5	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	5	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.849	2026-06-27 13:00:46.556
f31b6048-4e3b-4d60-a906-cd469e2eb208	Demo Field Activity Gallery 6	\N	Fictional gallery using compact reusable fixture images.	\N	eb3877af-dd51-4f3c-8b6b-57570d63c33c	demo-field-gallery-6	unpublished	t	\N	\N	\N	\N	\N	\N	6	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.852	2026-06-27 13:00:46.559
6a54114c-6059-4bf2-87b6-db3b1ea5639d	Demo Field Activity Gallery 7	डेमो गतिविधि गैलरी 7	Fictional gallery using compact reusable fixture images.	\N	18620944-e2bc-4e06-811d-f2c33d22ae84	demo-field-gallery-7	published	t	2027-01-15 08:00:00	2026-01-15 08:00:00	\N	\N	\N	\N	7	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.855	2026-06-27 13:00:46.563
5732a81f-6f2b-456b-89f8-242e3dafc01b	Demo Field Activity Gallery 8	\N	Fictional gallery using compact reusable fixture images.	\N	bf9358c7-960b-4365-8b61-74f8788a7ad3	demo-field-gallery-8	published	f	\N	2026-01-15 08:00:00	\N	\N	\N	\N	8	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.859	2026-06-27 13:00:46.567
7a44f5a2-ec5c-4799-8e40-2fddaa561c42	Demo Field Activity Gallery 9	डेमो गतिविधि गैलरी 9	Fictional gallery using compact reusable fixture images.	\N	84e59f6d-0311-404d-beaa-cf2172b47897	demo-field-gallery-9	draft	t	\N	\N	\N	\N	\N	\N	9	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.861	2026-06-27 13:00:46.571
3da241ad-da2b-4b23-b7bb-dac0cb6570cf	Demo Field Activity Gallery 10	\N	Fictional gallery using compact reusable fixture images.	\N	4e8d90dc-7a13-4084-addf-b476da99f4e6	demo-field-gallery-10	archived	f	\N	2026-01-15 08:00:00	2026-06-27 08:00:00	\N	\N	\N	10	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.863	2026-06-27 13:00:46.574
efe870eb-3011-4988-8d3f-b852082e623e	Demo Field Activity Gallery 1	डेमो गतिविधि गैलरी 1	Fictional gallery using compact reusable fixture images.	\N	3f24f935-ecf7-4c53-bd05-2d673cef6692	demo-field-gallery-1	published	t	\N	2026-01-15 08:00:00	\N	featured	2026-01-15 08:00:00	2027-01-15 08:00:00	1	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.829	2026-06-27 13:00:46.539
85fab47f-42a1-4bd4-8d52-081d94c70485	Demo Field Activity Gallery 2	\N	Fictional gallery using compact reusable fixture images.	\N	6853eb6c-ba01-4312-b751-b608641a94f5	demo-field-gallery-2	published	t	\N	2026-01-15 08:00:00	\N	latest	2026-01-15 08:00:00	2027-01-15 08:00:00	2	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.837	2026-06-27 13:00:46.545
\.


--
-- Data for Name: gallery_images; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gallery_images (id, gallery_id, media_id, display_order, caption_en, caption_hi) FROM stdin;
7cce19a1-7574-4aff-b075-e6fd8c60fb47	efe870eb-3011-4988-8d3f-b852082e623e	3f24f935-ecf7-4c53-bd05-2d673cef6692	1	Fictional activity image 1	काल्पनिक गतिविधि चित्र
a1c6fcec-300a-458d-bde6-a039250e5cc7	efe870eb-3011-4988-8d3f-b852082e623e	6853eb6c-ba01-4312-b751-b608641a94f5	2	Fictional activity image 2	\N
d9aefdd1-e325-45a4-96ca-14cefe3378ac	efe870eb-3011-4988-8d3f-b852082e623e	cd1634aa-09ca-471d-a8b8-94968c0b7c9d	3	Fictional activity image 3	\N
e87c1b4a-5d95-4c64-8c94-b67677a4de0e	85fab47f-42a1-4bd4-8d52-081d94c70485	e572b312-06c9-47e3-b150-4fd9c2b4e59c	1	Fictional activity image 1	काल्पनिक गतिविधि चित्र
5141034d-e64f-4c86-8e97-146b06c552f2	85fab47f-42a1-4bd4-8d52-081d94c70485	cc4f583c-bd55-44e8-a408-9af5aa951372	2	Fictional activity image 2	\N
2f276803-94d3-4e06-a03c-70297d1a255f	85fab47f-42a1-4bd4-8d52-081d94c70485	eb3877af-dd51-4f3c-8b6b-57570d63c33c	3	Fictional activity image 3	\N
3025b3ba-8da9-4aa1-9584-62c49ebe513d	39849df0-72ac-4788-b87c-4836168527c7	18620944-e2bc-4e06-811d-f2c33d22ae84	1	Fictional activity image 1	काल्पनिक गतिविधि चित्र
3e61c110-3e83-4865-ae78-fc525d587778	39849df0-72ac-4788-b87c-4836168527c7	bf9358c7-960b-4365-8b61-74f8788a7ad3	2	Fictional activity image 2	\N
11bf35e8-cef2-43f0-9f42-fdea6be38bfb	39849df0-72ac-4788-b87c-4836168527c7	84e59f6d-0311-404d-beaa-cf2172b47897	3	Fictional activity image 3	\N
fc0caea8-2e0e-4f85-bc3e-79f7d11f1dd0	05429ae9-b181-4e6c-9e03-2e74f0f36281	4e8d90dc-7a13-4084-addf-b476da99f4e6	1	Fictional activity image 1	काल्पनिक गतिविधि चित्र
eb92d1ba-e344-499c-90ab-0fc7f78a1363	05429ae9-b181-4e6c-9e03-2e74f0f36281	1556504e-8fcc-4269-9d95-c388657993f5	2	Fictional activity image 2	\N
1eac3263-e3b3-4266-ae74-6a2959b09efa	05429ae9-b181-4e6c-9e03-2e74f0f36281	4c222680-3614-4531-8764-4c832b5f850b	3	Fictional activity image 3	\N
ea9d9a80-f235-4505-8c62-8c4dbfa14b85	92623dd4-dec8-4416-8953-d8101fe2731b	ffdd7879-2936-44f4-9e85-590ef7f5c988	1	Fictional activity image 1	काल्पनिक गतिविधि चित्र
a723e35a-bb09-4a4b-99d1-da570de37dc7	92623dd4-dec8-4416-8953-d8101fe2731b	0968939c-7d8e-44fa-b682-e301befe10d4	2	Fictional activity image 2	\N
b5846d1a-64e1-4f4a-aea4-07a89409cee0	92623dd4-dec8-4416-8953-d8101fe2731b	e2c4def6-a80f-493c-ac02-f98a476978f6	3	Fictional activity image 3	\N
18d41115-3e65-4e53-8973-bf3ffded0051	f31b6048-4e3b-4d60-a906-cd469e2eb208	e2271e6c-b88e-4a53-a4b0-41e888954ced	1	Fictional activity image 1	काल्पनिक गतिविधि चित्र
91cde087-2871-4c3c-99cf-46855ecb4017	f31b6048-4e3b-4d60-a906-cd469e2eb208	396777b0-30cb-446a-881f-7b71bb378d49	2	Fictional activity image 2	\N
8403f419-8e0c-48da-a5c8-fe390e2422da	f31b6048-4e3b-4d60-a906-cd469e2eb208	5098ef8f-1b93-429c-b6f4-c1311d6eedd3	3	Fictional activity image 3	\N
dab97cec-ed15-424f-9bdc-755be4626c7a	6a54114c-6059-4bf2-87b6-db3b1ea5639d	4268af2d-2e9d-49d9-8253-80bab0f71ce0	1	Fictional activity image 1	काल्पनिक गतिविधि चित्र
6cdee804-981c-43be-a1d0-ef698b174231	6a54114c-6059-4bf2-87b6-db3b1ea5639d	b0c9b33a-5ad2-450b-95b7-38ab448dfc01	2	Fictional activity image 2	\N
a4492f63-595b-47b2-b803-9d86430cc62c	6a54114c-6059-4bf2-87b6-db3b1ea5639d	3f24f935-ecf7-4c53-bd05-2d673cef6692	3	Fictional activity image 3	\N
fb3dc0d0-2211-48d9-be1f-f735b9223574	5732a81f-6f2b-456b-89f8-242e3dafc01b	6853eb6c-ba01-4312-b751-b608641a94f5	1	Fictional activity image 1	काल्पनिक गतिविधि चित्र
e2f6efbf-1fa1-4053-b3c5-0de1d8640417	5732a81f-6f2b-456b-89f8-242e3dafc01b	cd1634aa-09ca-471d-a8b8-94968c0b7c9d	2	Fictional activity image 2	\N
8f333eba-0223-4192-b1dd-28004183d69d	5732a81f-6f2b-456b-89f8-242e3dafc01b	e572b312-06c9-47e3-b150-4fd9c2b4e59c	3	Fictional activity image 3	\N
fc61a113-96a1-4399-8c9a-10f8ab00acdd	7a44f5a2-ec5c-4799-8e40-2fddaa561c42	cc4f583c-bd55-44e8-a408-9af5aa951372	1	Fictional activity image 1	काल्पनिक गतिविधि चित्र
a547c02e-55b9-4f28-b489-a5b8f633406b	7a44f5a2-ec5c-4799-8e40-2fddaa561c42	eb3877af-dd51-4f3c-8b6b-57570d63c33c	2	Fictional activity image 2	\N
daede9a0-540f-49a1-b08c-303a26647aa5	7a44f5a2-ec5c-4799-8e40-2fddaa561c42	18620944-e2bc-4e06-811d-f2c33d22ae84	3	Fictional activity image 3	\N
c926127c-0525-4829-b1fd-aec1c58e6396	3da241ad-da2b-4b23-b7bb-dac0cb6570cf	bf9358c7-960b-4365-8b61-74f8788a7ad3	1	Fictional activity image 1	काल्पनिक गतिविधि चित्र
2e8a7216-ae7f-4866-ab39-e336f34ecbc7	3da241ad-da2b-4b23-b7bb-dac0cb6570cf	84e59f6d-0311-404d-beaa-cf2172b47897	2	Fictional activity image 2	\N
fabcae2c-6efc-42ec-a9c8-2ca3816403d6	3da241ad-da2b-4b23-b7bb-dac0cb6570cf	4e8d90dc-7a13-4084-addf-b476da99f4e6	3	Fictional activity image 3	\N
\.


--
-- Data for Name: institution_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.institution_types (id, name_en, name_hi, slug, is_active, display_order, created_at, updated_at) FROM stdin;
95978d27-ba32-4428-8949-8efb771e2949	Government Department	\N	government-department	t	1	2026-06-27 12:55:01.931	2026-06-27 13:00:45.748
c28b1bfd-2f62-480a-a131-491bdff15bbb	Training Institution	\N	training-institution	t	2	2026-06-27 12:55:01.934	2026-06-27 13:00:45.749
e5094e89-e1ee-4924-a2b7-5e485f50f08f	University	\N	university	t	3	2026-06-27 12:55:01.935	2026-06-27 13:00:45.75
1bd3c0a1-bf5d-4a54-99b9-9ab87a332dc7	NGO	\N	ngo	t	4	2026-06-27 12:55:01.935	2026-06-27 13:00:45.751
6378b980-4ede-4b11-af22-f77e22ff0450	Corporate Buyer	\N	corporate-buyer	t	5	2026-06-27 12:55:01.936	2026-06-27 13:00:45.751
8d8703c8-17cd-4079-aeea-e2396b98e993	Financial Institution	\N	financial-institution	t	6	2026-06-27 12:55:01.936	2026-06-27 13:00:45.752
85fbc056-fbb4-4eeb-bc98-f6ac0930d95a	Technical Agency	\N	technical-agency	t	7	2026-06-27 12:55:01.937	2026-06-27 13:00:45.753
b0f7b3aa-305d-4e47-84ed-8543e76ac96c	Cooperative Organization	\N	cooperative-organization	t	8	2026-06-27 12:55:01.938	2026-06-27 13:00:45.754
827a67e8-6ffe-4cc3-922f-e1314226dd34	Other Partner	\N	other-partner	t	9	2026-06-27 12:55:01.938	2026-06-27 13:00:45.754
\.


--
-- Data for Name: institutional_memberships; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.institutional_memberships (id, institution_id, membership_level, membership_type, membership_number, district_id, district_union_id, reporting_period_id, status, join_date, notes_en, notes_hi, slug, publication_state, public_visibility, publish_start_at, published_at, archived_at, highlight_type, highlight_start_at, highlight_end_at, display_order, show_on_homepage, created_by, updated_by, created_at, updated_at) FROM stdin;
dbe31499-8719-481f-9dc4-ba24d9d372cc	a7882c7b-b339-405a-98ff-787ea22af71e	sidhkofed	primary	DEMO-MEM-0001	8d3043ee-820f-4ebc-ac56-8879f8e937f4	\N	0cc986ce-b9ec-441c-9d0b-ddadad42e6e1	active	2023-01-01	Fictional institutional membership.	\N	demo-membership-1	published	t	\N	2026-01-15 08:00:00	\N	featured	2026-01-15 08:00:00	2027-01-15 08:00:00	1	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.417	2026-06-27 13:00:47.051
c8bd3468-525c-4b9d-9e05-72352d2925f4	76216f41-cbea-4f28-af6e-325511eec36b	sidhkofed	nominal	DEMO-MEM-0002	d0e08c0c-31f8-4518-a427-283419fdd90e	\N	077c30c4-0298-49d2-a725-341e51f0260c	active	2024-02-01	Fictional institutional membership.	\N	demo-membership-2	published	t	\N	2026-01-15 08:00:00	\N	latest	2026-01-15 08:00:00	2027-01-15 08:00:00	2	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.427	2026-06-27 13:00:47.054
ba466610-2fcd-4dcd-8af5-7ac3cab4b10f	4a4f9cba-ad6a-42ca-a33a-51c237b24959	district_union	primary	DEMO-MEM-0003	12b13393-e044-48ad-b999-7c6084714e9d	eb467702-6b19-4e1a-91bb-8e0b6f8846b5	c449cf5d-5ec2-47c7-a8c7-f746f1420b0e	active	2025-03-01	Fictional institutional membership.	\N	demo-membership-3	published	t	\N	2026-01-15 08:00:00	\N	important	2026-01-15 08:00:00	2027-01-15 08:00:00	3	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.43	2026-06-27 13:00:47.056
be5b785b-42f3-47fb-aa5e-5b444f9c60cf	eb467702-6b19-4e1a-91bb-8e0b6f8846b5	district_union	nominal	DEMO-MEM-0004	09fe9edc-6f60-4529-b959-8484f092de7e	1ba549fe-161d-41c1-8df5-6ac141b9a203	16eef30e-3720-43c3-9d92-e2206cde1933	active	2023-04-01	Fictional institutional membership.	\N	demo-membership-4	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	4	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.433	2026-06-27 13:00:47.057
8de365a5-0c07-4ae0-9ab5-978e844ba740	1ba549fe-161d-41c1-8df5-6ac141b9a203	sidhkofed	primary	DEMO-MEM-0005	3a1ea0fb-f4dd-46ea-bcd9-4c1e8f3650f6	\N	9cb5ee9c-5de0-473d-9f75-1f1d22934172	active	2024-05-01	Fictional institutional membership.	\N	demo-membership-5	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	5	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.435	2026-06-27 13:00:47.06
915e90a1-0325-4855-a541-5e898619f23f	8e19a717-50c2-4a26-b973-a6886b536573	sidhkofed	nominal	DEMO-MEM-0006	3915d156-ef49-420d-a645-0f8d521cbe9d	\N	ca9e1bde-a1e9-4ed6-a46e-d8f4300fee9f	active	2025-06-01	Fictional institutional membership.	\N	demo-membership-6	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	6	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.437	2026-06-27 13:00:47.061
55908c38-7030-4bbd-9e8b-caba99f5447c	0e9b51f2-f393-4f8d-a004-2d22190ab744	district_union	primary	DEMO-MEM-0007	a65e8a15-c344-4895-8329-9bd0d816efbf	aaaf27d6-9868-4bff-b595-e86bf092a2f1	b03a9306-05a1-4e31-933e-0216f8b1ef0c	active	2023-07-01	Fictional institutional membership.	\N	demo-membership-7	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	7	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.439	2026-06-27 13:00:47.063
d00b8bae-cd9f-4150-ab55-a85023b5a727	aaaf27d6-9868-4bff-b595-e86bf092a2f1	district_union	nominal	DEMO-MEM-0008	33e25b83-3af1-46ee-b50a-17f1eaf47a66	ae84e287-f81d-44ed-86ce-129141d2f407	abfc1441-2107-448a-8420-6c4ba6379691	active	2024-08-01	Fictional institutional membership.	\N	demo-membership-8	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	8	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.441	2026-06-27 13:00:47.064
61e54257-5930-432b-b95b-687628106dee	ae84e287-f81d-44ed-86ce-129141d2f407	sidhkofed	primary	DEMO-MEM-0009	5ea7f0c7-cd37-4360-ac58-de95d7eec88f	\N	3a730236-d6b1-4ae1-843e-101e130a5882	active	2025-09-01	Fictional institutional membership.	\N	demo-membership-9	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	9	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.444	2026-06-27 13:00:47.066
cf24dda4-aa5d-4249-86f7-4d632d8147d9	bff1ae9a-2a5e-4ade-970a-2b2e5d2b66e3	sidhkofed	nominal	DEMO-MEM-0010	a7f3f827-3863-4cb3-8ab8-2a8df83147df	\N	1e2a0590-208f-4db5-a7bc-02db1a0e92b4	active	2023-01-01	Fictional institutional membership.	\N	demo-membership-10	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	10	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.446	2026-06-27 13:00:47.068
f2dd1f25-9b0e-4441-b9ea-13a00248e4b2	4eb59158-f8ac-44c5-aa57-21c73ace31b2	district_union	primary	DEMO-MEM-0011	55db93f2-cda9-44ec-a882-4a8072f755ce	a7934626-a21d-48ad-967c-7cb38d69d4b3	5a81ff1c-97b8-4c10-b034-eef98ae10c7d	active	2024-02-01	Fictional institutional membership.	\N	demo-membership-11	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	11	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.447	2026-06-27 13:00:47.07
f72640ba-c990-4a4c-a7dd-631590a73021	a7934626-a21d-48ad-967c-7cb38d69d4b3	district_union	nominal	DEMO-MEM-0012	cf0d98e7-4f40-4426-9c27-3b41649469f1	a7882c7b-b339-405a-98ff-787ea22af71e	408e8c4f-915a-4099-a31c-16e780f3c918	active	2025-03-01	Fictional institutional membership.	\N	demo-membership-12	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	12	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.449	2026-06-27 13:00:47.071
e6ffbe58-4c3b-4663-b5ea-d722ebda5cc2	a7882c7b-b339-405a-98ff-787ea22af71e	sidhkofed	primary	DEMO-MEM-0013	c55140f4-a206-4bb4-9e40-cea4a362d3f6	\N	9be5231e-d84a-45cf-b040-e1c18052bb8c	active	2023-04-01	Fictional institutional membership.	\N	demo-membership-13	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	13	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.452	2026-06-27 13:00:47.072
d1598a00-2d7f-40b4-b48d-6a79805bb893	76216f41-cbea-4f28-af6e-325511eec36b	sidhkofed	nominal	DEMO-MEM-0014	14a0996f-885f-4f55-9dc0-3ceb5bc84d31	\N	adb11090-385a-4408-961e-da832f2c24f9	active	2024-05-01	Fictional institutional membership.	\N	demo-membership-14	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	14	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.454	2026-06-27 13:00:47.074
a0601311-f011-4d43-aa86-c656eefe44e3	4a4f9cba-ad6a-42ca-a33a-51c237b24959	district_union	primary	DEMO-MEM-0015	07f531b5-9897-440b-9083-6053fd25d936	eb467702-6b19-4e1a-91bb-8e0b6f8846b5	20c7c2fd-5a09-480e-8353-1df0b5dc8bf2	active	2025-06-01	Fictional institutional membership.	\N	demo-membership-15	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	15	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.456	2026-06-27 13:00:47.076
4f666c52-8d80-410c-b47f-c3a8e960b764	eb467702-6b19-4e1a-91bb-8e0b6f8846b5	district_union	nominal	DEMO-MEM-0016	14c04e14-a4be-404c-a2af-c306add55b0d	1ba549fe-161d-41c1-8df5-6ac141b9a203	0cc986ce-b9ec-441c-9d0b-ddadad42e6e1	active	2023-07-01	Fictional institutional membership.	\N	demo-membership-16	unpublished	t	\N	\N	\N	\N	\N	\N	16	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.458	2026-06-27 13:00:47.077
315b2545-44a1-4aef-8eee-dd17d6c8bd6e	1ba549fe-161d-41c1-8df5-6ac141b9a203	sidhkofed	primary	DEMO-MEM-0017	34adfbeb-9da7-40df-beae-6efef59458e6	\N	077c30c4-0298-49d2-a725-341e51f0260c	active	2024-08-01	Fictional institutional membership.	\N	demo-membership-17	published	t	2027-01-15 08:00:00	2026-01-15 08:00:00	\N	\N	\N	\N	17	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.459	2026-06-27 13:00:47.079
5e0ed188-47d2-4d24-821a-78e59b04b40e	8e19a717-50c2-4a26-b973-a6886b536573	sidhkofed	nominal	DEMO-MEM-0018	8d81689c-b74b-44fb-bedb-3e07ec044ef4	\N	c449cf5d-5ec2-47c7-a8c7-f746f1420b0e	inactive	2025-09-01	Fictional institutional membership.	\N	demo-membership-18	published	f	\N	2026-01-15 08:00:00	\N	\N	\N	\N	18	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.461	2026-06-27 13:00:47.081
31319ceb-c573-4c63-beb2-9eda8ebead5d	0e9b51f2-f393-4f8d-a004-2d22190ab744	district_union	primary	DEMO-MEM-0019	064a1b93-7c4c-4357-a140-d06d7b378b2b	aaaf27d6-9868-4bff-b595-e86bf092a2f1	16eef30e-3720-43c3-9d92-e2206cde1933	inactive	2023-01-01	Fictional institutional membership.	\N	demo-membership-19	draft	t	\N	\N	\N	\N	\N	\N	19	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.463	2026-06-27 13:00:47.083
58f010af-134b-4ade-a2f5-11ddff08e641	aaaf27d6-9868-4bff-b595-e86bf092a2f1	district_union	nominal	DEMO-MEM-0020	7e07b268-f055-4f23-9a1c-2a9923e08f67	ae84e287-f81d-44ed-86ce-129141d2f407	9cb5ee9c-5de0-473d-9f75-1f1d22934172	inactive	2024-02-01	Fictional institutional membership.	\N	demo-membership-20	archived	f	\N	2026-01-15 08:00:00	2026-06-27 08:00:00	\N	\N	\N	20	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.465	2026-06-27 13:00:47.084
\.


--
-- Data for Name: institutions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.institutions (id, institution_type_id, name_en, name_hi, description_en, description_hi, address_en, address_hi, website_url, logo_media_id, district_id, contact_email, contact_phone, slug, publication_state, public_visibility, publish_start_at, published_at, archived_at, highlight_type, highlight_start_at, highlight_end_at, display_order, show_on_homepage, created_by, updated_by, created_at, updated_at) FROM stdin;
a7882c7b-b339-405a-98ff-787ea22af71e	95978d27-ba32-4428-8949-8efb771e2949	Demo Bokaro Cooperative Institution 1	डेमो सहकारी संस्था 1	Fictional partner institution supporting lac livelihoods.	यह केवल परीक्षण के लिए काल्पनिक संस्था है।	Test Campus 1, Bokaro, Jharkhand	\N	https://example.test/institutions/1	3f24f935-ecf7-4c53-bd05-2d673cef6692	8d3043ee-820f-4ebc-ac56-8879f8e937f4	institution1@example.test	+91-6500-000-001	demo-cooperative-institution-1	published	t	\N	2026-01-15 08:00:00	\N	featured	2026-01-15 08:00:00	2027-01-15 08:00:00	1	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.383	2026-06-27 13:00:46.122
76216f41-cbea-4f28-af6e-325511eec36b	c28b1bfd-2f62-480a-a131-491bdff15bbb	Demo Chatra Cooperative Institution 2	\N	Fictional partner institution supporting honey livelihoods.	\N	Test Campus 2, Chatra, Jharkhand	\N	https://example.test/institutions/2	6853eb6c-ba01-4312-b751-b608641a94f5	d0e08c0c-31f8-4518-a427-283419fdd90e	institution2@example.test	+91-6500-000-002	demo-cooperative-institution-2	published	t	\N	2026-01-15 08:00:00	\N	latest	2026-01-15 08:00:00	2027-01-15 08:00:00	2	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.39	2026-06-27 13:00:46.125
4a4f9cba-ad6a-42ca-a33a-51c237b24959	e5094e89-e1ee-4924-a2b7-5e485f50f08f	Demo Deoghar Cooperative Institution 3	डेमो सहकारी संस्था 3	Fictional partner institution supporting ragi / millets livelihoods.	यह केवल परीक्षण के लिए काल्पनिक संस्था है।	Test Campus 3, Deoghar, Jharkhand	\N	https://example.test/institutions/3	cd1634aa-09ca-471d-a8b8-94968c0b7c9d	12b13393-e044-48ad-b999-7c6084714e9d	institution3@example.test	+91-6500-000-003	demo-cooperative-institution-3	published	t	\N	2026-01-15 08:00:00	\N	important	2026-01-15 08:00:00	2027-01-15 08:00:00	3	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.392	2026-06-27 13:00:46.126
eb467702-6b19-4e1a-91bb-8e0b6f8846b5	1bd3c0a1-bf5d-4a54-99b9-9ab87a332dc7	Demo Dhanbad Cooperative Institution 4	\N	Fictional partner institution supporting sal seed livelihoods.	\N	Test Campus 4, Dhanbad, Jharkhand	\N	https://example.test/institutions/4	e572b312-06c9-47e3-b150-4fd9c2b4e59c	09fe9edc-6f60-4529-b959-8484f092de7e	institution4@example.test	+91-6500-000-004	demo-cooperative-institution-4	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	4	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.395	2026-06-27 13:00:46.128
1ba549fe-161d-41c1-8df5-6ac141b9a203	6378b980-4ede-4b11-af22-f77e22ff0450	Demo Dumka Cooperative Institution 5	डेमो सहकारी संस्था 5	Fictional partner institution supporting karanj livelihoods.	यह केवल परीक्षण के लिए काल्पनिक संस्था है।	Test Campus 5, Dumka, Jharkhand	\N	https://example.test/institutions/5	cc4f583c-bd55-44e8-a408-9af5aa951372	3a1ea0fb-f4dd-46ea-bcd9-4c1e8f3650f6	institution5@example.test	+91-6500-000-005	demo-cooperative-institution-5	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	5	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.402	2026-06-27 13:00:46.134
8e19a717-50c2-4a26-b973-a6886b536573	8d8703c8-17cd-4079-aeea-e2396b98e993	Demo East Singhbhum Cooperative Institution 6	\N	Fictional partner institution supporting tamarind livelihoods.	\N	Test Campus 6, East Singhbhum, Jharkhand	\N	https://example.test/institutions/6	eb3877af-dd51-4f3c-8b6b-57570d63c33c	3915d156-ef49-420d-a645-0f8d521cbe9d	institution6@example.test	+91-6500-000-006	demo-cooperative-institution-6	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	6	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.404	2026-06-27 13:00:46.136
0e9b51f2-f393-4f8d-a004-2d22190ab744	85fbc056-fbb4-4eeb-bc98-f6ac0930d95a	Demo Garhwa Cooperative Institution 7	डेमो सहकारी संस्था 7	Fictional partner institution supporting lac livelihoods.	यह केवल परीक्षण के लिए काल्पनिक संस्था है।	Test Campus 7, Garhwa, Jharkhand	\N	https://example.test/institutions/7	18620944-e2bc-4e06-811d-f2c33d22ae84	a65e8a15-c344-4895-8329-9bd0d816efbf	institution7@example.test	+91-6500-000-007	demo-cooperative-institution-7	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	7	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.406	2026-06-27 13:00:46.138
aaaf27d6-9868-4bff-b595-e86bf092a2f1	b0f7b3aa-305d-4e47-84ed-8543e76ac96c	Demo Giridih Cooperative Institution 8	\N	Fictional partner institution supporting honey livelihoods.	\N	Test Campus 8, Giridih, Jharkhand	\N	https://example.test/institutions/8	bf9358c7-960b-4365-8b61-74f8788a7ad3	33e25b83-3af1-46ee-b50a-17f1eaf47a66	institution8@example.test	+91-6500-000-008	demo-cooperative-institution-8	unpublished	t	\N	\N	\N	\N	\N	\N	8	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.408	2026-06-27 13:00:46.139
ae84e287-f81d-44ed-86ce-129141d2f407	827a67e8-6ffe-4cc3-922f-e1314226dd34	Demo Godda Cooperative Institution 9	डेमो सहकारी संस्था 9	Fictional partner institution supporting ragi / millets livelihoods.	यह केवल परीक्षण के लिए काल्पनिक संस्था है।	Test Campus 9, Godda, Jharkhand	\N	https://example.test/institutions/9	84e59f6d-0311-404d-beaa-cf2172b47897	5ea7f0c7-cd37-4360-ac58-de95d7eec88f	institution9@example.test	+91-6500-000-009	demo-cooperative-institution-9	published	t	2027-01-15 08:00:00	2026-01-15 08:00:00	\N	\N	\N	\N	9	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.41	2026-06-27 13:00:46.141
bff1ae9a-2a5e-4ade-970a-2b2e5d2b66e3	95978d27-ba32-4428-8949-8efb771e2949	Demo Gumla Cooperative Institution 10	\N	Fictional partner institution supporting sal seed livelihoods.	\N	Test Campus 10, Gumla, Jharkhand	\N	https://example.test/institutions/10	4e8d90dc-7a13-4084-addf-b476da99f4e6	a7f3f827-3863-4cb3-8ab8-2a8df83147df	institution10@example.test	+91-6500-000-010	demo-cooperative-institution-10	published	f	\N	2026-01-15 08:00:00	\N	\N	\N	\N	10	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.411	2026-06-27 13:00:46.143
4eb59158-f8ac-44c5-aa57-21c73ace31b2	c28b1bfd-2f62-480a-a131-491bdff15bbb	Demo Hazaribagh Cooperative Institution 11	डेमो सहकारी संस्था 11	Fictional partner institution supporting karanj livelihoods.	यह केवल परीक्षण के लिए काल्पनिक संस्था है।	Test Campus 11, Hazaribagh, Jharkhand	\N	https://example.test/institutions/11	3f24f935-ecf7-4c53-bd05-2d673cef6692	55db93f2-cda9-44ec-a882-4a8072f755ce	institution11@example.test	+91-6500-000-011	demo-cooperative-institution-11	draft	t	\N	\N	\N	\N	\N	\N	11	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.413	2026-06-27 13:00:46.145
a7934626-a21d-48ad-967c-7cb38d69d4b3	e5094e89-e1ee-4924-a2b7-5e485f50f08f	Demo Jamtara Cooperative Institution 12	\N	Fictional partner institution supporting tamarind livelihoods.	\N	Test Campus 12, Jamtara, Jharkhand	\N	https://example.test/institutions/12	6853eb6c-ba01-4312-b751-b608641a94f5	cf0d98e7-4f40-4426-9c27-3b41649469f1	institution12@example.test	+91-6500-000-012	demo-cooperative-institution-12	archived	f	\N	2026-01-15 08:00:00	2026-06-27 08:00:00	\N	\N	\N	12	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.415	2026-06-27 13:00:46.146
\.


--
-- Data for Name: knowledge_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knowledge_categories (id, name_en, name_hi, slug, is_active, display_order, created_at, updated_at) FROM stdin;
da77b564-874f-4703-9e58-5e10cc1652d2	Acts and Rules	\N	acts-and-rules	t	1	2026-06-27 12:55:01.949	2026-06-27 13:00:45.764
0ec3b836-f2cd-44fd-a200-36d747d669cb	Bye-laws	\N	bye-laws	t	2	2026-06-27 12:55:01.952	2026-06-27 13:00:45.765
644c06bc-eb92-403a-a9f7-e75369c08837	Policies and Guidelines	\N	policies-and-guidelines	t	3	2026-06-27 12:55:01.952	2026-06-27 13:00:45.766
6d84947e-0002-44be-90e2-c9e42058656f	SOPs and Manuals	\N	sops-and-manuals	t	4	2026-06-27 12:55:01.953	2026-06-27 13:00:45.767
44a76805-9117-41d9-b4ec-330842046640	Training Resources	\N	training-resources	t	5	2026-06-27 12:55:01.954	2026-06-27 13:00:45.767
409ae789-523d-447e-9e94-698279c1d7e6	Research and Reports	\N	research-and-reports	t	6	2026-06-27 12:55:01.955	2026-06-27 13:00:45.768
348358c4-448f-4c1f-b5ec-a87275f6413c	Publications	\N	publications	t	7	2026-06-27 12:55:01.955	2026-06-27 13:00:45.769
a7afb135-3e39-4646-b093-93d1e3c14d35	Forms and Formats	\N	forms-and-formats	t	8	2026-06-27 12:55:01.956	2026-06-27 13:00:45.769
\.


--
-- Data for Name: media_assets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.media_assets (id, storage_key, url, file_name, mime_type, file_size_bytes, width, height, title, alt_text, caption, checksum, replaced_by_id, archived_at, uploaded_by, created_at, updated_at) FROM stdin;
eb3877af-dd51-4f3c-8b6b-57570d63c33c	media/fixtures/eb3877af-dd51-4f3c-8b6b-57570d63c33c.png	/api/v1/public/media/eb3877af-dd51-4f3c-8b6b-57570d63c33c/file	fixture-06.png	image/png	2667324	1672	941	Fictional cooperative activity 6	Fictional SIDHKOFED cooperative activity fixture 6	Fictional test image; not an official event photograph.	c188d0c811db7b65badb927da1a9f77220520a816dc98c097a3d6a2ef503ca14	\N	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.16	2026-06-27 13:00:45.916
18620944-e2bc-4e06-811d-f2c33d22ae84	media/fixtures/18620944-e2bc-4e06-811d-f2c33d22ae84.png	/api/v1/public/media/18620944-e2bc-4e06-811d-f2c33d22ae84/file	fixture-07.png	image/png	2784234	1672	941	Fictional cooperative activity 7	Fictional SIDHKOFED cooperative activity fixture 7	Fictional test image; not an official event photograph.	547fa9d2e076439c47cb737db9bb24b8506f148a88db665fa3c4f436d3a35950	\N	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.168	2026-06-27 13:00:45.921
bf9358c7-960b-4365-8b61-74f8788a7ad3	media/fixtures/bf9358c7-960b-4365-8b61-74f8788a7ad3.png	/api/v1/public/media/bf9358c7-960b-4365-8b61-74f8788a7ad3/file	fixture-08.png	image/png	2667324	1672	941	Fictional cooperative activity 8	Fictional SIDHKOFED cooperative activity fixture 8	Fictional test image; not an official event photograph.	c188d0c811db7b65badb927da1a9f77220520a816dc98c097a3d6a2ef503ca14	\N	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.174	2026-06-27 13:00:45.927
84e59f6d-0311-404d-beaa-cf2172b47897	media/fixtures/84e59f6d-0311-404d-beaa-cf2172b47897.png	/api/v1/public/media/84e59f6d-0311-404d-beaa-cf2172b47897/file	fixture-09.png	image/png	2784234	1672	941	Fictional cooperative activity 9	Fictional SIDHKOFED cooperative activity fixture 9	Fictional test image; not an official event photograph.	547fa9d2e076439c47cb737db9bb24b8506f148a88db665fa3c4f436d3a35950	\N	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.181	2026-06-27 13:00:45.933
1556504e-8fcc-4269-9d95-c388657993f5	media/fixtures/1556504e-8fcc-4269-9d95-c388657993f5.png	/api/v1/public/media/1556504e-8fcc-4269-9d95-c388657993f5/file	fixture-11.png	image/png	2784234	1672	941	Fictional cooperative activity 11	Fictional SIDHKOFED cooperative activity fixture 11	Fictional test image; not an official event photograph.	547fa9d2e076439c47cb737db9bb24b8506f148a88db665fa3c4f436d3a35950	\N	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.196	2026-06-27 13:00:45.944
4c222680-3614-4531-8764-4c832b5f850b	media/fixtures/4c222680-3614-4531-8764-4c832b5f850b.png	/api/v1/public/media/4c222680-3614-4531-8764-4c832b5f850b/file	fixture-12.png	image/png	2667324	1672	941	Fictional cooperative activity 12	Fictional SIDHKOFED cooperative activity fixture 12	Fictional test image; not an official event photograph.	c188d0c811db7b65badb927da1a9f77220520a816dc98c097a3d6a2ef503ca14	\N	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.203	2026-06-27 13:00:45.95
ffdd7879-2936-44f4-9e85-590ef7f5c988	media/fixtures/ffdd7879-2936-44f4-9e85-590ef7f5c988.png	/api/v1/public/media/ffdd7879-2936-44f4-9e85-590ef7f5c988/file	fixture-13.png	image/png	2784234	1672	941	Fictional cooperative activity 13	Fictional SIDHKOFED cooperative activity fixture 13	Fictional test image; not an official event photograph.	547fa9d2e076439c47cb737db9bb24b8506f148a88db665fa3c4f436d3a35950	\N	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.212	2026-06-27 13:00:45.955
0968939c-7d8e-44fa-b682-e301befe10d4	media/fixtures/0968939c-7d8e-44fa-b682-e301befe10d4.png	/api/v1/public/media/0968939c-7d8e-44fa-b682-e301befe10d4/file	fixture-14.png	image/png	2667324	1672	941	Fictional cooperative activity 14	Fictional SIDHKOFED cooperative activity fixture 14	Fictional test image; not an official event photograph.	c188d0c811db7b65badb927da1a9f77220520a816dc98c097a3d6a2ef503ca14	\N	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.219	2026-06-27 13:00:45.963
e2c4def6-a80f-493c-ac02-f98a476978f6	media/fixtures/e2c4def6-a80f-493c-ac02-f98a476978f6.png	/api/v1/public/media/e2c4def6-a80f-493c-ac02-f98a476978f6/file	fixture-15.png	image/png	2784234	1672	941	Fictional cooperative activity 15	Fictional SIDHKOFED cooperative activity fixture 15	Fictional test image; not an official event photograph.	547fa9d2e076439c47cb737db9bb24b8506f148a88db665fa3c4f436d3a35950	\N	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.226	2026-06-27 13:00:45.969
e2271e6c-b88e-4a53-a4b0-41e888954ced	media/fixtures/e2271e6c-b88e-4a53-a4b0-41e888954ced.png	/api/v1/public/media/e2271e6c-b88e-4a53-a4b0-41e888954ced/file	fixture-16.png	image/png	2667324	1672	941	Fictional cooperative activity 16	Fictional SIDHKOFED cooperative activity fixture 16	Fictional test image; not an official event photograph.	c188d0c811db7b65badb927da1a9f77220520a816dc98c097a3d6a2ef503ca14	\N	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.232	2026-06-27 13:00:45.974
396777b0-30cb-446a-881f-7b71bb378d49	media/fixtures/396777b0-30cb-446a-881f-7b71bb378d49.png	/api/v1/public/media/396777b0-30cb-446a-881f-7b71bb378d49/file	fixture-17.png	image/png	2784234	1672	941	Fictional cooperative activity 17	Fictional SIDHKOFED cooperative activity fixture 17	Fictional test image; not an official event photograph.	547fa9d2e076439c47cb737db9bb24b8506f148a88db665fa3c4f436d3a35950	\N	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.239	2026-06-27 13:00:45.98
5098ef8f-1b93-429c-b6f4-c1311d6eedd3	media/fixtures/5098ef8f-1b93-429c-b6f4-c1311d6eedd3.png	/api/v1/public/media/5098ef8f-1b93-429c-b6f4-c1311d6eedd3/file	fixture-18.png	image/png	2667324	1672	941	Fictional cooperative activity 18	Fictional SIDHKOFED cooperative activity fixture 18	Fictional test image; not an official event photograph.	c188d0c811db7b65badb927da1a9f77220520a816dc98c097a3d6a2ef503ca14	\N	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.246	2026-06-27 13:00:45.986
6853eb6c-ba01-4312-b751-b608641a94f5	media/fixtures/6853eb6c-ba01-4312-b751-b608641a94f5.png	/api/v1/public/media/6853eb6c-ba01-4312-b751-b608641a94f5/file	fixture-02.png	image/png	2667324	1672	941	Fictional cooperative activity 2	Fictional SIDHKOFED cooperative activity fixture 2	Fictional test image; not an official event photograph.	c188d0c811db7b65badb927da1a9f77220520a816dc98c097a3d6a2ef503ca14	\N	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.132	2026-06-27 13:00:45.892
cd1634aa-09ca-471d-a8b8-94968c0b7c9d	media/fixtures/cd1634aa-09ca-471d-a8b8-94968c0b7c9d.png	/api/v1/public/media/cd1634aa-09ca-471d-a8b8-94968c0b7c9d/file	fixture-03.png	image/png	2784234	1672	941	Fictional cooperative activity 3	Fictional SIDHKOFED cooperative activity fixture 3	Fictional test image; not an official event photograph.	547fa9d2e076439c47cb737db9bb24b8506f148a88db665fa3c4f436d3a35950	\N	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.139	2026-06-27 13:00:45.898
e572b312-06c9-47e3-b150-4fd9c2b4e59c	media/fixtures/e572b312-06c9-47e3-b150-4fd9c2b4e59c.png	/api/v1/public/media/e572b312-06c9-47e3-b150-4fd9c2b4e59c/file	fixture-04.png	image/png	2667324	1672	941	Fictional cooperative activity 4	Fictional SIDHKOFED cooperative activity fixture 4	Fictional test image; not an official event photograph.	c188d0c811db7b65badb927da1a9f77220520a816dc98c097a3d6a2ef503ca14	\N	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.146	2026-06-27 13:00:45.904
cc4f583c-bd55-44e8-a408-9af5aa951372	media/fixtures/cc4f583c-bd55-44e8-a408-9af5aa951372.png	/api/v1/public/media/cc4f583c-bd55-44e8-a408-9af5aa951372/file	fixture-05.png	image/png	2784234	1672	941	Fictional cooperative activity 5	Fictional SIDHKOFED cooperative activity fixture 5	Fictional test image; not an official event photograph.	547fa9d2e076439c47cb737db9bb24b8506f148a88db665fa3c4f436d3a35950	\N	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.154	2026-06-27 13:00:45.91
149ddd8c-6d46-4f4f-925a-1bccdb033971	media/fixtures/149ddd8c-6d46-4f4f-925a-1bccdb033971.pdf	/api/v1/public/media/149ddd8c-6d46-4f4f-925a-1bccdb033971/file	fixture-24.pdf	application/pdf	2678	\N	\N	Fictional public document 4	\N	\N	d391c0ca9b5ea7bb0bcee53e13c6f68de44d202c0aab3c65a4d925900ac1a2a0	\N	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.282	2026-06-27 13:00:46.01
69b7fec3-5b90-4b98-9c26-b04ef0192afe	media/fixtures/69b7fec3-5b90-4b98-9c26-b04ef0192afe.pdf	/api/v1/public/media/69b7fec3-5b90-4b98-9c26-b04ef0192afe/file	fixture-25.pdf	application/pdf	2678	\N	\N	Fictional public document 5	\N	\N	d391c0ca9b5ea7bb0bcee53e13c6f68de44d202c0aab3c65a4d925900ac1a2a0	\N	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.284	2026-06-27 13:00:46.013
de5fd4a9-fbf1-451c-80f2-93295dcf4d28	media/fixtures/de5fd4a9-fbf1-451c-80f2-93295dcf4d28.pdf	/api/v1/public/media/de5fd4a9-fbf1-451c-80f2-93295dcf4d28/file	fixture-26.pdf	application/pdf	2678	\N	\N	Fictional public document 6	\N	\N	d391c0ca9b5ea7bb0bcee53e13c6f68de44d202c0aab3c65a4d925900ac1a2a0	\N	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.287	2026-06-27 13:00:46.016
cfb8b062-b6e6-4274-a4f7-0adddce1348c	media/fixtures/cfb8b062-b6e6-4274-a4f7-0adddce1348c.pdf	/api/v1/public/media/cfb8b062-b6e6-4274-a4f7-0adddce1348c/file	fixture-27.pdf	application/pdf	2678	\N	\N	Fictional public document 7	\N	\N	d391c0ca9b5ea7bb0bcee53e13c6f68de44d202c0aab3c65a4d925900ac1a2a0	\N	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.291	2026-06-27 13:00:46.02
73bfc8f4-6e96-430d-8332-94d10ebba3c9	media/fixtures/73bfc8f4-6e96-430d-8332-94d10ebba3c9.pdf	/api/v1/public/media/73bfc8f4-6e96-430d-8332-94d10ebba3c9/file	fixture-28.pdf	application/pdf	2678	\N	\N	Fictional public document 8	\N	\N	d391c0ca9b5ea7bb0bcee53e13c6f68de44d202c0aab3c65a4d925900ac1a2a0	\N	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.294	2026-06-27 13:00:46.024
81cff119-5479-482d-83c7-a5317fbcf900	media/fixtures/81cff119-5479-482d-83c7-a5317fbcf900.pdf	/api/v1/public/media/81cff119-5479-482d-83c7-a5317fbcf900/file	fixture-29.pdf	application/pdf	2678	\N	\N	Fictional public document 9	\N	\N	d391c0ca9b5ea7bb0bcee53e13c6f68de44d202c0aab3c65a4d925900ac1a2a0	\N	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.297	2026-06-27 13:00:46.027
07c52317-ecee-4def-99c8-5d2976095090	media/fixtures/07c52317-ecee-4def-99c8-5d2976095090.pdf	/api/v1/public/media/07c52317-ecee-4def-99c8-5d2976095090/file	fixture-30.pdf	application/pdf	2678	\N	\N	Fictional public document 10	\N	\N	d391c0ca9b5ea7bb0bcee53e13c6f68de44d202c0aab3c65a4d925900ac1a2a0	\N	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.3	2026-06-27 13:00:46.03
c1fc235a-d72b-4a7e-affe-b1612bfd0c15	media/fixtures/c1fc235a-d72b-4a7e-affe-b1612bfd0c15.pdf	/api/v1/public/media/c1fc235a-d72b-4a7e-affe-b1612bfd0c15/file	fixture-31.pdf	application/pdf	2678	\N	\N	Fictional public document 11	\N	\N	d391c0ca9b5ea7bb0bcee53e13c6f68de44d202c0aab3c65a4d925900ac1a2a0	\N	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.303	2026-06-27 13:00:46.033
30445ff8-6684-4033-8d12-b405784c427e	media/fixtures/30445ff8-6684-4033-8d12-b405784c427e.pdf	/api/v1/public/media/30445ff8-6684-4033-8d12-b405784c427e/file	fixture-32.pdf	application/pdf	2678	\N	\N	Fictional public document 12	\N	\N	d391c0ca9b5ea7bb0bcee53e13c6f68de44d202c0aab3c65a4d925900ac1a2a0	\N	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.306	2026-06-27 13:00:46.036
0c2d3490-97d3-49a3-ac4d-890c553eef7f	media/fixtures/0c2d3490-97d3-49a3-ac4d-890c553eef7f.csv	/api/v1/public/media/0c2d3490-97d3-49a3-ac4d-890c553eef7f/file	fixture-33.csv	text/csv	244	\N	\N	Dashboard dataset 1	\N	\N	5d6e05d045db91d8007c67d0470fc3e738361e354c498dba498a46b67e848af2	\N	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.315	2026-06-27 13:00:46.039
eb4b5f98-228a-4cee-9150-8167a303dd9d	media/fixtures/eb4b5f98-228a-4cee-9150-8167a303dd9d.xlsx	/api/v1/public/media/eb4b5f98-228a-4cee-9150-8167a303dd9d/file	fixture-34.xlsx	application/vnd.openxmlformats-officedocument.spreadsheetml.sheet	2203	\N	\N	Dashboard dataset 2	\N	\N	8cff3e6389a68449ea6f5700943e9093788541c7f397462d4c1638ed2f40d8f8	\N	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.319	2026-06-27 13:00:46.042
79d022a1-0156-407f-b0e5-9dfb743eff91	media/fixtures/79d022a1-0156-407f-b0e5-9dfb743eff91.csv	/api/v1/public/media/79d022a1-0156-407f-b0e5-9dfb743eff91/file	fixture-35.csv	text/csv	244	\N	\N	Dashboard dataset 3	\N	\N	5d6e05d045db91d8007c67d0470fc3e738361e354c498dba498a46b67e848af2	\N	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.324	2026-06-27 13:00:46.046
afd1fc9a-6a81-408d-b0de-2af96a642b7c	media/fixtures/afd1fc9a-6a81-408d-b0de-2af96a642b7c.xlsx	/api/v1/public/media/afd1fc9a-6a81-408d-b0de-2af96a642b7c/file	fixture-36.xlsx	application/vnd.openxmlformats-officedocument.spreadsheetml.sheet	2203	\N	\N	Dashboard dataset 4	\N	\N	8cff3e6389a68449ea6f5700943e9093788541c7f397462d4c1638ed2f40d8f8	\N	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.327	2026-06-27 13:00:46.049
2bede4ce-021a-4e26-87f9-a598050a3c0b	media/fixtures/2bede4ce-021a-4e26-87f9-a598050a3c0b.csv	/api/v1/public/media/2bede4ce-021a-4e26-87f9-a598050a3c0b/file	fixture-37.csv	text/csv	244	\N	\N	Dashboard dataset 5	\N	\N	5d6e05d045db91d8007c67d0470fc3e738361e354c498dba498a46b67e848af2	\N	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.33	2026-06-27 13:00:46.052
89019f27-920a-464e-80fe-49b0135b5d11	media/fixtures/89019f27-920a-464e-80fe-49b0135b5d11.xlsx	/api/v1/public/media/89019f27-920a-464e-80fe-49b0135b5d11/file	fixture-38.xlsx	application/vnd.openxmlformats-officedocument.spreadsheetml.sheet	2203	\N	\N	Dashboard dataset 6	\N	\N	8cff3e6389a68449ea6f5700943e9093788541c7f397462d4c1638ed2f40d8f8	\N	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.333	2026-06-27 13:00:46.055
32946568-e6ae-424b-9d93-b7351a35902b	media/fixtures/32946568-e6ae-424b-9d93-b7351a35902b.csv	/api/v1/public/media/32946568-e6ae-424b-9d93-b7351a35902b/file	fixture-39.csv	text/csv	244	\N	\N	Dashboard dataset 7	\N	\N	5d6e05d045db91d8007c67d0470fc3e738361e354c498dba498a46b67e848af2	\N	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.336	2026-06-27 13:00:46.058
a72e713b-0a42-4a02-af13-dabc59f39527	media/fixtures/a72e713b-0a42-4a02-af13-dabc59f39527.xlsx	/api/v1/public/media/a72e713b-0a42-4a02-af13-dabc59f39527/file	fixture-40.xlsx	application/vnd.openxmlformats-officedocument.spreadsheetml.sheet	2203	\N	\N	Dashboard dataset 8	\N	\N	8cff3e6389a68449ea6f5700943e9093788541c7f397462d4c1638ed2f40d8f8	\N	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.339	2026-06-27 13:00:46.061
b0c9b33a-5ad2-450b-95b7-38ab448dfc01	media/fixtures/b0c9b33a-5ad2-450b-95b7-38ab448dfc01.png	/api/v1/public/media/b0c9b33a-5ad2-450b-95b7-38ab448dfc01/file	fixture-20.png	image/png	2667324	1672	941	Fictional cooperative activity 20	Fictional SIDHKOFED cooperative activity fixture 20	Fictional test image; not an official event photograph.	c188d0c811db7b65badb927da1a9f77220520a816dc98c097a3d6a2ef503ca14	\N	2026-06-27 08:00:00	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.26	2026-06-27 13:00:45.997
6536380f-9b03-46ff-85d7-4ab271ef2d17	media/fixtures/6536380f-9b03-46ff-85d7-4ab271ef2d17.pdf	/api/v1/public/media/6536380f-9b03-46ff-85d7-4ab271ef2d17/file	fixture-21.pdf	application/pdf	2678	\N	\N	Fictional public document 1	\N	\N	d391c0ca9b5ea7bb0bcee53e13c6f68de44d202c0aab3c65a4d925900ac1a2a0	\N	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.272	2026-06-27 13:00:46.001
6e1e1724-d6ec-4752-9ecb-c6dfe688a983	media/fixtures/6e1e1724-d6ec-4752-9ecb-c6dfe688a983.pdf	/api/v1/public/media/6e1e1724-d6ec-4752-9ecb-c6dfe688a983/file	fixture-22.pdf	application/pdf	2678	\N	\N	Fictional public document 2	\N	\N	d391c0ca9b5ea7bb0bcee53e13c6f68de44d202c0aab3c65a4d925900ac1a2a0	\N	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.275	2026-06-27 13:00:46.004
78c8d293-5fee-4db9-aa09-e8ba50848dc6	media/fixtures/78c8d293-5fee-4db9-aa09-e8ba50848dc6.pdf	/api/v1/public/media/78c8d293-5fee-4db9-aa09-e8ba50848dc6/file	fixture-23.pdf	application/pdf	2678	\N	\N	Fictional public document 3	\N	\N	d391c0ca9b5ea7bb0bcee53e13c6f68de44d202c0aab3c65a4d925900ac1a2a0	\N	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.278	2026-06-27 13:00:46.007
4e8d90dc-7a13-4084-addf-b476da99f4e6	media/fixtures/4e8d90dc-7a13-4084-addf-b476da99f4e6.png	/api/v1/public/media/4e8d90dc-7a13-4084-addf-b476da99f4e6/file	fixture-10.png	image/png	2667324	1672	941	Fictional cooperative activity 10	Fictional SIDHKOFED cooperative activity fixture 10	Fictional test image; not an official event photograph.	c188d0c811db7b65badb927da1a9f77220520a816dc98c097a3d6a2ef503ca14	\N	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.189	2026-06-27 13:00:45.938
4268af2d-2e9d-49d9-8253-80bab0f71ce0	media/fixtures/4268af2d-2e9d-49d9-8253-80bab0f71ce0.png	/api/v1/public/media/4268af2d-2e9d-49d9-8253-80bab0f71ce0/file	fixture-19.png	image/png	2784234	1672	941	Fictional cooperative activity 19	Fictional SIDHKOFED cooperative activity fixture 19	Fictional test image; not an official event photograph.	547fa9d2e076439c47cb737db9bb24b8506f148a88db665fa3c4f436d3a35950	\N	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.252	2026-06-27 13:00:45.991
3f24f935-ecf7-4c53-bd05-2d673cef6692	media/fixtures/3f24f935-ecf7-4c53-bd05-2d673cef6692.png	/api/v1/public/media/3f24f935-ecf7-4c53-bd05-2d673cef6692/file	fixture-01.png	image/png	2784234	1672	941	Fictional cooperative activity 1	Fictional SIDHKOFED cooperative activity fixture 1	Fictional test image; not an official event photograph.	547fa9d2e076439c47cb737db9bb24b8506f148a88db665fa3c4f436d3a35950	6853eb6c-ba01-4312-b751-b608641a94f5	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.121	2026-06-27 13:00:46.063
\.


--
-- Data for Name: media_usages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.media_usages (id, media_id, entity_type, entity_id, field, created_at) FROM stdin;
98fad2f4-6de1-463f-b839-95064ee92a15	4e8d90dc-7a13-4084-addf-b476da99f4e6	institution	bff1ae9a-2a5e-4ade-970a-2b2e5d2b66e3	logo_media_id	2026-06-27 12:55:03.662
b9c0bb6e-635a-4375-82de-bf7f20a43045	1556504e-8fcc-4269-9d95-c388657993f5	institution	4eb59158-f8ac-44c5-aa57-21c73ace31b2	logo_media_id	2026-06-27 12:55:03.663
f36af75a-5a63-4d93-856a-9d6550172504	4c222680-3614-4531-8764-4c832b5f850b	institution	a7934626-a21d-48ad-967c-7cb38d69d4b3	logo_media_id	2026-06-27 12:55:03.663
48cf1ca3-acc9-4b0e-8d7b-a0947aa49247	3f24f935-ecf7-4c53-bd05-2d673cef6692	programme	22fcb9e5-5190-4635-ab71-825976847e51	cover_media_id	2026-06-27 12:55:03.664
cf37ce1e-5b5f-420c-9963-34556f138fcc	6853eb6c-ba01-4312-b751-b608641a94f5	programme	d89d19c1-31ed-488f-a792-88de2325f352	cover_media_id	2026-06-27 12:55:03.665
6f72d627-96d2-4dce-bff0-430b590667fa	cd1634aa-09ca-471d-a8b8-94968c0b7c9d	programme	9867c29c-3ebf-41b0-98a8-221efcd86aca	cover_media_id	2026-06-27 12:55:03.666
80f7e7d0-0c0f-49f4-b03c-b5abc2f03307	e572b312-06c9-47e3-b150-4fd9c2b4e59c	programme	27a6b58a-a27a-4445-9ae4-1db0f6c6c223	cover_media_id	2026-06-27 12:55:03.667
ca5dc8e5-69ec-44dd-822c-29c5732e7fde	cc4f583c-bd55-44e8-a408-9af5aa951372	programme	cf87cfda-4657-46ab-8dc3-5f2c288b52a1	cover_media_id	2026-06-27 12:55:03.667
39caec5f-ed62-4a19-af5f-972772afa1b5	eb3877af-dd51-4f3c-8b6b-57570d63c33c	programme	edf6864c-2bd3-4a15-8a3c-7b23c3407be0	cover_media_id	2026-06-27 12:55:03.668
ae9072bf-3f49-4181-88d8-6d421c348abe	18620944-e2bc-4e06-811d-f2c33d22ae84	programme	f2418002-8794-4079-a380-4dc3f810aafa	cover_media_id	2026-06-27 12:55:03.669
f762d42b-893c-4048-be6f-f0074962b64d	3f24f935-ecf7-4c53-bd05-2d673cef6692	event	90816975-fff8-4e41-914c-4a434b87fbdf	cover_media_id	2026-06-27 12:55:03.632
ecf16516-0746-4d84-8300-326fd97831e7	6853eb6c-ba01-4312-b751-b608641a94f5	event	24f83e40-7156-4ee4-ab8a-ec2925392ca9	cover_media_id	2026-06-27 12:55:03.635
cbc2a7bf-b9e9-4a91-a84b-c5092784efb5	cd1634aa-09ca-471d-a8b8-94968c0b7c9d	event	8424284e-5a82-451c-8863-baffeeb71f2b	cover_media_id	2026-06-27 12:55:03.637
a8e7c59d-aad4-4e20-983c-579b1e8ee0af	e572b312-06c9-47e3-b150-4fd9c2b4e59c	event	c3a7c7ac-27c3-4c66-a7f0-79d0907d5272	cover_media_id	2026-06-27 12:55:03.638
56612401-b0c1-4e19-8d30-530551bacf5a	cc4f583c-bd55-44e8-a408-9af5aa951372	event	973f4234-e445-424a-8053-9490f7fcc956	cover_media_id	2026-06-27 12:55:03.639
1b7e4823-ab5a-43e7-a8bc-29a28879a752	eb3877af-dd51-4f3c-8b6b-57570d63c33c	event	82cf3be5-7fa5-45b9-8d71-08b15cab4642	cover_media_id	2026-06-27 12:55:03.64
a5679e7f-c17e-4dda-9747-946c105eb73f	18620944-e2bc-4e06-811d-f2c33d22ae84	event	3484093c-ee25-4a22-a2d2-e7c870c200df	cover_media_id	2026-06-27 12:55:03.641
42c5a104-8e77-4166-ad8a-20c5b2f33bd1	e2c4def6-a80f-493c-ac02-f98a476978f6	event	cca553d4-a3ca-4270-b166-adff9f3e1614	cover_media_id	2026-06-27 12:55:03.647
ab956e23-308d-4d0e-b161-cbe950cddc4e	e2271e6c-b88e-4a53-a4b0-41e888954ced	event	46865834-4135-41ef-9a93-df11593deb78	cover_media_id	2026-06-27 12:55:03.648
3c8bbfb1-1c83-4664-915e-9dce7a9ae8ed	396777b0-30cb-446a-881f-7b71bb378d49	event	4e88a410-6772-4053-97f6-5664a8721c46	cover_media_id	2026-06-27 12:55:03.648
a160162a-112a-4b4d-b7c0-fc74a940bbbd	5098ef8f-1b93-429c-b6f4-c1311d6eedd3	event	797f6ea6-1380-4878-aa72-a5a478a272f0	cover_media_id	2026-06-27 12:55:03.649
a186f4f0-14ad-4b04-9251-1a6ea2a12e20	4268af2d-2e9d-49d9-8253-80bab0f71ce0	event	da12f740-3f3c-4998-992b-70f049762e9d	cover_media_id	2026-06-27 12:55:03.65
3d12deef-5b6d-4604-91d1-84f36abb1c95	b0c9b33a-5ad2-450b-95b7-38ab448dfc01	event	035a951d-39e7-41b6-a6e9-d88e8a69aef3	cover_media_id	2026-06-27 12:55:03.651
dcf6ec4b-acd1-4f71-ae85-72cd87aab1ba	3f24f935-ecf7-4c53-bd05-2d673cef6692	event	b9404cc6-355d-4a30-8fd0-732236b1d762	cover_media_id	2026-06-27 12:55:03.652
53f146c4-4f5d-4e4f-86aa-c5dca744bfa6	6853eb6c-ba01-4312-b751-b608641a94f5	event	118075dd-8c9b-4a71-ac35-3974fe107a57	cover_media_id	2026-06-27 12:55:03.653
47bbd994-81f3-4816-8273-4e600b5c8b04	cd1634aa-09ca-471d-a8b8-94968c0b7c9d	event	29ef0b76-98de-438d-83b3-744e1a68d13a	cover_media_id	2026-06-27 12:55:03.653
532d4539-9089-4516-8e44-c74715b4447e	e572b312-06c9-47e3-b150-4fd9c2b4e59c	event	03ce842e-931e-46d8-b33d-fa2c8d6f2628	cover_media_id	2026-06-27 12:55:03.654
5c54d355-45ea-4867-8c7a-564ae3eef780	3f24f935-ecf7-4c53-bd05-2d673cef6692	institution	a7882c7b-b339-405a-98ff-787ea22af71e	logo_media_id	2026-06-27 12:55:03.655
7586d689-c0e9-4f76-8b96-91affac18fc2	6853eb6c-ba01-4312-b751-b608641a94f5	institution	76216f41-cbea-4f28-af6e-325511eec36b	logo_media_id	2026-06-27 12:55:03.655
67cea56c-d9d6-4a2b-b7d7-5fdc426196e7	cd1634aa-09ca-471d-a8b8-94968c0b7c9d	institution	4a4f9cba-ad6a-42ca-a33a-51c237b24959	logo_media_id	2026-06-27 12:55:03.656
16f0618b-cab7-4a6a-aa69-da8559252dca	e572b312-06c9-47e3-b150-4fd9c2b4e59c	institution	eb467702-6b19-4e1a-91bb-8e0b6f8846b5	logo_media_id	2026-06-27 12:55:03.657
eb26a242-db7a-49ce-8c3d-f131a0aeefb7	cc4f583c-bd55-44e8-a408-9af5aa951372	institution	1ba549fe-161d-41c1-8df5-6ac141b9a203	logo_media_id	2026-06-27 12:55:03.658
21f3d108-4de0-4280-9a4b-ac26a7f2b42e	eb3877af-dd51-4f3c-8b6b-57570d63c33c	institution	8e19a717-50c2-4a26-b973-a6886b536573	logo_media_id	2026-06-27 12:55:03.659
839e116b-65e1-4b74-8aa4-257664a82f71	18620944-e2bc-4e06-811d-f2c33d22ae84	institution	0e9b51f2-f393-4f8d-a004-2d22190ab744	logo_media_id	2026-06-27 12:55:03.66
b8f0f20a-3547-4603-b0d0-0f6e20458e13	bf9358c7-960b-4365-8b61-74f8788a7ad3	institution	aaaf27d6-9868-4bff-b595-e86bf092a2f1	logo_media_id	2026-06-27 12:55:03.66
68250b46-188e-4d15-9b93-e5a134d15672	84e59f6d-0311-404d-beaa-cf2172b47897	institution	ae84e287-f81d-44ed-86ce-129141d2f407	logo_media_id	2026-06-27 12:55:03.661
f49db8b6-3371-406b-84ff-dc3c37ddf400	bf9358c7-960b-4365-8b61-74f8788a7ad3	programme	fbbc4562-43a7-4015-9d4d-31ec23f1fcd0	cover_media_id	2026-06-27 12:55:03.669
90a302d0-8615-478a-b48c-9704be439349	84e59f6d-0311-404d-beaa-cf2172b47897	programme	d6dcdc56-84dc-4d87-990a-986e8ded46fb	cover_media_id	2026-06-27 12:55:03.67
71815bd4-5054-45e7-ac8a-ed3c120a67e8	4e8d90dc-7a13-4084-addf-b476da99f4e6	programme	e5427a51-68a7-4fbe-b618-3378361218a7	cover_media_id	2026-06-27 12:55:03.671
085e3d95-f8c9-4829-9422-380b46a67421	bf9358c7-960b-4365-8b61-74f8788a7ad3	event	f20b1cdf-e8a9-43e4-a23b-f1a1783e0d2c	cover_media_id	2026-06-27 12:55:03.641
dadb1e4c-50a9-4eef-a1c5-0309ed525c70	84e59f6d-0311-404d-beaa-cf2172b47897	event	e30b279f-fd18-497a-bd1a-a0b5beaafb63	cover_media_id	2026-06-27 12:55:03.642
a4a1d89b-a03a-45a4-aed3-a707c28b2ccd	4e8d90dc-7a13-4084-addf-b476da99f4e6	event	5e20a76d-7323-4bd8-b6ba-234b3aa33141	cover_media_id	2026-06-27 12:55:03.643
5a3c726b-2603-406c-8b81-b475febd5df2	1556504e-8fcc-4269-9d95-c388657993f5	event	b49ec2d0-2c30-4f6e-bd35-871a2f281eb7	cover_media_id	2026-06-27 12:55:03.644
bc00c43c-6851-4c78-9bb5-16e7995f6752	4c222680-3614-4531-8764-4c832b5f850b	event	73acb719-a481-4f93-9edb-395bcd8fafc5	cover_media_id	2026-06-27 12:55:03.645
7d46ccb6-12d2-411e-8179-1b6391b6cd3a	ffdd7879-2936-44f4-9e85-590ef7f5c988	event	476da260-931a-40a1-9242-44b81f0d4620	cover_media_id	2026-06-27 12:55:03.646
803a6973-93b5-40c6-b37c-3f115573f3e9	0968939c-7d8e-44fa-b682-e301befe10d4	event	eeeb1b36-e943-420c-835b-654d5300a00c	cover_media_id	2026-06-27 12:55:03.646
\.


--
-- Data for Name: menu_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.menu_items (id, label_en, label_hi, location, url, page_id, parent_id, opens_new_tab, display_order, is_active, created_by, updated_by, created_at, updated_at) FROM stdin;
061d5a06-177a-4a5d-bd52-3b730682e96f	Demo Menu 6	\N	header	\N	fef6d7d5-e050-4b7f-b630-b2dfa8abc09b	\N	f	6	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.334	2026-06-27 13:00:46.986
f6d525c8-040e-4067-9956-bad81a952810	Demo Menu 7	डेमो मेनू 7	header	\N	700901a3-df8a-4466-a5fd-52874ffd7268	39c080c1-13db-4528-84c8-33a5d54aa6ed	f	7	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.335	2026-06-27 13:00:46.987
8af037cf-5e54-40cf-bfe7-dc92eab8564b	Demo Menu 8	\N	header	\N	b760ba72-1e72-4241-b09a-3ce0940218ea	dac882ae-d957-4e30-b4c4-7072fae43e5c	f	8	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.337	2026-06-27 13:00:46.988
51fac59e-327c-43b1-95e5-8d20dc2d17a2	Demo Menu 9	डेमो मेनू 9	header	https://example.test/menu/9	\N	3e97f064-ed7c-4601-9989-3a913ee53c1e	t	9	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.338	2026-06-27 13:00:46.988
7237f8d0-540e-4dfc-b6c5-fb1ddd07599d	Demo Menu 10	\N	header	\N	c09bd126-08d9-448c-941b-2a48d7e2137a	97761052-04a6-4f75-9e66-9f6f5f8e96fa	f	10	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.339	2026-06-27 13:00:46.989
b9422c95-35cc-4d48-acd0-120b85440a9c	Demo Menu 11	डेमो मेनू 11	header	\N	7c811948-029c-4003-b2e8-8392858132b5	3875734b-8031-4178-b287-7d344e4c6eae	f	11	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.34	2026-06-27 13:00:46.99
39a0ba92-2b02-4916-bfc6-177e0630d58d	Demo Menu 12	\N	header	\N	18ca2692-d371-4c66-97c2-e1a9222d2035	061d5a06-177a-4a5d-bd52-3b730682e96f	f	12	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.341	2026-06-27 13:00:46.991
d07b91bd-fa24-4491-8169-09ac0331836f	Demo Menu 13	डेमो मेनू 13	footer	https://example.test/menu/13	\N	\N	t	13	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.342	2026-06-27 13:00:46.992
27d1266c-cd7b-4e34-94db-8588e3fa3214	Demo Menu 14	\N	footer	\N	caa19092-b5da-440b-8972-25fa5c39ee46	\N	f	14	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.343	2026-06-27 13:00:46.993
c163d005-743d-42d2-8f44-a85f239ab097	Demo Menu 15	डेमो मेनू 15	footer	\N	0b3286fb-de5d-4cb7-8f47-c27ce0511139	\N	f	15	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.344	2026-06-27 13:00:46.994
a9ebe714-2e4b-4e41-82d6-433fe17f97a9	Demo Menu 16	\N	footer	\N	7c9c5a18-8f7e-4693-b85c-09e042e82810	\N	f	16	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.345	2026-06-27 13:00:46.995
d424a671-5a06-49dc-978f-9a975a53bdb0	Demo Menu 17	डेमो मेनू 17	footer	https://example.test/menu/17	\N	\N	t	17	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.346	2026-06-27 13:00:46.996
089ceb64-92a4-43a1-8aeb-97965b5df9f7	Demo Menu 18	\N	footer	\N	fef6d7d5-e050-4b7f-b630-b2dfa8abc09b	\N	f	18	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.347	2026-06-27 13:00:46.997
adb7c654-dab5-4e9e-bb68-0b1161e7aa4f	Demo Menu 19	डेमो मेनू 19	footer	\N	700901a3-df8a-4466-a5fd-52874ffd7268	\N	f	19	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.348	2026-06-27 13:00:46.999
39c080c1-13db-4528-84c8-33a5d54aa6ed	Demo Menu 1	डेमो मेनू 1	header	https://example.test/menu/1	\N	\N	t	1	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.326	2026-06-27 13:00:46.98
dac882ae-d957-4e30-b4c4-7072fae43e5c	Demo Menu 2	\N	header	\N	caa19092-b5da-440b-8972-25fa5c39ee46	\N	f	2	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.329	2026-06-27 13:00:46.981
3e97f064-ed7c-4601-9989-3a913ee53c1e	Demo Menu 3	डेमो मेनू 3	header	\N	0b3286fb-de5d-4cb7-8f47-c27ce0511139	\N	f	3	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.331	2026-06-27 13:00:46.982
97761052-04a6-4f75-9e66-9f6f5f8e96fa	Demo Menu 4	\N	header	\N	7c9c5a18-8f7e-4693-b85c-09e042e82810	\N	f	4	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.332	2026-06-27 13:00:46.983
3875734b-8031-4178-b287-7d344e4c6eae	Demo Menu 5	डेमो मेनू 5	header	https://example.test/menu/5	\N	\N	t	5	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.333	2026-06-27 13:00:46.985
760978a9-b3f2-42ec-bcb1-caccc12e0d86	Demo Menu 20	\N	footer	\N	b760ba72-1e72-4241-b09a-3ce0940218ea	\N	f	20	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.349	2026-06-27 13:00:46.999
5254c377-a724-44d3-9ebf-f4d9cdb42367	Demo Menu 21	डेमो मेनू 21	utility	https://example.test/menu/21	\N	\N	t	21	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.35	2026-06-27 13:00:47
5b74d34c-de62-4107-a95a-91a96099e0f7	Demo Menu 22	\N	utility	\N	c09bd126-08d9-448c-941b-2a48d7e2137a	\N	f	22	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.351	2026-06-27 13:00:47.001
8bd09336-6bc7-450a-a421-b1886a2a6c64	Demo Menu 23	डेमो मेनू 23	utility	\N	7c811948-029c-4003-b2e8-8392858132b5	\N	f	23	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.353	2026-06-27 13:00:47.002
e3546616-6012-4fc7-ae77-9e129b180069	Demo Menu 24	\N	utility	\N	18ca2692-d371-4c66-97c2-e1a9222d2035	\N	f	24	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.354	2026-06-27 13:00:47.003
\.


--
-- Data for Name: official_communications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.official_communications (id, title_en, title_hi, summary_en, summary_hi, body_en, body_hi, communication_type_id, reference_number, issue_date, effective_date, expiry_date, issuing_authority, document_id, slug, publication_state, public_visibility, publish_start_at, published_at, archived_at, highlight_type, highlight_start_at, highlight_end_at, display_order, show_on_homepage, created_by, updated_by, created_at, updated_at) FROM stdin;
a531ebd4-b24c-439d-92d6-f4bc35e49f33	Demo communication record 7	डेमो सूचना 7	Fictional communication content covering Lac.	\N	Fixture communication body.	\N	42ecac9d-42cd-40c8-85ba-3e89d9e0137d	DEMO/COM/2026/7	2026-01-05	2026-01-15	2026-12-31	Demo SIDHKOFED Secretariat	2c366c39-c9ef-4a33-a676-5bfa04ab9305	demo-communication-7	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	7	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.227	2026-06-27 13:00:46.9
2fb2b873-2810-4c6c-8f1c-ab47e8019eb3	Demo communication record 8	\N	Fictional communication content covering Honey.	\N	Fixture communication body.	\N	58341cb8-722d-4bb7-a1b3-4b0fc17e6df7	DEMO/COM/2026/8	2026-02-05	2026-01-15	\N	Demo SIDHKOFED Secretariat	e326d4f8-140b-4f04-b43e-8790b44b3860	demo-communication-8	unpublished	t	\N	\N	\N	\N	\N	\N	8	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.229	2026-06-27 13:00:46.902
d0da4f4c-ea81-4ba8-8c62-f4cad0961ddb	Demo communication record 9	डेमो सूचना 9	Fictional communication content covering Ragi / Millets.	\N	Fixture communication body.	\N	47b8a50a-f6e8-4af2-b07f-de6bbb1da434	DEMO/COM/2026/9	2026-03-05	2026-01-15	\N	Demo SIDHKOFED Secretariat	d223a5d9-ff95-4736-9292-727d62dde24a	demo-communication-9	published	t	2027-01-15 08:00:00	2026-01-15 08:00:00	\N	\N	\N	\N	9	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.231	2026-06-27 13:00:46.904
65174077-0a58-4bf3-8385-539449765a39	Demo communication record 10	\N	Fictional communication content covering Sal Seed.	\N	Fixture communication body.	\N	0968f479-b97e-4dae-b4a7-815868d54f2a	DEMO/COM/2026/10	2026-04-05	2026-01-15	2026-12-31	Demo SIDHKOFED Secretariat	3cd791ca-0192-4685-8332-78c2bce1ed4c	demo-communication-10	published	f	\N	2026-01-15 08:00:00	\N	\N	\N	\N	10	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.233	2026-06-27 13:00:46.905
9cdc8647-31a4-4008-b92d-571de81bd8c8	Demo communication record 11	डेमो सूचना 11	Fictional communication content covering Karanj.	\N	Fixture communication body.	\N	ac7cd88e-ce6b-4ab3-bca8-c22a5231581e	DEMO/COM/2026/11	2026-05-05	2026-01-15	\N	Demo SIDHKOFED Secretariat	151d0a3f-bddb-4ba2-8943-d788078de702	demo-communication-11	draft	t	\N	\N	\N	\N	\N	\N	11	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.235	2026-06-27 13:00:46.907
1aa59fb5-918e-4c7a-9c1c-1b23cc748cd4	Demo communication record 12	\N	Fictional communication content covering Tamarind.	\N	Fixture communication body.	\N	350525f0-eb9f-4c22-a502-5e40ceefee69	DEMO/COM/2026/12	2026-06-05	2026-01-15	\N	Demo SIDHKOFED Secretariat	82b43929-43c0-40dd-bb89-0cc1eab52785	demo-communication-12	archived	f	\N	2026-01-15 08:00:00	2026-06-27 08:00:00	\N	\N	\N	12	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.237	2026-06-27 13:00:46.909
f5cdb98a-a3b6-43e2-aaf1-1261740d108e	Demo communication record 1	डेमो सूचना 1	Fictional communication content covering Lac.	\N	Fixture communication body.	\N	42ecac9d-42cd-40c8-85ba-3e89d9e0137d	DEMO/COM/2026/1	2026-01-05	2026-01-15	2026-12-31	Demo SIDHKOFED Secretariat	7944c41a-0cfa-4b43-a262-d498bd509c7e	demo-communication-1	published	t	\N	2026-01-15 08:00:00	\N	featured	2026-01-15 08:00:00	2027-01-15 08:00:00	1	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.208	2026-06-27 13:00:46.889
cb068e56-9639-463b-a6d2-5748272a7b7c	Demo communication record 2	\N	Fictional communication content covering Honey.	\N	Fixture communication body.	\N	58341cb8-722d-4bb7-a1b3-4b0fc17e6df7	DEMO/COM/2026/2	2026-02-05	2026-01-15	\N	Demo SIDHKOFED Secretariat	623abf9f-5986-42a1-bf2e-19ef4dd44ae4	demo-communication-2	published	t	\N	2026-01-15 08:00:00	\N	latest	2026-01-15 08:00:00	2027-01-15 08:00:00	2	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.216	2026-06-27 13:00:46.891
48605fd1-a5e7-4e35-9e41-d6f91031f39c	Demo communication record 3	डेमो सूचना 3	Fictional communication content covering Ragi / Millets.	\N	Fixture communication body.	\N	47b8a50a-f6e8-4af2-b07f-de6bbb1da434	DEMO/COM/2026/3	2026-03-05	2026-01-15	\N	Demo SIDHKOFED Secretariat	cc5052f0-2a3b-4122-85f2-54e91fe0e409	demo-communication-3	published	t	\N	2026-01-15 08:00:00	\N	important	2026-01-15 08:00:00	2027-01-15 08:00:00	3	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.218	2026-06-27 13:00:46.893
8a9e953a-04a2-405a-a279-145b5905c672	Demo communication record 4	\N	Fictional communication content covering Sal Seed.	\N	Fixture communication body.	\N	0968f479-b97e-4dae-b4a7-815868d54f2a	DEMO/COM/2026/4	2026-04-05	2026-01-15	2026-12-31	Demo SIDHKOFED Secretariat	5fa1f9d9-bb93-4e97-bace-309f87178155	demo-communication-4	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	4	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.221	2026-06-27 13:00:46.895
21a293ad-7961-48b6-ad1b-9f9b3d538caf	Demo communication record 5	डेमो सूचना 5	Fictional communication content covering Karanj.	\N	Fixture communication body.	\N	ac7cd88e-ce6b-4ab3-bca8-c22a5231581e	DEMO/COM/2026/5	2026-05-05	2026-01-15	\N	Demo SIDHKOFED Secretariat	a718689f-92f0-4279-ae77-a975a854d6db	demo-communication-5	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	5	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.223	2026-06-27 13:00:46.897
076fd7c6-f360-481d-94f7-741eb89b8101	Demo communication record 6	\N	Fictional communication content covering Tamarind.	\N	Fixture communication body.	\N	350525f0-eb9f-4c22-a502-5e40ceefee69	DEMO/COM/2026/6	2026-06-05	2026-01-15	\N	Demo SIDHKOFED Secretariat	16a09d86-3153-4a7a-8071-b2d5968e80dd	demo-communication-6	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	6	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.225	2026-06-27 13:00:46.898
\.


--
-- Data for Name: pages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pages (id, title_en, title_hi, body_en, body_hi, meta_title_en, meta_title_hi, meta_description_en, meta_description_hi, slug, publication_state, public_visibility, publish_start_at, published_at, archived_at, highlight_type, highlight_start_at, highlight_end_at, display_order, show_on_homepage, created_by, updated_by, created_at, updated_at) FROM stdin;
fef6d7d5-e050-4b7f-b630-b2dfa8abc09b	Demo Institutional Page 6	\N	Fictional institutional page content for CMS editing, SEO, menus, and public detail testing.	\N	Demo Page 6 | SIDHKOFED	\N	Fictional SEO fixture.	\N	demo-page-6	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	6	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.314	2026-06-27 13:00:46.968
b760ba72-1e72-4241-b09a-3ce0940218ea	Demo Institutional Page 8	\N	Fictional institutional page content for CMS editing, SEO, menus, and public detail testing.	\N	Demo Page 8 | SIDHKOFED	\N	Fictional SEO fixture.	\N	demo-page-8	unpublished	t	\N	\N	\N	\N	\N	\N	8	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.318	2026-06-27 13:00:46.972
c09bd126-08d9-448c-941b-2a48d7e2137a	Demo Institutional Page 10	\N	Fictional institutional page content for CMS editing, SEO, menus, and public detail testing.	\N	Demo Page 10 | SIDHKOFED	\N	Fictional SEO fixture.	\N	demo-page-10	published	f	\N	2026-01-15 08:00:00	\N	\N	\N	\N	10	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.321	2026-06-27 13:00:46.974
caa19092-b5da-440b-8972-25fa5c39ee46	Demo Institutional Page 2	\N	Fictional institutional page content for CMS editing, SEO, menus, and public detail testing.	\N	Demo Page 2 | SIDHKOFED	\N	Fictional SEO fixture.	\N	demo-page-2	published	t	\N	2026-01-15 08:00:00	\N	latest	2026-01-15 08:00:00	2027-01-15 08:00:00	2	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.307	2026-06-27 13:00:46.961
0b3286fb-de5d-4cb7-8f47-c27ce0511139	Demo Institutional Page 3	डेमो पृष्ठ 3	Fictional institutional page content for CMS editing, SEO, menus, and public detail testing.	यह केवल परीक्षण के लिए काल्पनिक पृष्ठ है।	Demo Page 3 | SIDHKOFED	\N	Fictional SEO fixture.	\N	demo-page-3	published	t	\N	2026-01-15 08:00:00	\N	important	2026-01-15 08:00:00	2027-01-15 08:00:00	3	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.309	2026-06-27 13:00:46.963
7c9c5a18-8f7e-4693-b85c-09e042e82810	Demo Institutional Page 4	\N	Fictional institutional page content for CMS editing, SEO, menus, and public detail testing.	\N	Demo Page 4 | SIDHKOFED	\N	Fictional SEO fixture.	\N	demo-page-4	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	4	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.311	2026-06-27 13:00:46.965
ababd85e-5c31-45c6-8d90-cd284a57c21c	Demo Institutional Page 5	डेमो पृष्ठ 5	Fictional institutional page content for CMS editing, SEO, menus, and public detail testing.	यह केवल परीक्षण के लिए काल्पनिक पृष्ठ है।	Demo Page 5 | SIDHKOFED	\N	Fictional SEO fixture.	\N	demo-page-5	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	5	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.313	2026-06-27 13:00:46.967
700901a3-df8a-4466-a5fd-52874ffd7268	Demo Institutional Page 7	डेमो पृष्ठ 7	Fictional institutional page content for CMS editing, SEO, menus, and public detail testing.	यह केवल परीक्षण के लिए काल्पनिक पृष्ठ है।	Demo Page 7 | SIDHKOFED	\N	Fictional SEO fixture.	\N	demo-page-7	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	7	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.316	2026-06-27 13:00:46.97
bfc8c7fb-7a63-4ca1-8483-fdeb8bcfe99f	Demo Institutional Page 9	डेमो पृष्ठ 9	Fictional institutional page content for CMS editing, SEO, menus, and public detail testing.	यह केवल परीक्षण के लिए काल्पनिक पृष्ठ है।	Demo Page 9 | SIDHKOFED	\N	Fictional SEO fixture.	\N	demo-page-9	published	t	2027-01-15 08:00:00	2026-01-15 08:00:00	\N	\N	\N	\N	9	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.319	2026-06-27 13:00:46.973
e8e2f722-e776-496d-96de-ef9fde80c714	Demo Institutional Page 1	डेमो पृष्ठ 1	Fictional institutional page content for CMS editing, SEO, menus, and public detail testing.	यह केवल परीक्षण के लिए काल्पनिक पृष्ठ है।	Demo Page 1 | SIDHKOFED	\N	Fictional SEO fixture.	\N	demo-page-1	published	t	\N	2026-01-15 08:00:00	\N	featured	2026-01-15 08:00:00	2027-01-15 08:00:00	1	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.302	2026-06-27 13:00:46.959
18ca2692-d371-4c66-97c2-e1a9222d2035	Demo Institutional Page 12	\N	Fictional institutional page content for CMS editing, SEO, menus, and public detail testing.	\N	Demo Page 12 | SIDHKOFED	\N	Fictional SEO fixture.	\N	demo-page-12	archived	f	\N	2026-01-15 08:00:00	2026-06-27 08:00:00	\N	\N	\N	12	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.324	2026-06-27 13:00:46.978
7c811948-029c-4003-b2e8-8392858132b5	Demo Institutional Page 11	डेमो पृष्ठ 11	Fictional institutional page content for CMS editing, SEO, menus, and public detail testing.	यह केवल परीक्षण के लिए काल्पनिक पृष्ठ है।	Demo Page 11 | SIDHKOFED	\N	Fictional SEO fixture.	\N	demo-page-11	draft	t	\N	\N	\N	\N	\N	\N	11	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.322	2026-06-27 13:00:46.976
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permissions (id, key, module, action, description) FROM stdin;
a1d1c7fe-6dcb-4b2c-b5d3-11aeffac02f4	toolkits.view	toolkits	view	Read Toolkit records.
31a2825b-8377-42a7-a266-8b553d9ee68c	toolkits.create	toolkits	create	Create draft Toolkit records.
b4586678-4eee-4e0f-8b61-4197b32dcb81	toolkits.update	toolkits	update	Edit Toolkit records.
97b9410a-ca0d-40be-abe1-14ef74f3a97c	toolkits.publish	toolkits	publish	Publish Toolkit records.
6a4ba816-7aa0-48f8-a8b9-215d15a018a9	content.create	content	create	Create draft content.
25840112-ff58-4774-9a65-8636df0c11b4	toolkits.unpublish	toolkits	unpublish	Unpublish Toolkit records.
351896ed-44c7-4c65-a030-709c59535bb1	toolkits.archive	toolkits	archive	Archive Toolkit records.
e1f7704b-a771-484f-911b-47453116001c	toolkits.restore	toolkits	restore	Restore archived Toolkit records.
7ddd452b-ad77-4f23-a049-df72f8f14964	toolkit_items.view	toolkit_items	view	Read Toolkit item records.
82a8e8e5-65bd-47db-9b42-78217d4b3ebd	content.update	content	update	Edit content.
78bf5807-7db8-488a-9147-0121ce0808b1	content.publish	content	publish	Publish content.
7564d6db-4dad-4d2a-9323-27f554ae9d46	content.unpublish	content	unpublish	Unpublish content.
9788801c-7f4a-4860-9527-f1658918eb30	content.archive	content	archive	Archive content.
def09386-80cf-4cd1-b9ed-bd1b5259450e	content.restore	content	restore	Restore archived content.
1a293d15-9e7a-4c42-89a3-d2c4f84bab64	users.manage	users	manage	Manage user accounts and role assignments.
e68e6aa0-1b60-4fe4-994b-db86aaf20c85	settings.manage	settings	manage	Manage system settings.
72adf1ef-48bb-4b48-89b7-59d4c08f1b8d	masters.view	masters	view	Read master data (dropdown access).
5ec7d5eb-1d47-488c-a7e9-e147291ace58	masters.create	masters	create	Create master records.
75d5dacb-02b3-4925-a2bf-0ffec5deb376	masters.update	masters	update	Edit master records.
6c2aedb2-446a-43c5-b99a-1e2db89e402b	masters.activate	masters	activate	Activate master records.
3671f524-19fe-4c74-83d3-d99dcb12b79a	masters.deactivate	masters	deactivate	Deactivate master records.
660544b9-01d2-4497-b3b2-a26297c22a3e	masters.restore	masters	restore	Restore (re-activate) master records.
8610cc64-0847-4be5-96e6-8415ed5d49d3	programmes.view	programmes	view	Read Programme records.
2adf3adc-5833-45d8-926d-18b023ba1dde	programmes.create	programmes	create	Create draft Programme records.
9cccbd4e-36d3-414d-a113-208ac56ed2fc	programmes.update	programmes	update	Edit Programme records.
ac517387-6684-4fda-a7b1-90da9919ad73	programmes.publish	programmes	publish	Publish Programme records.
e78afe48-908b-421c-96fd-0eab7cee1958	programmes.unpublish	programmes	unpublish	Unpublish Programme records.
e4c74280-0c19-402a-9ee2-8dc517c31f84	programmes.archive	programmes	archive	Archive Programme records.
f1be9ab3-4638-4ee5-8e73-c1a82e332f14	toolkit_items.create	toolkit_items	create	Create Toolkit item records.
32487088-cd9d-499c-84b3-757079de1457	toolkit_items.update	toolkit_items	update	Edit Toolkit item records.
535a10e8-6a68-427a-a4b1-cc46c1fa2e04	toolkit_items.delete	toolkit_items	delete	Delete Toolkit item records.
301a2b98-33cf-4115-bc3a-36f9e5b5b26b	toolkit_distributions.view	toolkit_distributions	view	Read Toolkit distribution summary records.
ff2eda52-3d89-4048-9d16-20bf2bbc3977	toolkit_distributions.create	toolkit_distributions	create	Create Toolkit distribution summary records.
84b7c82a-3ab3-4a8f-8ed4-056777265129	toolkit_distributions.update	toolkit_distributions	update	Edit Toolkit distribution summary records.
26d833b1-3910-463d-98b0-812b97718b29	toolkit_distributions.delete	toolkit_distributions	delete	Delete Toolkit distribution summary records.
4962c2e3-1886-426a-8ddf-0d96ba647965	dashboard.publish	dashboard	publish	Publish dashboard reports.
ef1864f8-ad73-41b9-8bce-bb8e75d21916	dashboard.unpublish	dashboard	unpublish	Unpublish dashboard reports.
bbb2dfd4-19de-440d-9538-cbde34ed3d97	dashboard.archive	dashboard	archive	Archive dashboard reports.
47ed5865-42d6-47bc-a696-e5b27d329c2a	dashboard.restore	dashboard	restore	Restore archived dashboard reports.
e2dfcb0b-afd0-40f5-8565-0c336177de9d	dashboard.manage_data	dashboard	manage_data	Manage dashboard metrics and import datasets.
a5b05851-d7b3-41a8-bfb2-c8ecde8b617c	programmes.restore	programmes	restore	Restore archived Programme records.
\.


--
-- Data for Name: procurement_update_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.procurement_update_types (id, name_en, name_hi, slug, is_active, display_order, created_at, updated_at) FROM stdin;
708e5703-a8ce-4f50-bc40-dd7f5a070606	Procurement Rate	\N	procurement-rate	t	1	2026-06-27 12:55:01.969	2026-06-27 13:00:45.778
24d56f35-8f4e-4a53-a69c-725158905bfe	Procurement Announcement	\N	procurement-announcement	t	2	2026-06-27 12:55:01.972	2026-06-27 13:00:45.779
c930d201-31b4-402b-bfff-37cc50c5d2a1	Procurement Schedule	\N	procurement-schedule	t	3	2026-06-27 12:55:01.972	2026-06-27 13:00:45.78
0c14305a-a3e8-4758-9df9-3706aadc3845	Procurement Centre Update	\N	procurement-centre-update	t	4	2026-06-27 12:55:01.973	2026-06-27 13:00:45.781
f41df2ca-1605-4c37-ac12-5462b8b9f7fd	Trade Opportunity	\N	trade-opportunity	t	5	2026-06-27 12:55:01.974	2026-06-27 13:00:45.782
\.


--
-- Data for Name: procurement_updates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.procurement_updates (id, title_en, title_hi, summary_en, summary_hi, description_en, description_hi, procurement_update_type_id, commodity_id, rate, unit, effective_date, period_start, period_end, district_id, block_id, location_text, programme_scheme_id, document_id, status, slug, publication_state, public_visibility, publish_start_at, published_at, archived_at, highlight_type, highlight_start_at, highlight_end_at, display_order, show_on_homepage, created_by, updated_by, created_at, updated_at) FROM stdin;
dcfc03a4-180f-48ab-8b20-c4e90c5eb5ef	Demo procurement record 2	\N	Fictional procurement content covering Honey.	\N	Fixture procurement information only; no transaction processing.	\N	24d56f35-8f4e-4a53-a69c-725158905bfe	d5302db1-d57e-4d7c-85ad-bf3dbc6db6e5	\N	\N	2026-02-10	2026-01-15	2027-01-15	d0e08c0c-31f8-4518-a427-283419fdd90e	\N	Demo procurement centre 2	d89d19c1-31ed-488f-a792-88de2325f352	623abf9f-5986-42a1-bf2e-19ef4dd44ae4	active	demo-procurement-2	published	t	\N	2026-01-15 08:00:00	\N	latest	2026-01-15 08:00:00	2027-01-15 08:00:00	2	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.277	2026-06-27 13:00:46.936
f0280dbc-530f-48a3-9d80-1f8791654986	Demo procurement record 3	डेमो सूचना 3	Fictional procurement content covering Ragi / Millets.	\N	Fixture procurement information only; no transaction processing.	\N	c930d201-31b4-402b-bfff-37cc50c5d2a1	b4873f7f-544f-42c3-855e-2810c7970236	\N	\N	2026-03-10	2026-01-15	2027-01-15	12b13393-e044-48ad-b999-7c6084714e9d	\N	Demo procurement centre 3	9867c29c-3ebf-41b0-98a8-221efcd86aca	cc5052f0-2a3b-4122-85f2-54e91fe0e409	active	demo-procurement-3	published	t	\N	2026-01-15 08:00:00	\N	important	2026-01-15 08:00:00	2027-01-15 08:00:00	3	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.279	2026-06-27 13:00:46.938
f8529185-9867-4df7-abb6-bba505b5ff78	Demo procurement record 4	\N	Fictional procurement content covering Sal Seed.	\N	Fixture procurement information only; no transaction processing.	\N	0c14305a-a3e8-4758-9df9-3706aadc3845	cffc6a8c-ed36-4163-aab4-2417904ca859	\N	\N	2026-04-10	2026-01-15	2027-01-15	09fe9edc-6f60-4529-b959-8484f092de7e	\N	Demo procurement centre 4	27a6b58a-a27a-4445-9ae4-1db0f6c6c223	5fa1f9d9-bb93-4e97-bace-309f87178155	active	demo-procurement-4	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	4	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.281	2026-06-27 13:00:46.94
6422daaa-50be-4640-9d8a-d4fe293e6afc	Demo procurement record 5	डेमो सूचना 5	Fictional procurement content covering Karanj.	\N	Fixture procurement information only; no transaction processing.	\N	f41df2ca-1605-4c37-ac12-5462b8b9f7fd	df849f1b-b168-45a9-a1cb-40139f8d225d	\N	\N	2026-05-10	2026-01-15	2027-01-15	3a1ea0fb-f4dd-46ea-bcd9-4c1e8f3650f6	\N	Demo procurement centre 5	cf87cfda-4657-46ab-8dc3-5f2c288b52a1	a718689f-92f0-4279-ae77-a975a854d6db	active	demo-procurement-5	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	5	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.284	2026-06-27 13:00:46.943
32ef5b65-f167-4565-a887-f33503be9088	Demo procurement record 6	\N	Fictional procurement content covering Tamarind.	\N	Fixture procurement information only; no transaction processing.	\N	708e5703-a8ce-4f50-bc40-dd7f5a070606	4f276af1-d981-4294-9f50-fbcdf2c979c2	150.00	kg	2026-06-10	2026-01-15	2027-01-15	3915d156-ef49-420d-a645-0f8d521cbe9d	\N	Demo procurement centre 6	edf6864c-2bd3-4a15-8a3c-7b23c3407be0	16a09d86-3153-4a7a-8071-b2d5968e80dd	active	demo-procurement-6	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	6	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.286	2026-06-27 13:00:46.945
424bd933-8abb-4de2-aeab-fe4de4d4c688	Demo procurement record 7	डेमो सूचना 7	Fictional procurement content covering Lac.	\N	Fixture procurement information only; no transaction processing.	\N	24d56f35-8f4e-4a53-a69c-725158905bfe	29abba96-aa2b-49b5-ba07-d75f2ce64932	\N	\N	2026-01-10	2026-01-15	2027-01-15	a65e8a15-c344-4895-8329-9bd0d816efbf	\N	Demo procurement centre 7	f2418002-8794-4079-a380-4dc3f810aafa	2c366c39-c9ef-4a33-a676-5bfa04ab9305	active	demo-procurement-7	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	7	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.289	2026-06-27 13:00:46.947
38929d50-a080-42f0-80be-2ca94326591e	Demo procurement record 8	\N	Fictional procurement content covering Honey.	\N	Fixture procurement information only; no transaction processing.	\N	c930d201-31b4-402b-bfff-37cc50c5d2a1	d5302db1-d57e-4d7c-85ad-bf3dbc6db6e5	\N	\N	2026-02-10	2026-01-15	2027-01-15	33e25b83-3af1-46ee-b50a-17f1eaf47a66	\N	Demo procurement centre 8	fbbc4562-43a7-4015-9d4d-31ec23f1fcd0	e326d4f8-140b-4f04-b43e-8790b44b3860	active	demo-procurement-8	unpublished	t	\N	\N	\N	\N	\N	\N	8	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.291	2026-06-27 13:00:46.949
c620c552-1510-4f78-b2bc-f235f38028be	Demo procurement record 9	डेमो सूचना 9	Fictional procurement content covering Ragi / Millets.	\N	Fixture procurement information only; no transaction processing.	\N	0c14305a-a3e8-4758-9df9-3706aadc3845	b4873f7f-544f-42c3-855e-2810c7970236	\N	\N	2026-03-10	2026-01-15	2027-01-15	5ea7f0c7-cd37-4360-ac58-de95d7eec88f	\N	Demo procurement centre 9	d6dcdc56-84dc-4d87-990a-986e8ded46fb	d223a5d9-ff95-4736-9292-727d62dde24a	closed	demo-procurement-9	published	t	2027-01-15 08:00:00	2026-01-15 08:00:00	\N	\N	\N	\N	9	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.293	2026-06-27 13:00:46.951
3b2d5fe9-444e-485d-a024-857247c7c8b5	Demo procurement record 10	\N	Fictional procurement content covering Sal Seed.	\N	Fixture procurement information only; no transaction processing.	\N	f41df2ca-1605-4c37-ac12-5462b8b9f7fd	cffc6a8c-ed36-4163-aab4-2417904ca859	\N	\N	2026-04-10	2026-01-15	2027-01-15	a7f3f827-3863-4cb3-8ab8-2a8df83147df	\N	Demo procurement centre 10	e5427a51-68a7-4fbe-b618-3378361218a7	3cd791ca-0192-4685-8332-78c2bce1ed4c	closed	demo-procurement-10	published	f	\N	2026-01-15 08:00:00	\N	\N	\N	\N	10	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.295	2026-06-27 13:00:46.953
8e29a9d5-7e39-49ec-a44f-ac6568e1e04f	Demo procurement record 11	डेमो सूचना 11	Fictional procurement content covering Karanj.	\N	Fixture procurement information only; no transaction processing.	\N	708e5703-a8ce-4f50-bc40-dd7f5a070606	df849f1b-b168-45a9-a1cb-40139f8d225d	175.00	kg	2026-05-10	2026-01-15	2027-01-15	55db93f2-cda9-44ec-a882-4a8072f755ce	\N	Demo procurement centre 11	22fcb9e5-5190-4635-ab71-825976847e51	151d0a3f-bddb-4ba2-8943-d788078de702	closed	demo-procurement-11	draft	t	\N	\N	\N	\N	\N	\N	11	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.297	2026-06-27 13:00:46.956
7953f05c-cd34-4f33-b99c-2922858cc4e4	Demo procurement record 1	डेमो सूचना 1	Fictional procurement content covering Lac.	\N	Fixture procurement information only; no transaction processing.	\N	708e5703-a8ce-4f50-bc40-dd7f5a070606	29abba96-aa2b-49b5-ba07-d75f2ce64932	125.00	kg	2026-01-10	2026-01-15	2027-01-15	8d3043ee-820f-4ebc-ac56-8879f8e937f4	\N	Demo procurement centre 1	22fcb9e5-5190-4635-ab71-825976847e51	7944c41a-0cfa-4b43-a262-d498bd509c7e	active	demo-procurement-1	published	t	\N	2026-01-15 08:00:00	\N	featured	2026-01-15 08:00:00	2027-01-15 08:00:00	1	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.268	2026-06-27 13:00:46.933
044eb9d5-98e5-43f1-8bc0-99f74a8a1ca6	Demo procurement record 12	\N	Fictional procurement content covering Tamarind.	\N	Fixture procurement information only; no transaction processing.	\N	24d56f35-8f4e-4a53-a69c-725158905bfe	4f276af1-d981-4294-9f50-fbcdf2c979c2	\N	\N	2026-06-10	2026-01-15	2027-01-15	cf0d98e7-4f40-4426-9c27-3b41649469f1	\N	Demo procurement centre 12	d89d19c1-31ed-488f-a792-88de2325f352	82b43929-43c0-40dd-bb89-0cc1eab52785	closed	demo-procurement-12	archived	f	\N	2026-01-15 08:00:00	2026-06-27 08:00:00	\N	\N	\N	12	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.299	2026-06-27 13:00:46.957
\.


--
-- Data for Name: programme_commodities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programme_commodities (id, programme_scheme_id, commodity_id) FROM stdin;
846e0500-58e5-4278-86bc-9888286f76f2	22fcb9e5-5190-4635-ab71-825976847e51	29abba96-aa2b-49b5-ba07-d75f2ce64932
84bc3713-0290-4bc2-9d52-351c6c8986db	22fcb9e5-5190-4635-ab71-825976847e51	d5302db1-d57e-4d7c-85ad-bf3dbc6db6e5
661c8bd6-b643-4925-b69d-2c9c6e71630a	d89d19c1-31ed-488f-a792-88de2325f352	d5302db1-d57e-4d7c-85ad-bf3dbc6db6e5
d0475386-ad51-453b-bbbc-98d9ad5aeda1	d89d19c1-31ed-488f-a792-88de2325f352	b4873f7f-544f-42c3-855e-2810c7970236
59a5ea70-25b4-4e29-a2cf-dd9fc3038045	9867c29c-3ebf-41b0-98a8-221efcd86aca	b4873f7f-544f-42c3-855e-2810c7970236
66fc08d6-d156-45eb-becf-1c9895d476c7	9867c29c-3ebf-41b0-98a8-221efcd86aca	cffc6a8c-ed36-4163-aab4-2417904ca859
9dea0049-14e0-47bc-8a88-3bb0cf1dde63	27a6b58a-a27a-4445-9ae4-1db0f6c6c223	cffc6a8c-ed36-4163-aab4-2417904ca859
f6562fb1-a70f-48e6-9a07-26f61f9f0173	27a6b58a-a27a-4445-9ae4-1db0f6c6c223	df849f1b-b168-45a9-a1cb-40139f8d225d
78f35e19-5f07-4983-921b-ab79c0b1af4d	cf87cfda-4657-46ab-8dc3-5f2c288b52a1	df849f1b-b168-45a9-a1cb-40139f8d225d
905453c0-86f1-44d4-8918-43b28c2393bf	cf87cfda-4657-46ab-8dc3-5f2c288b52a1	4f276af1-d981-4294-9f50-fbcdf2c979c2
e3409f68-46b9-4be4-968c-3d70de72f48b	edf6864c-2bd3-4a15-8a3c-7b23c3407be0	4f276af1-d981-4294-9f50-fbcdf2c979c2
e547fd84-a76c-42ed-ad72-66ece6e2e64b	edf6864c-2bd3-4a15-8a3c-7b23c3407be0	29abba96-aa2b-49b5-ba07-d75f2ce64932
7c81dda3-b3fc-43ad-b658-f50172f2a7b7	f2418002-8794-4079-a380-4dc3f810aafa	29abba96-aa2b-49b5-ba07-d75f2ce64932
6634ec26-f38d-4bc3-8deb-39c66d15976d	f2418002-8794-4079-a380-4dc3f810aafa	d5302db1-d57e-4d7c-85ad-bf3dbc6db6e5
7335a964-2736-419a-930e-18dc989acb7b	fbbc4562-43a7-4015-9d4d-31ec23f1fcd0	d5302db1-d57e-4d7c-85ad-bf3dbc6db6e5
0e7a07d8-ed12-4b80-a4c3-5bf347f3127b	fbbc4562-43a7-4015-9d4d-31ec23f1fcd0	b4873f7f-544f-42c3-855e-2810c7970236
cfe646ed-8858-4d6e-afac-b73cfe68f964	d6dcdc56-84dc-4d87-990a-986e8ded46fb	b4873f7f-544f-42c3-855e-2810c7970236
7f4a4453-bcd7-4c78-b94e-900d3195a611	d6dcdc56-84dc-4d87-990a-986e8ded46fb	cffc6a8c-ed36-4163-aab4-2417904ca859
e7f514a0-4770-4fa2-bb19-8cc22b7ef423	e5427a51-68a7-4fbe-b618-3378361218a7	cffc6a8c-ed36-4163-aab4-2417904ca859
c599bc0f-a227-4a95-b9d1-7f8eaa0612ba	e5427a51-68a7-4fbe-b618-3378361218a7	df849f1b-b168-45a9-a1cb-40139f8d225d
\.


--
-- Data for Name: programme_permitted_training_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programme_permitted_training_types (id, programme_scheme_id, training_type_id) FROM stdin;
6d0772e9-dcb3-4a6f-b3d8-a1a463047df1	22fcb9e5-5190-4635-ab71-825976847e51	709c6b77-e169-474e-a370-2f2561fc3c8e
d534b6dc-507a-47bc-a974-92c13f33c9e2	22fcb9e5-5190-4635-ab71-825976847e51	8420d28b-1cf4-4e30-9d75-1412e79ba349
f012b11f-27cc-4669-834b-b8b4b856fce1	d89d19c1-31ed-488f-a792-88de2325f352	8420d28b-1cf4-4e30-9d75-1412e79ba349
fa1511fb-818e-4091-a309-84e3c412d5bc	d89d19c1-31ed-488f-a792-88de2325f352	2575a66d-6984-4be7-a068-b5d1cf215abf
f6b3dcec-67c6-4168-8e8c-212dc428181a	9867c29c-3ebf-41b0-98a8-221efcd86aca	2575a66d-6984-4be7-a068-b5d1cf215abf
7d10ff36-43ff-4193-9669-f204defddec9	9867c29c-3ebf-41b0-98a8-221efcd86aca	5e1cc670-720c-4294-89fd-54bc49b2e7a7
f0337054-d82a-43d9-9167-3c63de8e6e3a	27a6b58a-a27a-4445-9ae4-1db0f6c6c223	5e1cc670-720c-4294-89fd-54bc49b2e7a7
62af17a1-9274-48a4-bf70-20d1971f12f1	27a6b58a-a27a-4445-9ae4-1db0f6c6c223	43b6fabc-eae3-4525-b729-738070046dd5
5573ae9c-630a-4de9-a065-6f9215159d37	cf87cfda-4657-46ab-8dc3-5f2c288b52a1	43b6fabc-eae3-4525-b729-738070046dd5
63b5f451-bf6c-4f34-812a-da3f5763b93f	cf87cfda-4657-46ab-8dc3-5f2c288b52a1	709c6b77-e169-474e-a370-2f2561fc3c8e
db85e2e2-bbbf-4d93-a530-8606e859c58c	edf6864c-2bd3-4a15-8a3c-7b23c3407be0	709c6b77-e169-474e-a370-2f2561fc3c8e
0c12b60b-16ac-4e14-b0c6-b9ec5fba5cd0	edf6864c-2bd3-4a15-8a3c-7b23c3407be0	8420d28b-1cf4-4e30-9d75-1412e79ba349
2701ac6a-05ad-40ca-8f9d-c5eda1b32e32	f2418002-8794-4079-a380-4dc3f810aafa	8420d28b-1cf4-4e30-9d75-1412e79ba349
ba96d830-1b0a-4904-9d0f-f5983d65a48b	f2418002-8794-4079-a380-4dc3f810aafa	2575a66d-6984-4be7-a068-b5d1cf215abf
902cd231-693c-4c50-9e84-49047e139403	fbbc4562-43a7-4015-9d4d-31ec23f1fcd0	2575a66d-6984-4be7-a068-b5d1cf215abf
67bf3ea6-e085-401d-9240-e9ee5d80847e	fbbc4562-43a7-4015-9d4d-31ec23f1fcd0	5e1cc670-720c-4294-89fd-54bc49b2e7a7
6e15877b-0973-450c-9cd3-7ff6d528d682	d6dcdc56-84dc-4d87-990a-986e8ded46fb	5e1cc670-720c-4294-89fd-54bc49b2e7a7
d7f3eb8a-7d2d-4bbd-8bc2-e4907e8da835	d6dcdc56-84dc-4d87-990a-986e8ded46fb	43b6fabc-eae3-4525-b729-738070046dd5
2d260e8e-4898-44d6-ac51-d8b6edbae124	e5427a51-68a7-4fbe-b618-3378361218a7	43b6fabc-eae3-4525-b729-738070046dd5
46e3e9ab-cc8f-4061-9466-c085a458b964	e5427a51-68a7-4fbe-b618-3378361218a7	709c6b77-e169-474e-a370-2f2561fc3c8e
\.


--
-- Data for Name: programme_schemes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.programme_schemes (id, title_en, title_hi, short_code, summary_en, summary_hi, description_en, description_hi, objectives_en, objectives_hi, eligibility_en, eligibility_hi, benefits_en, benefits_hi, application_process_en, application_process_hi, funding_source, start_date, end_date, cover_media_id, slug, publication_state, public_visibility, publish_start_at, published_at, archived_at, highlight_type, highlight_start_at, highlight_end_at, display_order, show_on_homepage, created_by, updated_by, created_at, updated_at) FROM stdin;
edf6864c-2bd3-4a15-8a3c-7b23c3407be0	Demo Tamarind Enterprise Programme 6	\N	DEMO-06	Fictional programme used to exercise programme listings and relationships.	\N	Supports training, toolkit distribution, institutional partnerships, and public information testing.	\N	Validate filters, relationships, homepage cards, and detail rendering.	\N	Fictional cooperative institutions in the demo dataset.	\N	Training and demonstration toolkit support.	\N	No real application; this is fixture content.	\N	Demo Cooperative Fund	2026-04-01	2028-03-31	eb3877af-dd51-4f3c-8b6b-57570d63c33c	demo-enterprise-programme-6	unpublished	t	\N	\N	\N	\N	\N	\N	6	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.456	2026-06-27 13:00:46.184
f2418002-8794-4079-a380-4dc3f810aafa	Demo Lac Enterprise Programme 7	डेमो आजीविका कार्यक्रम 7	DEMO-07	Fictional programme used to exercise programme listings and relationships.	\N	Supports training, toolkit distribution, institutional partnerships, and public information testing.	\N	Validate filters, relationships, homepage cards, and detail rendering.	\N	Fictional cooperative institutions in the demo dataset.	\N	Training and demonstration toolkit support.	\N	No real application; this is fixture content.	\N	Demo State Plan	2024-04-01	2026-03-31	18620944-e2bc-4e06-811d-f2c33d22ae84	demo-enterprise-programme-7	published	t	2027-01-15 08:00:00	2026-01-15 08:00:00	\N	\N	\N	\N	7	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.46	2026-06-27 13:00:46.188
d89d19c1-31ed-488f-a792-88de2325f352	Demo Honey Enterprise Programme 2	\N	DEMO-02	Fictional programme used to exercise programme listings and relationships.	\N	Supports training, toolkit distribution, institutional partnerships, and public information testing.	\N	Validate filters, relationships, homepage cards, and detail rendering.	\N	Fictional cooperative institutions in the demo dataset.	\N	Training and demonstration toolkit support.	\N	No real application; this is fixture content.	\N	Demo Cooperative Fund	2025-04-01	2027-03-31	6853eb6c-ba01-4312-b751-b608641a94f5	demo-enterprise-programme-2	published	t	\N	2026-01-15 08:00:00	\N	latest	2026-01-15 08:00:00	2027-01-15 08:00:00	2	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.435	2026-06-27 13:00:46.161
9867c29c-3ebf-41b0-98a8-221efcd86aca	Demo Ragi / Millets Enterprise Programme 3	डेमो आजीविका कार्यक्रम 3	DEMO-03	Fictional programme used to exercise programme listings and relationships.	\N	Supports training, toolkit distribution, institutional partnerships, and public information testing.	\N	Validate filters, relationships, homepage cards, and detail rendering.	\N	Fictional cooperative institutions in the demo dataset.	\N	Training and demonstration toolkit support.	\N	No real application; this is fixture content.	\N	Demo State Plan	2026-04-01	2028-03-31	cd1634aa-09ca-471d-a8b8-94968c0b7c9d	demo-enterprise-programme-3	published	t	\N	2026-01-15 08:00:00	\N	important	2026-01-15 08:00:00	2027-01-15 08:00:00	3	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.441	2026-06-27 13:00:46.167
27a6b58a-a27a-4445-9ae4-1db0f6c6c223	Demo Sal Seed Enterprise Programme 4	\N	DEMO-04	Fictional programme used to exercise programme listings and relationships.	\N	Supports training, toolkit distribution, institutional partnerships, and public information testing.	\N	Validate filters, relationships, homepage cards, and detail rendering.	\N	Fictional cooperative institutions in the demo dataset.	\N	Training and demonstration toolkit support.	\N	No real application; this is fixture content.	\N	Demo Cooperative Fund	2024-04-01	2026-03-31	e572b312-06c9-47e3-b150-4fd9c2b4e59c	demo-enterprise-programme-4	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	4	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.445	2026-06-27 13:00:46.173
cf87cfda-4657-46ab-8dc3-5f2c288b52a1	Demo Karanj Enterprise Programme 5	डेमो आजीविका कार्यक्रम 5	DEMO-05	Fictional programme used to exercise programme listings and relationships.	\N	Supports training, toolkit distribution, institutional partnerships, and public information testing.	\N	Validate filters, relationships, homepage cards, and detail rendering.	\N	Fictional cooperative institutions in the demo dataset.	\N	Training and demonstration toolkit support.	\N	No real application; this is fixture content.	\N	Demo State Plan	2025-04-01	2027-03-31	cc4f583c-bd55-44e8-a408-9af5aa951372	demo-enterprise-programme-5	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	5	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.451	2026-06-27 13:00:46.179
e5427a51-68a7-4fbe-b618-3378361218a7	Demo Sal Seed Enterprise Programme 10	\N	DEMO-10	Fictional programme used to exercise programme listings and relationships.	\N	Supports training, toolkit distribution, institutional partnerships, and public information testing.	\N	Validate filters, relationships, homepage cards, and detail rendering.	\N	Fictional cooperative institutions in the demo dataset.	\N	Training and demonstration toolkit support.	\N	No real application; this is fixture content.	\N	Demo Cooperative Fund	2024-04-01	2026-03-31	4e8d90dc-7a13-4084-addf-b476da99f4e6	demo-enterprise-programme-10	archived	f	\N	2026-01-15 08:00:00	2026-06-27 08:00:00	\N	\N	\N	10	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.475	2026-06-27 13:00:46.204
22fcb9e5-5190-4635-ab71-825976847e51	Demo Lac Enterprise Programme 1	डेमो आजीविका कार्यक्रम 1	DEMO-01	Fictional programme used to exercise programme listings and relationships.	\N	Supports training, toolkit distribution, institutional partnerships, and public information testing.	\N	Validate filters, relationships, homepage cards, and detail rendering.	\N	Fictional cooperative institutions in the demo dataset.	\N	Training and demonstration toolkit support.	\N	No real application; this is fixture content.	\N	Demo State Plan	2024-04-01	2026-03-31	3f24f935-ecf7-4c53-bd05-2d673cef6692	demo-enterprise-programme-1	published	t	\N	2026-01-15 08:00:00	\N	featured	2026-01-15 08:00:00	2027-01-15 08:00:00	1	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.417	2026-06-27 13:00:46.148
fbbc4562-43a7-4015-9d4d-31ec23f1fcd0	Demo Honey Enterprise Programme 8	\N	DEMO-08	Fictional programme used to exercise programme listings and relationships.	\N	Supports training, toolkit distribution, institutional partnerships, and public information testing.	\N	Validate filters, relationships, homepage cards, and detail rendering.	\N	Fictional cooperative institutions in the demo dataset.	\N	Training and demonstration toolkit support.	\N	No real application; this is fixture content.	\N	Demo Cooperative Fund	2025-04-01	2027-03-31	bf9358c7-960b-4365-8b61-74f8788a7ad3	demo-enterprise-programme-8	published	f	\N	2026-01-15 08:00:00	\N	\N	\N	\N	8	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.465	2026-06-27 13:00:46.193
d6dcdc56-84dc-4d87-990a-986e8ded46fb	Demo Ragi / Millets Enterprise Programme 9	डेमो आजीविका कार्यक्रम 9	DEMO-09	Fictional programme used to exercise programme listings and relationships.	\N	Supports training, toolkit distribution, institutional partnerships, and public information testing.	\N	Validate filters, relationships, homepage cards, and detail rendering.	\N	Fictional cooperative institutions in the demo dataset.	\N	Training and demonstration toolkit support.	\N	No real application; this is fixture content.	\N	Demo State Plan	2026-04-01	2028-03-31	84e59f6d-0311-404d-beaa-cf2172b47897	demo-enterprise-programme-9	draft	t	\N	\N	\N	\N	\N	\N	9	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.471	2026-06-27 13:00:46.198
\.


--
-- Data for Name: reporting_periods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reporting_periods (id, financial_year_id, name_en, name_hi, slug, period_type, calendar_year, start_date, end_date, is_active, created_at, updated_at) FROM stdin;
0cc986ce-b9ec-441c-9d0b-ddadad42e6e1	\N	Cumulative	\N	cumulative	cumulative	\N	2020-04-01	2030-03-31	t	2026-06-27 12:55:02.058	2026-06-27 13:00:45.833
16eef30e-3720-43c3-9d92-e2206cde1933	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	FY 2025-2026	\N	fy-2025-2026	financial_year	\N	2025-04-01	2026-03-31	t	2026-06-27 12:55:02.062	2026-06-27 13:00:45.834
077c30c4-0298-49d2-a725-341e51f0260c	\N	Calendar Year 2025	\N	calendar-year-2025	calendar_year	2025	2025-01-01	2025-12-31	t	2026-06-27 12:55:02.063	2026-06-27 13:00:45.835
c449cf5d-5ec2-47c7-a8c7-f746f1420b0e	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	April 2025	\N	april-2025	month	\N	2025-04-01	2025-04-30	t	2026-06-27 12:55:02.065	2026-06-27 13:00:45.856
9cb5ee9c-5de0-473d-9f75-1f1d22934172	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	May 2025	\N	may-2025	month	\N	2025-05-01	2025-05-31	t	2026-06-27 12:55:02.093	2026-06-27 13:00:45.858
ca9e1bde-a1e9-4ed6-a46e-d8f4300fee9f	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	June 2025	\N	june-2025	month	\N	2025-06-01	2025-06-30	t	2026-06-27 12:55:02.094	2026-06-27 13:00:45.859
b03a9306-05a1-4e31-933e-0216f8b1ef0c	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	July 2025	\N	july-2025	month	\N	2025-07-01	2025-07-31	t	2026-06-27 12:55:02.095	2026-06-27 13:00:45.86
abfc1441-2107-448a-8420-6c4ba6379691	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	August 2025	\N	august-2025	month	\N	2025-08-01	2025-08-31	t	2026-06-27 12:55:02.096	2026-06-27 13:00:45.861
3a730236-d6b1-4ae1-843e-101e130a5882	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	September 2025	\N	september-2025	month	\N	2025-09-01	2025-09-30	t	2026-06-27 12:55:02.097	2026-06-27 13:00:45.861
1e2a0590-208f-4db5-a7bc-02db1a0e92b4	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	October 2025	\N	october-2025	month	\N	2025-10-01	2025-10-31	t	2026-06-27 12:55:02.098	2026-06-27 13:00:45.862
5a81ff1c-97b8-4c10-b034-eef98ae10c7d	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	November 2025	\N	november-2025	month	\N	2025-11-01	2025-11-30	t	2026-06-27 12:55:02.098	2026-06-27 13:00:45.863
408e8c4f-915a-4099-a31c-16e780f3c918	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	December 2025	\N	december-2025	month	\N	2025-12-01	2025-12-31	t	2026-06-27 12:55:02.099	2026-06-27 13:00:45.864
9be5231e-d84a-45cf-b040-e1c18052bb8c	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	January 2026	\N	january-2026	month	\N	2026-01-01	2026-01-31	t	2026-06-27 12:55:02.1	2026-06-27 13:00:45.865
adb11090-385a-4408-961e-da832f2c24f9	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	February 2026	\N	february-2026	month	\N	2026-02-01	2026-02-28	t	2026-06-27 12:55:02.101	2026-06-27 13:00:45.866
20c7c2fd-5a09-480e-8353-1df0b5dc8bf2	f5f4e2cd-face-4f7c-94df-0f2c64f8a931	March 2026	\N	march-2026	month	\N	2026-03-01	2026-03-31	t	2026-06-27 12:55:02.102	2026-06-27 13:00:45.867
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_permissions (id, role_id, permission_id) FROM stdin;
4c6553a6-3abc-45e2-909d-6e313e024054	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	6a4ba816-7aa0-48f8-a8b9-215d15a018a9
2461b0ea-dca6-4a48-bd15-512e7e917422	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	82a8e8e5-65bd-47db-9b42-78217d4b3ebd
60af743f-9b35-473f-a1f1-d8862477ce4e	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	78bf5807-7db8-488a-9147-0121ce0808b1
46defd24-f1a9-46ce-b980-de9999525658	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	7564d6db-4dad-4d2a-9323-27f554ae9d46
71de9e73-e923-49d0-9c93-8746942d5499	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	9788801c-7f4a-4860-9527-f1658918eb30
0ff5c4b1-483a-4a3c-9808-59652d752f51	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	def09386-80cf-4cd1-b9ed-bd1b5259450e
0f030d91-fa21-4eb3-a064-97a7b4cdc099	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	1a293d15-9e7a-4c42-89a3-d2c4f84bab64
aa347526-1350-492d-87a4-9edb07c635a5	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	e68e6aa0-1b60-4fe4-994b-db86aaf20c85
d9565832-dce9-4a01-a7e3-3eeac9a47f44	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	72adf1ef-48bb-4b48-89b7-59d4c08f1b8d
0c514adb-be3d-4b74-9e11-f7e33dd3a3ca	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	5ec7d5eb-1d47-488c-a7e9-e147291ace58
8e536875-5b67-462c-9d7e-aaf7f1696d91	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	75d5dacb-02b3-4925-a2bf-0ffec5deb376
2edfd611-9562-4d40-8a3a-2420f6d2c532	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	6c2aedb2-446a-43c5-b99a-1e2db89e402b
5b545966-c1de-4554-9acb-7fb57288b4e1	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	3671f524-19fe-4c74-83d3-d99dcb12b79a
8fff0a7c-5cca-4db4-9115-0a5ebd32bdf6	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	660544b9-01d2-4497-b3b2-a26297c22a3e
43ff2da4-ebbe-4bae-aaa6-eebb0031960a	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	8610cc64-0847-4be5-96e6-8415ed5d49d3
8b8ff7e7-eda5-4897-a39d-e446f1b8ed23	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	2adf3adc-5833-45d8-926d-18b023ba1dde
37b9d546-de99-4682-aeac-8e8f5ea45f7a	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	9cccbd4e-36d3-414d-a113-208ac56ed2fc
e1af36df-5319-4d6c-9508-430930c30d33	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	ac517387-6684-4fda-a7b1-90da9919ad73
e8ad22ad-f2b1-4eae-a458-813b34da3e77	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	e78afe48-908b-421c-96fd-0eab7cee1958
12ecd0a3-ed36-4439-8d2b-02c69d1cfc8d	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	e4c74280-0c19-402a-9ee2-8dc517c31f84
08973da8-912f-441d-9a88-049af8172811	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	a5b05851-d7b3-41a8-bfb2-c8ecde8b617c
b4667eb6-be07-40b0-8901-4554bf27edbe	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	a1d1c7fe-6dcb-4b2c-b5d3-11aeffac02f4
c74b7fcd-c35e-4e17-b29e-f3193e4c3ba2	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	31a2825b-8377-42a7-a266-8b553d9ee68c
1eede584-4acf-45b2-adb1-824a458ddb79	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	b4586678-4eee-4e0f-8b61-4197b32dcb81
a54f4820-ca50-410b-9402-657daa996cf4	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	97b9410a-ca0d-40be-abe1-14ef74f3a97c
6d49459c-7fc3-436f-8eb7-cc7d4b566bbe	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	25840112-ff58-4774-9a65-8636df0c11b4
ba880fbb-d1fb-4bdd-8da1-061e709d2ad8	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	351896ed-44c7-4c65-a030-709c59535bb1
10d5620a-202c-4a22-9a27-aa3285c2c101	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	e1f7704b-a771-484f-911b-47453116001c
d0d0d4ad-d48b-4fea-93b9-f20260683623	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	7ddd452b-ad77-4f23-a049-df72f8f14964
5e3cd3d0-821b-4f4e-87d0-1e14ef5593e7	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	f1be9ab3-4638-4ee5-8e73-c1a82e332f14
b7fa3d86-a542-494e-bdd2-84cfd57eceff	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	32487088-cd9d-499c-84b3-757079de1457
a61495cf-b77f-4bad-8b18-e84bd808f516	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	535a10e8-6a68-427a-a4b1-cc46c1fa2e04
ad112a7e-955c-471e-bce3-082be1ad0a07	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	301a2b98-33cf-4115-bc3a-36f9e5b5b26b
477d82d2-bcf1-4f2c-9b46-8feae03a753d	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	ff2eda52-3d89-4048-9d16-20bf2bbc3977
bd144399-8cd6-4763-8cae-6045b1ee66b1	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	84b7c82a-3ab3-4a8f-8ed4-056777265129
b07ee02b-4bd4-4771-81a0-7e0ddb8cb7b5	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	26d833b1-3910-463d-98b0-812b97718b29
fe92cb5f-60ed-4b86-9be4-9c85fa48a933	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	4962c2e3-1886-426a-8ddf-0d96ba647965
e56173ea-dfae-457b-8401-331d822d05fd	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	ef1864f8-ad73-41b9-8bce-bb8e75d21916
2469ab50-75ce-4a99-98db-273b6da67374	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	bbb2dfd4-19de-440d-9538-cbde34ed3d97
5207e658-06a4-4a0d-9e74-7833f484efbb	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	47ed5865-42d6-47bc-a696-e5b27d329c2a
62af7de5-adb7-497e-99f5-6dcb1a13f5f1	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	e2dfcb0b-afd0-40f5-8565-0c336177de9d
233d0c74-824f-497d-8a3a-1b08c3a3c69b	8f8b1574-d939-4196-90ac-ca4eef26bbd7	6a4ba816-7aa0-48f8-a8b9-215d15a018a9
e525e6b5-d93e-4b56-8a49-5ba28814f05d	8f8b1574-d939-4196-90ac-ca4eef26bbd7	82a8e8e5-65bd-47db-9b42-78217d4b3ebd
0ed034df-224e-4435-abdb-776e0f3342d2	8f8b1574-d939-4196-90ac-ca4eef26bbd7	72adf1ef-48bb-4b48-89b7-59d4c08f1b8d
65787913-7f3e-4fc8-9eea-fae5199407fc	8f8b1574-d939-4196-90ac-ca4eef26bbd7	8610cc64-0847-4be5-96e6-8415ed5d49d3
da5d8a7e-2c04-4982-a465-e02f76ba713c	8f8b1574-d939-4196-90ac-ca4eef26bbd7	2adf3adc-5833-45d8-926d-18b023ba1dde
c112823f-f15c-4c8a-8957-c768bab72e02	8f8b1574-d939-4196-90ac-ca4eef26bbd7	9cccbd4e-36d3-414d-a113-208ac56ed2fc
1ecfea0f-a884-4264-bad2-36108305eb1a	8f8b1574-d939-4196-90ac-ca4eef26bbd7	a1d1c7fe-6dcb-4b2c-b5d3-11aeffac02f4
97b8a83d-8213-4db2-8fb8-89f9063accea	8f8b1574-d939-4196-90ac-ca4eef26bbd7	31a2825b-8377-42a7-a266-8b553d9ee68c
6721fc62-055e-42a1-89a3-37febddf5227	8f8b1574-d939-4196-90ac-ca4eef26bbd7	b4586678-4eee-4e0f-8b61-4197b32dcb81
c080fea1-ab6d-4afc-bcb3-f23ba4249229	8f8b1574-d939-4196-90ac-ca4eef26bbd7	7ddd452b-ad77-4f23-a049-df72f8f14964
bccd3be4-ca6a-4ee4-867d-2362aedb52a3	8f8b1574-d939-4196-90ac-ca4eef26bbd7	f1be9ab3-4638-4ee5-8e73-c1a82e332f14
d2ba133e-11dc-4016-8a81-728337ac809a	8f8b1574-d939-4196-90ac-ca4eef26bbd7	32487088-cd9d-499c-84b3-757079de1457
9c981132-655a-4901-a952-21f5a509d2cb	8f8b1574-d939-4196-90ac-ca4eef26bbd7	535a10e8-6a68-427a-a4b1-cc46c1fa2e04
aff0f755-c919-4749-a029-d2e6c4b8c59f	8f8b1574-d939-4196-90ac-ca4eef26bbd7	301a2b98-33cf-4115-bc3a-36f9e5b5b26b
ad75521e-fa6e-4205-85b2-21ebf78cce6d	8f8b1574-d939-4196-90ac-ca4eef26bbd7	ff2eda52-3d89-4048-9d16-20bf2bbc3977
115c4e65-4134-43fb-9ac4-4b98d4622d37	8f8b1574-d939-4196-90ac-ca4eef26bbd7	84b7c82a-3ab3-4a8f-8ed4-056777265129
c3acd707-d05d-43af-bbd4-815a8676bc33	8f8b1574-d939-4196-90ac-ca4eef26bbd7	26d833b1-3910-463d-98b0-812b97718b29
b8466013-cf81-4717-95e4-4f1b6aea0b13	a465de88-98e7-4062-a0c4-fdeb7911b0e1	78bf5807-7db8-488a-9147-0121ce0808b1
3608c06f-f121-4738-9cb9-3f055b63b8c8	a465de88-98e7-4062-a0c4-fdeb7911b0e1	7564d6db-4dad-4d2a-9323-27f554ae9d46
2da95d26-38fc-4ace-9ee7-3c315e8038d2	a465de88-98e7-4062-a0c4-fdeb7911b0e1	9788801c-7f4a-4860-9527-f1658918eb30
388f0d69-77fc-4091-b7b4-2e9f7c18f0a9	a465de88-98e7-4062-a0c4-fdeb7911b0e1	def09386-80cf-4cd1-b9ed-bd1b5259450e
67b3ec04-05cc-4f1e-a9ad-2d5ab2775f23	a465de88-98e7-4062-a0c4-fdeb7911b0e1	82a8e8e5-65bd-47db-9b42-78217d4b3ebd
4e393dfa-88c5-430b-abb7-ac594b98acbf	a465de88-98e7-4062-a0c4-fdeb7911b0e1	72adf1ef-48bb-4b48-89b7-59d4c08f1b8d
ecc4a322-b61e-4042-aa8d-3158e657d06b	a465de88-98e7-4062-a0c4-fdeb7911b0e1	4962c2e3-1886-426a-8ddf-0d96ba647965
172b53cd-c67f-4f8b-a7c1-9fe37a7662b3	a465de88-98e7-4062-a0c4-fdeb7911b0e1	ef1864f8-ad73-41b9-8bce-bb8e75d21916
34642265-8c47-414e-ac60-f6f65f9d3607	a465de88-98e7-4062-a0c4-fdeb7911b0e1	bbb2dfd4-19de-440d-9538-cbde34ed3d97
66739d97-c420-4c5f-9c44-e9dce198994d	a465de88-98e7-4062-a0c4-fdeb7911b0e1	47ed5865-42d6-47bc-a696-e5b27d329c2a
b919a965-b4a3-4c19-baa4-d66a9f9b5cc4	a465de88-98e7-4062-a0c4-fdeb7911b0e1	e2dfcb0b-afd0-40f5-8565-0c336177de9d
d88bd2bb-875f-4563-a88d-bbc2b3980bfc	a465de88-98e7-4062-a0c4-fdeb7911b0e1	8610cc64-0847-4be5-96e6-8415ed5d49d3
74b35ea4-ffc2-4239-9e17-03b34de38da4	a465de88-98e7-4062-a0c4-fdeb7911b0e1	9cccbd4e-36d3-414d-a113-208ac56ed2fc
f233a5d7-f3ea-4844-9b82-621612dcf150	a465de88-98e7-4062-a0c4-fdeb7911b0e1	ac517387-6684-4fda-a7b1-90da9919ad73
17955a4d-4c77-4a8c-9cf2-bac124a5c91a	a465de88-98e7-4062-a0c4-fdeb7911b0e1	e78afe48-908b-421c-96fd-0eab7cee1958
d235593e-ebf5-4a79-ac4b-2c0277a79f89	a465de88-98e7-4062-a0c4-fdeb7911b0e1	e4c74280-0c19-402a-9ee2-8dc517c31f84
c97c4c9e-4a3e-45c9-9407-15f1913c6768	a465de88-98e7-4062-a0c4-fdeb7911b0e1	a5b05851-d7b3-41a8-bfb2-c8ecde8b617c
7af82af5-4980-4133-9eb4-1aee3368a59e	a465de88-98e7-4062-a0c4-fdeb7911b0e1	a1d1c7fe-6dcb-4b2c-b5d3-11aeffac02f4
373be226-abf8-4f78-82e9-24c0a3693d83	a465de88-98e7-4062-a0c4-fdeb7911b0e1	b4586678-4eee-4e0f-8b61-4197b32dcb81
941655f3-ef3d-4c01-923f-00b5e45e1e87	a465de88-98e7-4062-a0c4-fdeb7911b0e1	97b9410a-ca0d-40be-abe1-14ef74f3a97c
260be4e8-9b96-4584-8d03-ce50788ef35e	a465de88-98e7-4062-a0c4-fdeb7911b0e1	25840112-ff58-4774-9a65-8636df0c11b4
260d6db7-d0b3-494c-8b38-13c00fbb8a64	a465de88-98e7-4062-a0c4-fdeb7911b0e1	351896ed-44c7-4c65-a030-709c59535bb1
e7f0285a-ffed-4ba2-9dfe-b52007e45502	a465de88-98e7-4062-a0c4-fdeb7911b0e1	e1f7704b-a771-484f-911b-47453116001c
77fde6ac-6712-45f2-a1e1-7994abfc57bf	a465de88-98e7-4062-a0c4-fdeb7911b0e1	7ddd452b-ad77-4f23-a049-df72f8f14964
2b1a2390-96a3-437c-970f-86f96a7d0a7b	a465de88-98e7-4062-a0c4-fdeb7911b0e1	f1be9ab3-4638-4ee5-8e73-c1a82e332f14
4569a97c-f03b-4f41-be08-064c2227da90	a465de88-98e7-4062-a0c4-fdeb7911b0e1	32487088-cd9d-499c-84b3-757079de1457
dcb12c95-95f0-40e5-b45f-6499bdc10f49	a465de88-98e7-4062-a0c4-fdeb7911b0e1	535a10e8-6a68-427a-a4b1-cc46c1fa2e04
01cbf5bc-916e-4eac-babc-5b1c231d2e6f	a465de88-98e7-4062-a0c4-fdeb7911b0e1	301a2b98-33cf-4115-bc3a-36f9e5b5b26b
689140ff-a786-452c-9646-eea95b8bdada	a465de88-98e7-4062-a0c4-fdeb7911b0e1	ff2eda52-3d89-4048-9d16-20bf2bbc3977
1796f5b6-0b26-47d0-a2b6-6657ca259276	a465de88-98e7-4062-a0c4-fdeb7911b0e1	84b7c82a-3ab3-4a8f-8ed4-056777265129
3c81221a-56da-47d3-8965-7ea1bdb74a0c	a465de88-98e7-4062-a0c4-fdeb7911b0e1	26d833b1-3910-463d-98b0-812b97718b29
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, key, name_en, description, is_system, created_at, updated_at) FROM stdin;
438bcfae-b0d4-4d8e-bce5-a686ddafdbf7	super_admin	Super Admin	Full access to all modules, users, masters, and settings.	t	2026-06-27 12:55:01.496	2026-06-27 13:00:45.326
8f8b1574-d939-4196-90ac-ca4eef26bbd7	content_editor	Content Editor	Create and edit draft content. Cannot publish, archive, or manage the system.	t	2026-06-27 12:55:01.5	2026-06-27 13:00:45.328
a465de88-98e7-4062-a0c4-fdeb7911b0e1	publisher	Publisher	Publish, unpublish, archive, and restore content; edit where granted.	t	2026-06-27 12:55:01.501	2026-06-27 13:00:45.328
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.settings (id, key, value_text, value_json, description, updated_by, updated_at) FROM stdin;
8a283b4e-026c-4ee6-b1c5-dde4620f11de	contact.office_name		null	Office name shown on Contact.	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 13:00:46.071
eecdd386-6c50-4460-9d4b-bfb586a8110d	contact.address	Demo Secretariat, Ranchi, Jharkhand	null	Postal address.	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 13:00:46.072
03c89c12-7283-4edf-8d4b-f157377b3491	contact.phone	+91 651 000 0000	null	Public phone number.	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 13:00:46.073
5414aca2-01f4-4062-9bcf-46ebc23250ab	contact.email	demo@sidhkofed.example	null	Public contact email.	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 13:00:46.073
49a502e9-f2f3-45de-912d-28bbab5cbb68	contact.office_hours	Monday-Friday, 10:00-17:00	null	Office hours text.	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 13:00:46.074
f5bd3848-f093-4ed2-baad-3065095eb899	contact.map_url	https://maps.example.test/sidhkofed-demo	null	Map embed/link URL.	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 13:00:46.075
bd46aae0-9720-4fc4-8742-00dbcd6ecba3	social.facebook_url		null	Facebook page URL.	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 13:00:46.076
5e7559de-5c9f-44ae-9335-824c033a7203	social.twitter_url		null	X/Twitter URL.	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 13:00:46.076
46130e9f-c4a0-4cec-a2fc-60ac54b9a11f	social.youtube_url		null	YouTube channel URL.	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 13:00:46.077
7a873718-7c88-4fdd-a86c-7ff1635cf441	social.instagram_url		null	Instagram URL.	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 13:00:46.078
b3ba88a4-2593-49d9-bd4b-9f3da1a67757	limits.homepage_highlight_limit	6	null	Max highlighted items surfaced on the homepage.	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 13:00:46.086
ecabda64-feec-4243-b36e-c4d808e9a714	limits.video_homepage_limit	3	null	Max featured homepage videos (cap 3 per requirements).	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 13:00:46.087
c3bf08f4-c476-4de6-a827-aa33aa61aa52	translation.fallback_enabled	false	null	Enable labeled machine-translation fallback.	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 13:00:46.087
e16ebd9d-f8ba-4083-a704-5e8eef992c60	social.linkedin_url		null	LinkedIn URL.	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 13:00:46.078
1e0385e7-aa0e-42a6-a654-db1428346627	footer.copyright_text	© SIDHKOFED	null	Footer copyright line.	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 13:00:46.079
8a74eb7c-9a4b-4e72-8df9-a64726f30d71	footer.important_links	\N	[]	Footer important links.	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 13:00:46.08
e1b3092d-32e2-49bc-bd64-a702302ef0a1	seo.default_title	SIDHKOFED	null	Default SEO/social title.	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 13:00:46.081
26454fd5-3b14-48e4-9a21-93cf0fad0f40	seo.default_description	Fictional SIDHKOFED CMS fixture portal.	null	Default meta description.	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 13:00:46.082
71e6c2ab-baba-446c-8c5b-9f691078ce4c	seo.default_social_image_media_id	6853eb6c-ba01-4312-b751-b608641a94f5	null	Default social share image (media id).	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 13:00:46.082
243debcc-7c26-4048-b2d4-2056fb1cf0b5	uploads.max_image_mb	10	null	Max image upload size (MB).	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 13:00:46.083
3a255add-060e-4fa7-beb7-2152173fdeca	site.name	SIDHKOFED Demo Portal	null	Public site / office name.	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 13:00:46.066
ebb0fc27-072a-4332-a1db-6608c6a01355	site.tagline	Fictional cooperative development data for CMS testing	null	Short site tagline.	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 13:00:46.067
d42e3527-abbb-4071-a94e-f6004b00e6ac	site.logo_media_id	3f24f935-ecf7-4c53-bd05-2d673cef6692	null	Media asset id of the site logo.	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 13:00:46.068
b5799db1-65a7-4328-bbd5-b7a91da6bb44	site.default_language	en	null	Default UI language.	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 13:00:46.069
4c627058-3a23-47c3-84f0-63b8cd1b3c40	homepage.show_dashboard_kpis	true	null	Show the KPI band on the homepage.	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 13:00:46.07
1a042bb2-b058-4c97-91e8-bbf37384dfda	homepage.featured_partners_limit	8	null	Max partner logos on the homepage.	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 13:00:46.07
b23129dc-b47d-46f2-ae7b-21a0d406a95f	uploads.max_document_mb	25	null	Max document upload size (MB).	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 13:00:46.084
89980967-7c20-4a33-a083-b737f2bb9026	uploads.allowed_image_types	\N	["image/jpeg", "image/png", "image/webp", "image/gif"]	Allowed image MIME types.	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 13:00:46.084
e4fd527d-50ae-4871-9f6d-bb827d5a67d6	uploads.allowed_document_types	\N	["application/pdf", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"]	Allowed document MIME types.	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 13:00:46.085
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tags (id, name_en, name_hi, slug, is_active, created_at, updated_at) FROM stdin;
20323969-dfd0-4c48-9110-0b01ff01db38	Lac	\N	lac	t	2026-06-27 12:55:02.103	2026-06-27 13:00:45.868
faeb0032-27da-4135-9b5f-e9b459bca286	Honey	\N	honey	t	2026-06-27 12:55:02.106	2026-06-27 13:00:45.869
da31bd72-846a-400b-a9db-71cee53fc8c7	Millets	\N	millets	t	2026-06-27 12:55:02.107	2026-06-27 13:00:45.87
8fe861d8-5643-406d-a755-67e3c41e49a4	Training	\N	training	t	2026-06-27 12:55:02.108	2026-06-27 13:00:45.871
916c7a1c-25c6-4e06-bc21-fb648e749155	Procurement	\N	procurement	t	2026-06-27 12:55:02.108	2026-06-27 13:00:45.871
3b750363-0a23-453e-a994-99e822372d4d	Membership	\N	membership	t	2026-06-27 12:55:02.109	2026-06-27 13:00:45.872
6f39163d-11eb-41cd-8896-5bb3b7fe1b42	Women Led	\N	women-led	t	2026-06-27 12:55:02.109	2026-06-27 13:00:45.873
bf95bd6c-a3be-4411-aae7-46f2538356bd	District Coverage	\N	district-coverage	t	2026-06-27 12:55:02.11	2026-06-27 13:00:45.874
54e9b49e-78af-48da-8b81-2972b70ddadb	Policy	\N	policy	t	2026-06-27 12:55:02.11	2026-06-27 13:00:45.874
e52ede18-9e93-45c6-9b7b-785c0ed345b8	Research	\N	research	t	2026-06-27 12:55:02.111	2026-06-27 13:00:45.875
020b2af1-be29-460e-a04c-7db48eca5629	Toolkit	\N	toolkit	t	2026-06-27 12:55:02.112	2026-06-27 13:00:45.875
5dc047c4-f3f9-4ca4-98f2-148fd2c54a57	Cooperative	\N	cooperative	t	2026-06-27 12:55:02.112	2026-06-27 13:00:45.876
\.


--
-- Data for Name: tender_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tender_types (id, name_en, name_hi, slug, is_active, display_order, created_at, updated_at) FROM stdin;
844fcb23-647a-4b14-9d31-56ab7f1089dc	Goods	\N	goods	t	1	2026-06-27 12:55:01.963	2026-06-27 13:00:45.775
52abf73e-e80f-4fc6-9c8c-033477b26901	Works	\N	works	t	2	2026-06-27 12:55:01.966	2026-06-27 13:00:45.776
62ccb434-8678-47df-aaa9-cc4fbcb88265	Services	\N	services	t	3	2026-06-27 12:55:01.967	2026-06-27 13:00:45.777
d6ebbdc6-16bb-440f-a6d6-6c3b9caaa3ce	Consultancy	\N	consultancy	t	4	2026-06-27 12:55:01.968	2026-06-27 13:00:45.778
\.


--
-- Data for Name: tenders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tenders (id, title_en, title_hi, summary_en, summary_hi, tender_type_id, tender_number, publish_date, submission_deadline, opening_date, tender_status, gem_url, slug, publication_state, public_visibility, publish_start_at, published_at, archived_at, highlight_type, highlight_start_at, highlight_end_at, display_order, show_on_homepage, created_by, updated_by, created_at, updated_at) FROM stdin;
b7fb2fdd-a631-4461-82d5-69ed92f2f152	Demo tender record 10	\N	Fictional tender content covering Sal Seed.	\N	52abf73e-e80f-4fc6-9c8c-033477b26901	DEMO-TENDER-010	2026-04-01	2026-09-20 12:00:00	2026-09-21 10:00:00	closed	https://gem.gov.in/demo/10	demo-tender-10	published	f	\N	2026-01-15 08:00:00	\N	\N	\N	\N	10	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.263	2026-06-27 13:00:46.928
3f394ae3-bc81-49ce-a9a9-e7af4d058533	Demo tender record 11	डेमो सूचना 11	Fictional tender content covering Karanj.	\N	62ccb434-8678-47df-aaa9-cc4fbcb88265	DEMO-TENDER-011	2026-05-01	2026-10-20 12:00:00	2026-10-21 10:00:00	closed	https://gem.gov.in/demo/11	demo-tender-11	draft	t	\N	\N	\N	\N	\N	\N	11	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.264	2026-06-27 13:00:46.929
0559c110-74cf-492c-b850-7f45ca9c8939	Demo tender record 12	\N	Fictional tender content covering Tamarind.	\N	d6ebbdc6-16bb-440f-a6d6-6c3b9caaa3ce	DEMO-TENDER-012	2026-06-01	2026-11-20 12:00:00	2026-11-21 10:00:00	closed	https://gem.gov.in/demo/12	demo-tender-12	archived	f	\N	2026-01-15 08:00:00	2026-06-27 08:00:00	\N	\N	\N	12	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.266	2026-06-27 13:00:46.931
59ee1a3a-3d09-4630-9930-01399b3d8a6f	Demo tender record 1	डेमो सूचना 1	Fictional tender content covering Lac.	\N	844fcb23-647a-4b14-9d31-56ab7f1089dc	DEMO-TENDER-001	2026-01-01	2026-06-20 12:00:00	2026-06-21 10:00:00	active	https://gem.gov.in/demo/1	demo-tender-1	published	t	\N	2026-01-15 08:00:00	\N	featured	2026-01-15 08:00:00	2027-01-15 08:00:00	1	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.238	2026-06-27 13:00:46.91
9446ba99-c155-435e-8752-5bdf4faffa5a	Demo tender record 2	\N	Fictional tender content covering Honey.	\N	52abf73e-e80f-4fc6-9c8c-033477b26901	DEMO-TENDER-002	2026-02-01	2026-07-20 12:00:00	2026-07-21 10:00:00	active	https://gem.gov.in/demo/2	demo-tender-2	published	t	\N	2026-01-15 08:00:00	\N	latest	2026-01-15 08:00:00	2027-01-15 08:00:00	2	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.247	2026-06-27 13:00:46.913
164a4c43-9488-4b03-8fb8-63173f732759	Demo tender record 3	डेमो सूचना 3	Fictional tender content covering Ragi / Millets.	\N	62ccb434-8678-47df-aaa9-cc4fbcb88265	DEMO-TENDER-003	2026-03-01	2026-08-20 12:00:00	2026-08-21 10:00:00	active	https://gem.gov.in/demo/3	demo-tender-3	published	t	\N	2026-01-15 08:00:00	\N	important	2026-01-15 08:00:00	2027-01-15 08:00:00	3	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.25	2026-06-27 13:00:46.915
22da0c2d-e536-43bf-b880-c36c001515eb	Demo tender record 4	\N	Fictional tender content covering Sal Seed.	\N	d6ebbdc6-16bb-440f-a6d6-6c3b9caaa3ce	DEMO-TENDER-004	2026-04-01	2026-09-20 12:00:00	2026-09-21 10:00:00	active	https://gem.gov.in/demo/4	demo-tender-4	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	4	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.251	2026-06-27 13:00:46.917
684c5368-0f12-45c5-9b3d-de03a8d84edc	Demo tender record 5	डेमो सूचना 5	Fictional tender content covering Karanj.	\N	844fcb23-647a-4b14-9d31-56ab7f1089dc	DEMO-TENDER-005	2026-05-01	2026-10-20 12:00:00	2026-10-21 10:00:00	active	https://gem.gov.in/demo/5	demo-tender-5	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	5	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.254	2026-06-27 13:00:46.919
6e2c8de9-ae13-4774-8b0f-be832a8ee856	Demo tender record 6	\N	Fictional tender content covering Tamarind.	\N	52abf73e-e80f-4fc6-9c8c-033477b26901	DEMO-TENDER-006	2026-06-01	2026-11-20 12:00:00	2026-11-21 10:00:00	active	https://gem.gov.in/demo/6	demo-tender-6	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	6	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.256	2026-06-27 13:00:46.92
40c96116-9637-4746-9e34-58a90ced7998	Demo tender record 7	डेमो सूचना 7	Fictional tender content covering Lac.	\N	62ccb434-8678-47df-aaa9-cc4fbcb88265	DEMO-TENDER-007	2026-01-01	2026-06-20 12:00:00	2026-06-21 10:00:00	closed	https://gem.gov.in/demo/7	demo-tender-7	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	7	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.257	2026-06-27 13:00:46.922
b125c6c8-927e-409e-a7ee-be3ea1ac4765	Demo tender record 8	\N	Fictional tender content covering Honey.	\N	d6ebbdc6-16bb-440f-a6d6-6c3b9caaa3ce	DEMO-TENDER-008	2026-02-01	2026-07-20 12:00:00	2026-07-21 10:00:00	closed	https://gem.gov.in/demo/8	demo-tender-8	unpublished	t	\N	\N	\N	\N	\N	\N	8	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.259	2026-06-27 13:00:46.924
19383a16-2dd6-4a19-8ae0-ae35140ea818	Demo tender record 9	डेमो सूचना 9	Fictional tender content covering Ragi / Millets.	\N	844fcb23-647a-4b14-9d31-56ab7f1089dc	DEMO-TENDER-009	2026-03-01	2026-08-20 12:00:00	2026-08-21 10:00:00	closed	https://gem.gov.in/demo/9	demo-tender-9	published	t	2027-01-15 08:00:00	2026-01-15 08:00:00	\N	\N	\N	\N	9	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.261	2026-06-27 13:00:46.926
\.


--
-- Data for Name: toolkit_distribution_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.toolkit_distribution_items (id, toolkit_distribution_summary_id, toolkit_item_id, distribution_basis, quantity_per_unit, number_of_units_or_groups, total_quantity, manual_override) FROM stdin;
44ae55cd-a793-4eb7-abc4-09755d5ad5ac	455d0d80-3267-4d57-9718-cd0bac0d7f98	658d87e2-b61a-4641-8fab-577d7c1110f3	individual	1.00	10	10.00	f
ed3b66bd-cf22-4d0c-9264-125153454c29	455d0d80-3267-4d57-9718-cd0bac0d7f98	46e73c79-4dd0-44ea-b22e-0e1ec88e6c1a	group	2.00	10	20.00	f
1f5db9dc-f5f6-4e71-9d10-00eac0685842	455d0d80-3267-4d57-9718-cd0bac0d7f98	3c122161-8aff-4fcc-8640-d852fd11cd13	individual	3.00	10	30.00	t
6afdb85b-da75-45ca-81ef-04f33b43b6c1	45cc9b85-a4d9-4700-876d-2708b0aa50ec	e92c6897-8803-4234-8963-8a993990d04b	individual	1.00	11	11.00	f
0c1a8319-2b01-415e-b216-37120477140c	45cc9b85-a4d9-4700-876d-2708b0aa50ec	8dee0892-2620-4eb5-b093-3ccd81e7ef6b	group	2.00	11	22.00	f
45717a81-a6a3-4f72-816d-7f258d5ebcf6	45cc9b85-a4d9-4700-876d-2708b0aa50ec	62e9f595-4690-43f4-8760-3ecda8120b4c	individual	3.00	11	33.00	t
cf46b717-5bf5-4db9-893c-901eca22ac43	f0fdd7e4-9b25-45db-b94b-bec59517da84	6515be7e-ce5e-4f67-a037-10e5c9cc29ca	individual	1.00	12	12.00	f
20f0954d-7a97-48be-bc78-3f08b1b17e4e	f0fdd7e4-9b25-45db-b94b-bec59517da84	90f7e9e4-069f-47a1-b9fd-dd546072ad3d	group	2.00	12	24.00	f
03b44de2-a8c0-436d-99c5-a4421ceb91e7	f0fdd7e4-9b25-45db-b94b-bec59517da84	b1b6153e-c91a-4148-9399-b384809531a5	individual	3.00	12	36.00	t
5fc96797-0be4-4768-85c2-afe1032b0df2	9cb83a14-880c-4d8f-9c91-a6672cff0390	2c7c822e-1bba-4f36-b82d-0de40f5a8642	individual	1.00	13	13.00	f
0242263c-8ac0-4d7f-ba8a-a2c84a391ef9	9cb83a14-880c-4d8f-9c91-a6672cff0390	66fb9596-1ea7-49d5-b462-684eb20b6214	group	2.00	13	26.00	f
17e0faa5-54d9-4aed-a0eb-644aba9493d6	9cb83a14-880c-4d8f-9c91-a6672cff0390	0266afbf-e58f-4bf1-a593-1e019bb3a6f4	individual	3.00	13	39.00	t
3613edab-8bc9-4aa8-a82b-71267bfae683	0c5a9ad4-93db-4920-8ed0-a601978be578	c64ba20a-2385-4420-a7f2-1b8192bd0c43	individual	1.00	14	14.00	f
54c5da5f-980e-43f9-b660-e722464627b2	0c5a9ad4-93db-4920-8ed0-a601978be578	71b911e9-410e-45ea-9d69-8113e3506bbd	group	2.00	14	28.00	f
f02f3376-48dc-4fed-a2a3-2c6aeadb2534	0c5a9ad4-93db-4920-8ed0-a601978be578	0bc6731f-b791-4946-92a3-e28e236825b8	individual	3.00	14	42.00	t
94a0489b-43b2-4d74-a402-da53eae30e01	d224f123-bb4e-469d-bb31-56a962a00b1c	ffdac2cd-9921-4dce-84e5-5954e6edc3c3	individual	1.00	15	15.00	f
2abddef5-1c32-41a7-86f3-01f1b2459c6e	d224f123-bb4e-469d-bb31-56a962a00b1c	5acf7f57-7424-4b0a-b8dc-702c5ec89632	group	2.00	15	30.00	f
3b401b19-e0f3-46fb-aa35-af765e29b479	d224f123-bb4e-469d-bb31-56a962a00b1c	a2e0d57a-1f75-4bd6-8f2a-3c0b15352f96	individual	3.00	15	45.00	t
178544ff-c5f1-44c8-9c4d-594048c1b3aa	a4728e70-9853-4c38-be4f-35ae057affe7	195b89b2-9cee-4ed6-a7cf-b741d14f4e37	individual	1.00	16	16.00	f
f794a8b9-7574-4ceb-bb8d-6b023d358af6	a4728e70-9853-4c38-be4f-35ae057affe7	4a33c384-284c-41ab-ac5a-aec04880d203	group	2.00	16	32.00	f
c73188b2-01c3-440b-b26f-12699f093087	a4728e70-9853-4c38-be4f-35ae057affe7	c4ecb7e5-5ab7-4d38-aa6c-9de0b5bfdb38	individual	3.00	16	48.00	t
f35eb889-9773-4e99-85cb-a35d2d609a7c	eca67c64-915a-4bb2-877f-e40589a1338f	c5d38d4f-e5a8-4de6-9f65-636111781752	individual	1.00	17	17.00	f
a6bfe979-6a4d-4dbd-aa32-0c902e7a19a1	eca67c64-915a-4bb2-877f-e40589a1338f	bdce49ca-141e-4947-a733-4ff55412d98d	group	2.00	17	34.00	f
465d1b11-83ac-4a27-a037-a592b2f1d623	eca67c64-915a-4bb2-877f-e40589a1338f	5407c807-c51c-46dc-b3dd-7673abd6d9ca	individual	3.00	17	51.00	t
0b0194c3-44b3-43fc-af9d-984fe3f2e1d8	da7353ac-088e-4c30-9ae2-560d04b6fa69	4e2951ec-12a1-433e-bab0-7c76cdc29642	individual	1.00	18	18.00	f
1cb54bbe-8b91-4963-bef5-2cfb40dcde98	da7353ac-088e-4c30-9ae2-560d04b6fa69	205fd528-62ce-4008-bc83-466504f69b9c	group	2.00	18	36.00	f
a4654a84-fd55-49dc-bf0d-f5f1866cb525	da7353ac-088e-4c30-9ae2-560d04b6fa69	3631a954-0047-412d-9955-ae40856fa6be	individual	3.00	18	54.00	t
d5647305-f207-41b6-84f3-dde702be3836	3531c904-7539-405f-9479-baaf43318876	4ee2055b-d36d-4930-bbc5-ad4d91e4988f	individual	1.00	19	19.00	f
9ce230ae-4e82-4470-9bff-c43cc8491161	3531c904-7539-405f-9479-baaf43318876	cd06100a-a6b9-48dd-ba13-b914749627d2	group	2.00	19	38.00	f
eaf28cc6-fb30-40fe-84b5-d305dc7053f6	3531c904-7539-405f-9479-baaf43318876	509355f7-d1cb-455f-a6c7-c6f10bc52bec	individual	3.00	19	57.00	t
d2f1b583-44ee-4b8f-b83d-e53f274f5599	370f444c-9d94-4693-bf98-190e51a84ba8	658d87e2-b61a-4641-8fab-577d7c1110f3	individual	1.00	20	20.00	f
fff48876-6321-4e08-b88e-f983d547e0a8	370f444c-9d94-4693-bf98-190e51a84ba8	46e73c79-4dd0-44ea-b22e-0e1ec88e6c1a	group	2.00	20	40.00	f
1c4b621a-61cc-4d8c-9c94-12c4b03eaa29	370f444c-9d94-4693-bf98-190e51a84ba8	3c122161-8aff-4fcc-8640-d852fd11cd13	individual	3.00	20	60.00	t
e62482e1-afd8-4259-91a2-ba381542ff98	b848e832-d3c0-4961-aa64-e8aa58af59e1	e92c6897-8803-4234-8963-8a993990d04b	individual	1.00	21	21.00	f
48b05212-40ee-49b2-a693-070b94a9dde1	b848e832-d3c0-4961-aa64-e8aa58af59e1	8dee0892-2620-4eb5-b093-3ccd81e7ef6b	group	2.00	21	42.00	f
bb074b65-0545-493b-99fa-9463d829c38b	b848e832-d3c0-4961-aa64-e8aa58af59e1	62e9f595-4690-43f4-8760-3ecda8120b4c	individual	3.00	21	63.00	t
\.


--
-- Data for Name: toolkit_distribution_summaries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.toolkit_distribution_summaries (id, event_id, toolkit_id, distribution_done, distribution_model, participants_covered, distribution_date, remarks_en, remarks_hi, created_by, updated_by, created_at, updated_at) FROM stdin;
455d0d80-3267-4d57-9718-cd0bac0d7f98	90816975-fff8-4e41-914c-4a434b87fbdf	6bbef6fc-41ac-42c9-8fa5-f04afea05579	t	mixed	30	2025-01-12	Fictional distribution summary.	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.161	2026-06-27 13:00:46.85
45cc9b85-a4d9-4700-876d-2708b0aa50ec	24f83e40-7156-4ee4-ab8a-ec2925392ca9	62e1cc34-89da-4d8d-b947-1f0fd0aeae1a	t	group	34	2025-02-12	Fictional distribution summary.	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.173	2026-06-27 13:00:46.858
f0fdd7e4-9b25-45db-b94b-bec59517da84	8424284e-5a82-451c-8863-baffeeb71f2b	22dbc69f-7dcd-480a-976c-30fda77691d3	t	individual	38	2025-03-12	Fictional distribution summary.	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.177	2026-06-27 13:00:46.861
9cb83a14-880c-4d8f-9c91-a6672cff0390	c3a7c7ac-27c3-4c66-a7f0-79d0907d5272	b0c62d90-ac55-439d-9fe8-3c3eacd5ed25	t	mixed	42	2025-04-12	Fictional distribution summary.	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.18	2026-06-27 13:00:46.864
0c5a9ad4-93db-4920-8ed0-a601978be578	973f4234-e445-424a-8053-9490f7fcc956	459a150c-24de-4f90-ac0d-8d3d53bf4b37	t	individual	46	2025-05-12	Fictional distribution summary.	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.183	2026-06-27 13:00:46.866
d224f123-bb4e-469d-bb31-56a962a00b1c	82cf3be5-7fa5-45b9-8d71-08b15cab4642	c82ac9d2-d8c1-487e-8aa6-547c5f1a2508	t	group	50	2025-06-12	Fictional distribution summary.	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.187	2026-06-27 13:00:46.869
a4728e70-9853-4c38-be4f-35ae057affe7	3484093c-ee25-4a22-a2d2-e7c870c200df	1ee77721-7abc-4c19-8e61-dc8dc457bd3e	t	mixed	54	2025-07-12	Fictional distribution summary.	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.19	2026-06-27 13:00:46.872
eca67c64-915a-4bb2-877f-e40589a1338f	f20b1cdf-e8a9-43e4-a23b-f1a1783e0d2c	46218205-5ea4-47af-8df3-5a1bb8c26925	t	group	58	2025-08-12	Fictional distribution summary.	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.193	2026-06-27 13:00:46.875
da7353ac-088e-4c30-9ae2-560d04b6fa69	e30b279f-fd18-497a-bd1a-a0b5beaafb63	d252cd05-da84-42c0-8633-23bd535bc9dd	t	individual	62	2025-09-12	Fictional distribution summary.	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.196	2026-06-27 13:00:46.878
3531c904-7539-405f-9479-baaf43318876	5e20a76d-7323-4bd8-b6ba-234b3aa33141	6d60c8a4-809a-4bc7-bc2b-5b751ae87c3c	t	mixed	66	2025-01-12	Fictional distribution summary.	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.199	2026-06-27 13:00:46.88
370f444c-9d94-4693-bf98-190e51a84ba8	b49ec2d0-2c30-4f6e-bd35-871a2f281eb7	6bbef6fc-41ac-42c9-8fa5-f04afea05579	t	individual	70	2025-02-12	Fictional distribution summary.	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.202	2026-06-27 13:00:46.883
b848e832-d3c0-4961-aa64-e8aa58af59e1	73acb719-a481-4f93-9edb-395bcd8fafc5	62e1cc34-89da-4d8d-b947-1f0fd0aeae1a	t	group	74	2025-03-12	Fictional distribution summary.	\N	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.204	2026-06-27 13:00:46.885
\.


--
-- Data for Name: toolkit_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.toolkit_items (id, toolkit_id, name_en, name_hi, description_en, description_hi, unit, distribution_basis, default_quantity_per_unit, default_group_size, quantity_summary, is_active, display_order, created_at, updated_at) FROM stdin;
cd06100a-a6b9-48dd-ba13-b914749627d2	6d60c8a4-809a-4bc7-bc2b-5b751ae87c3c	Protective material	\N	Fictional test item.	\N	set	group	2.00	10	26.00	t	2	2026-06-27 12:55:02.52	2026-06-27 13:00:46.258
509355f7-d1cb-455f-a6c7-c6f10bc52bec	6d60c8a4-809a-4bc7-bc2b-5b751ae87c3c	Reference booklet	संदर्भ पुस्तिका	Fictional test item.	\N	copy	individual	1.00	\N	27.00	f	3	2026-06-27 12:55:02.52	2026-06-27 13:00:46.259
3c122161-8aff-4fcc-8640-d852fd11cd13	6bbef6fc-41ac-42c9-8fa5-f04afea05579	Reference booklet	संदर्भ पुस्तिका	Fictional test item.	\N	copy	individual	1.00	\N	27.00	t	3	2026-06-27 12:55:02.486	2026-06-27 13:00:46.214
e92c6897-8803-4234-8963-8a993990d04b	62e1cc34-89da-4d8d-b947-1f0fd0aeae1a	Field tool set	\N	Fictional test item.	\N	set	individual	2.00	\N	25.00	t	1	2026-06-27 12:55:02.492	2026-06-27 13:00:46.217
8dee0892-2620-4eb5-b093-3ccd81e7ef6b	62e1cc34-89da-4d8d-b947-1f0fd0aeae1a	Protective material	\N	Fictional test item.	\N	set	group	2.00	10	26.00	t	2	2026-06-27 12:55:02.492	2026-06-27 13:00:46.218
62e9f595-4690-43f4-8760-3ecda8120b4c	62e1cc34-89da-4d8d-b947-1f0fd0aeae1a	Reference booklet	संदर्भ पुस्तिका	Fictional test item.	\N	copy	individual	1.00	\N	27.00	t	3	2026-06-27 12:55:02.492	2026-06-27 13:00:46.219
6515be7e-ce5e-4f67-a037-10e5c9cc29ca	22dbc69f-7dcd-480a-976c-30fda77691d3	Field tool set	\N	Fictional test item.	\N	set	individual	2.00	\N	25.00	t	1	2026-06-27 12:55:02.495	2026-06-27 13:00:46.222
90f7e9e4-069f-47a1-b9fd-dd546072ad3d	22dbc69f-7dcd-480a-976c-30fda77691d3	Protective material	\N	Fictional test item.	\N	set	group	2.00	10	26.00	t	2	2026-06-27 12:55:02.495	2026-06-27 13:00:46.223
b1b6153e-c91a-4148-9399-b384809531a5	22dbc69f-7dcd-480a-976c-30fda77691d3	Reference booklet	संदर्भ पुस्तिका	Fictional test item.	\N	copy	individual	1.00	\N	27.00	t	3	2026-06-27 12:55:02.495	2026-06-27 13:00:46.223
2c7c822e-1bba-4f36-b82d-0de40f5a8642	b0c62d90-ac55-439d-9fe8-3c3eacd5ed25	Field tool set	\N	Fictional test item.	\N	set	individual	2.00	\N	25.00	t	1	2026-06-27 12:55:02.499	2026-06-27 13:00:46.226
66fb9596-1ea7-49d5-b462-684eb20b6214	b0c62d90-ac55-439d-9fe8-3c3eacd5ed25	Protective material	\N	Fictional test item.	\N	set	group	2.00	10	26.00	t	2	2026-06-27 12:55:02.499	2026-06-27 13:00:46.227
0266afbf-e58f-4bf1-a593-1e019bb3a6f4	b0c62d90-ac55-439d-9fe8-3c3eacd5ed25	Reference booklet	संदर्भ पुस्तिका	Fictional test item.	\N	copy	individual	1.00	\N	27.00	t	3	2026-06-27 12:55:02.499	2026-06-27 13:00:46.229
ffdac2cd-9921-4dce-84e5-5954e6edc3c3	c82ac9d2-d8c1-487e-8aa6-547c5f1a2508	Field tool set	\N	Fictional test item.	\N	set	individual	2.00	\N	25.00	t	1	2026-06-27 12:55:02.506	2026-06-27 13:00:46.237
5acf7f57-7424-4b0a-b8dc-702c5ec89632	c82ac9d2-d8c1-487e-8aa6-547c5f1a2508	Protective material	\N	Fictional test item.	\N	set	group	2.00	10	26.00	t	2	2026-06-27 12:55:02.506	2026-06-27 13:00:46.238
a2e0d57a-1f75-4bd6-8f2a-3c0b15352f96	c82ac9d2-d8c1-487e-8aa6-547c5f1a2508	Reference booklet	संदर्भ पुस्तिका	Fictional test item.	\N	copy	individual	1.00	\N	27.00	t	3	2026-06-27 12:55:02.506	2026-06-27 13:00:46.239
195b89b2-9cee-4ed6-a7cf-b741d14f4e37	1ee77721-7abc-4c19-8e61-dc8dc457bd3e	Field tool set	\N	Fictional test item.	\N	set	individual	2.00	\N	25.00	t	1	2026-06-27 12:55:02.509	2026-06-27 13:00:46.242
4a33c384-284c-41ab-ac5a-aec04880d203	1ee77721-7abc-4c19-8e61-dc8dc457bd3e	Protective material	\N	Fictional test item.	\N	set	group	2.00	10	26.00	t	2	2026-06-27 12:55:02.509	2026-06-27 13:00:46.243
c4ecb7e5-5ab7-4d38-aa6c-9de0b5bfdb38	1ee77721-7abc-4c19-8e61-dc8dc457bd3e	Reference booklet	संदर्भ पुस्तिका	Fictional test item.	\N	copy	individual	1.00	\N	27.00	t	3	2026-06-27 12:55:02.509	2026-06-27 13:00:46.244
c5d38d4f-e5a8-4de6-9f65-636111781752	46218205-5ea4-47af-8df3-5a1bb8c26925	Field tool set	\N	Fictional test item.	\N	set	individual	2.00	\N	25.00	t	1	2026-06-27 12:55:02.513	2026-06-27 13:00:46.246
bdce49ca-141e-4947-a733-4ff55412d98d	46218205-5ea4-47af-8df3-5a1bb8c26925	Protective material	\N	Fictional test item.	\N	set	group	2.00	10	26.00	t	2	2026-06-27 12:55:02.513	2026-06-27 13:00:46.247
5407c807-c51c-46dc-b3dd-7673abd6d9ca	46218205-5ea4-47af-8df3-5a1bb8c26925	Reference booklet	संदर्भ पुस्तिका	Fictional test item.	\N	copy	individual	1.00	\N	27.00	t	3	2026-06-27 12:55:02.513	2026-06-27 13:00:46.249
4e2951ec-12a1-433e-bab0-7c76cdc29642	d252cd05-da84-42c0-8633-23bd535bc9dd	Field tool set	\N	Fictional test item.	\N	set	individual	2.00	\N	25.00	t	1	2026-06-27 12:55:02.516	2026-06-27 13:00:46.252
205fd528-62ce-4008-bc83-466504f69b9c	d252cd05-da84-42c0-8633-23bd535bc9dd	Protective material	\N	Fictional test item.	\N	set	group	2.00	10	26.00	t	2	2026-06-27 12:55:02.516	2026-06-27 13:00:46.253
3631a954-0047-412d-9955-ae40856fa6be	d252cd05-da84-42c0-8633-23bd535bc9dd	Reference booklet	संदर्भ पुस्तिका	Fictional test item.	\N	copy	individual	1.00	\N	27.00	t	3	2026-06-27 12:55:02.516	2026-06-27 13:00:46.254
4ee2055b-d36d-4930-bbc5-ad4d91e4988f	6d60c8a4-809a-4bc7-bc2b-5b751ae87c3c	Field tool set	\N	Fictional test item.	\N	set	individual	2.00	\N	25.00	t	1	2026-06-27 12:55:02.52	2026-06-27 13:00:46.257
658d87e2-b61a-4641-8fab-577d7c1110f3	6bbef6fc-41ac-42c9-8fa5-f04afea05579	Field tool set	\N	Fictional test item.	\N	set	individual	2.00	\N	25.00	t	1	2026-06-27 12:55:02.486	2026-06-27 13:00:46.211
46e73c79-4dd0-44ea-b22e-0e1ec88e6c1a	6bbef6fc-41ac-42c9-8fa5-f04afea05579	Protective material	\N	Fictional test item.	\N	set	group	2.00	10	26.00	t	2	2026-06-27 12:55:02.486	2026-06-27 13:00:46.213
c64ba20a-2385-4420-a7f2-1b8192bd0c43	459a150c-24de-4f90-ac0d-8d3d53bf4b37	Field tool set	\N	Fictional test item.	\N	set	individual	2.00	\N	25.00	t	1	2026-06-27 12:55:02.503	2026-06-27 13:00:46.231
71b911e9-410e-45ea-9d69-8113e3506bbd	459a150c-24de-4f90-ac0d-8d3d53bf4b37	Protective material	\N	Fictional test item.	\N	set	group	2.00	10	26.00	t	2	2026-06-27 12:55:02.503	2026-06-27 13:00:46.233
0bc6731f-b791-4946-92a3-e28e236825b8	459a150c-24de-4f90-ac0d-8d3d53bf4b37	Reference booklet	संदर्भ पुस्तिका	Fictional test item.	\N	copy	individual	1.00	\N	27.00	t	3	2026-06-27 12:55:02.503	2026-06-27 13:00:46.234
\.


--
-- Data for Name: toolkits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.toolkits (id, title_en, title_hi, summary_en, summary_hi, description_en, description_hi, programme_scheme_id, commodity_id, cover_media_id, slug, publication_state, public_visibility, publish_start_at, published_at, archived_at, highlight_type, highlight_start_at, highlight_end_at, display_order, show_on_homepage, created_by, updated_by, created_at, updated_at) FROM stdin;
22dbc69f-7dcd-480a-976c-30fda77691d3	Demo Ragi / Millets Starter Toolkit 3	डेमो टूलकिट 3	Fictional toolkit definition for distribution testing.	\N	Contains three reusable demonstration items.	\N	9867c29c-3ebf-41b0-98a8-221efcd86aca	b4873f7f-544f-42c3-855e-2810c7970236	cc4f583c-bd55-44e8-a408-9af5aa951372	demo-starter-toolkit-3	published	t	\N	2026-01-15 08:00:00	\N	important	2026-01-15 08:00:00	2027-01-15 08:00:00	3	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.493	2026-06-27 13:00:46.22
6bbef6fc-41ac-42c9-8fa5-f04afea05579	Demo Lac Starter Toolkit 1	डेमो टूलकिट 1	Fictional toolkit definition for distribution testing.	\N	Contains three reusable demonstration items.	\N	22fcb9e5-5190-4635-ab71-825976847e51	29abba96-aa2b-49b5-ba07-d75f2ce64932	cd1634aa-09ca-471d-a8b8-94968c0b7c9d	demo-starter-toolkit-1	published	t	\N	2026-01-15 08:00:00	\N	featured	2026-01-15 08:00:00	2027-01-15 08:00:00	1	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.48	2026-06-27 13:00:46.209
62e1cc34-89da-4d8d-b947-1f0fd0aeae1a	Demo Honey Starter Toolkit 2	\N	Fictional toolkit definition for distribution testing.	\N	Contains three reusable demonstration items.	\N	d89d19c1-31ed-488f-a792-88de2325f352	d5302db1-d57e-4d7c-85ad-bf3dbc6db6e5	e572b312-06c9-47e3-b150-4fd9c2b4e59c	demo-starter-toolkit-2	published	t	\N	2026-01-15 08:00:00	\N	latest	2026-01-15 08:00:00	2027-01-15 08:00:00	2	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.49	2026-06-27 13:00:46.215
b0c62d90-ac55-439d-9fe8-3c3eacd5ed25	Demo Sal Seed Starter Toolkit 4	\N	Fictional toolkit definition for distribution testing.	\N	Contains three reusable demonstration items.	\N	27a6b58a-a27a-4445-9ae4-1db0f6c6c223	cffc6a8c-ed36-4163-aab4-2417904ca859	eb3877af-dd51-4f3c-8b6b-57570d63c33c	demo-starter-toolkit-4	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	4	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.497	2026-06-27 13:00:46.224
459a150c-24de-4f90-ac0d-8d3d53bf4b37	Demo Karanj Starter Toolkit 5	डेमो टूलकिट 5	Fictional toolkit definition for distribution testing.	\N	Contains three reusable demonstration items.	\N	cf87cfda-4657-46ab-8dc3-5f2c288b52a1	df849f1b-b168-45a9-a1cb-40139f8d225d	18620944-e2bc-4e06-811d-f2c33d22ae84	demo-starter-toolkit-5	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	5	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.501	2026-06-27 13:00:46.23
c82ac9d2-d8c1-487e-8aa6-547c5f1a2508	Demo Tamarind Starter Toolkit 6	\N	Fictional toolkit definition for distribution testing.	\N	Contains three reusable demonstration items.	\N	edf6864c-2bd3-4a15-8a3c-7b23c3407be0	4f276af1-d981-4294-9f50-fbcdf2c979c2	bf9358c7-960b-4365-8b61-74f8788a7ad3	demo-starter-toolkit-6	unpublished	t	\N	\N	\N	\N	\N	\N	6	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.504	2026-06-27 13:00:46.235
1ee77721-7abc-4c19-8e61-dc8dc457bd3e	Demo Lac Starter Toolkit 7	डेमो टूलकिट 7	Fictional toolkit definition for distribution testing.	\N	Contains three reusable demonstration items.	\N	f2418002-8794-4079-a380-4dc3f810aafa	29abba96-aa2b-49b5-ba07-d75f2ce64932	84e59f6d-0311-404d-beaa-cf2172b47897	demo-starter-toolkit-7	published	t	2027-01-15 08:00:00	2026-01-15 08:00:00	\N	\N	\N	\N	7	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.507	2026-06-27 13:00:46.24
46218205-5ea4-47af-8df3-5a1bb8c26925	Demo Honey Starter Toolkit 8	\N	Fictional toolkit definition for distribution testing.	\N	Contains three reusable demonstration items.	\N	fbbc4562-43a7-4015-9d4d-31ec23f1fcd0	d5302db1-d57e-4d7c-85ad-bf3dbc6db6e5	4e8d90dc-7a13-4084-addf-b476da99f4e6	demo-starter-toolkit-8	published	f	\N	2026-01-15 08:00:00	\N	\N	\N	\N	8	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.511	2026-06-27 13:00:46.245
d252cd05-da84-42c0-8633-23bd535bc9dd	Demo Ragi / Millets Starter Toolkit 9	डेमो टूलकिट 9	Fictional toolkit definition for distribution testing.	\N	Contains three reusable demonstration items.	\N	d6dcdc56-84dc-4d87-990a-986e8ded46fb	b4873f7f-544f-42c3-855e-2810c7970236	3f24f935-ecf7-4c53-bd05-2d673cef6692	demo-starter-toolkit-9	draft	t	\N	\N	\N	\N	\N	\N	9	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.514	2026-06-27 13:00:46.25
6d60c8a4-809a-4bc7-bc2b-5b751ae87c3c	Demo Sal Seed Starter Toolkit 10	\N	Fictional toolkit definition for distribution testing.	\N	Contains three reusable demonstration items.	\N	e5427a51-68a7-4fbe-b618-3378361218a7	cffc6a8c-ed36-4163-aab4-2417904ca859	6853eb6c-ba01-4312-b751-b608641a94f5	demo-starter-toolkit-10	archived	f	\N	2026-01-15 08:00:00	2026-06-27 08:00:00	\N	\N	\N	10	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:02.518	2026-06-27 13:00:46.255
\.


--
-- Data for Name: training_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.training_types (id, name_en, name_hi, slug, is_active, display_order, created_at, updated_at) FROM stdin;
709c6b77-e169-474e-a370-2f2561fc3c8e	Skill Development	\N	skill-development	t	1	2026-06-27 12:55:01.917	2026-06-27 13:00:45.737
8420d28b-1cf4-4e30-9d75-1412e79ba349	Capacity Building	\N	capacity-building	t	2	2026-06-27 12:55:01.92	2026-06-27 13:00:45.739
2575a66d-6984-4be7-a068-b5d1cf215abf	Orientation	\N	orientation	t	3	2026-06-27 12:55:01.921	2026-06-27 13:00:45.739
5e1cc670-720c-4294-89fd-54bc49b2e7a7	Refresher	\N	refresher	t	4	2026-06-27 12:55:01.921	2026-06-27 13:00:45.74
43b6fabc-eae3-4525-b729-738070046dd5	Awareness	\N	awareness	t	5	2026-06-27 12:55:01.922	2026-06-27 13:00:45.741
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_roles (id, user_id, role_id) FROM stdin;
0e1d7aa1-aff7-448e-88d5-2e004d4dafaa	daee13c3-8dd0-404d-8bc3-12ef2206dc60	438bcfae-b0d4-4d8e-bce5-a686ddafdbf7
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, password_hash, full_name, preferred_language, is_active, last_login_at, created_at, updated_at) FROM stdin;
daee13c3-8dd0-404d-8bc3-12ef2206dc60	admin@sidhkofed.com	$2b$12$yXf8fuhTguWlj2WkY9LWw.hF4DxteNnPzuH8bsd3c6m9WqrbzCTcy	SIDHKOFED Super Admin	en	t	\N	2026-06-27 12:55:01.901	2026-06-27 13:00:45.726
\.


--
-- Data for Name: videos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.videos (id, title_en, title_hi, description_en, description_hi, youtube_id, youtube_url, thumbnail_media_id, slug, publication_state, public_visibility, publish_start_at, published_at, archived_at, highlight_type, highlight_start_at, highlight_end_at, display_order, show_on_homepage, created_by, updated_by, created_at, updated_at) FROM stdin;
871d32af-ec5a-473c-9987-daaeb965fdef	Demo Cooperative Video 7	डेमो वीडियो 7	Fictional YouTube-linked video metadata with a local thumbnail.	\N	demoVid0007	https://www.youtube.com/watch?v=demoVid0007	4c222680-3614-4531-8764-4c832b5f850b	demo-cooperative-video-7	published	t	2027-01-15 08:00:00	2026-01-15 08:00:00	\N	\N	\N	\N	7	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.409	2026-06-27 13:00:47.046
daca7ecd-177f-45d8-a0e4-586ca4400331	Demo Cooperative Video 8	\N	Fictional YouTube-linked video metadata with a local thumbnail.	\N	demoVid0008	https://www.youtube.com/watch?v=demoVid0008	ffdd7879-2936-44f4-9e85-590ef7f5c988	demo-cooperative-video-8	published	f	\N	2026-01-15 08:00:00	\N	\N	\N	\N	8	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.41	2026-06-27 13:00:47.047
ed5e9612-0643-4b2a-a3be-fe59c4502abe	Demo Cooperative Video 1	डेमो वीडियो 1	Fictional YouTube-linked video metadata with a local thumbnail.	\N	demoVid0001	https://www.youtube.com/watch?v=demoVid0001	eb3877af-dd51-4f3c-8b6b-57570d63c33c	demo-cooperative-video-1	published	t	\N	2026-01-15 08:00:00	\N	featured	2026-01-15 08:00:00	2027-01-15 08:00:00	1	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.395	2026-06-27 13:00:47.036
395da2d5-7174-4e62-bc45-aae4322c6676	Demo Cooperative Video 2	\N	Fictional YouTube-linked video metadata with a local thumbnail.	\N	demoVid0002	https://www.youtube.com/watch?v=demoVid0002	18620944-e2bc-4e06-811d-f2c33d22ae84	demo-cooperative-video-2	published	t	\N	2026-01-15 08:00:00	\N	latest	2026-01-15 08:00:00	2027-01-15 08:00:00	2	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.399	2026-06-27 13:00:47.039
fbd39bfb-e83a-45e4-8994-1e83cccb57e9	Demo Cooperative Video 3	डेमो वीडियो 3	Fictional YouTube-linked video metadata with a local thumbnail.	\N	demoVid0003	https://www.youtube.com/watch?v=demoVid0003	bf9358c7-960b-4365-8b61-74f8788a7ad3	demo-cooperative-video-3	published	t	\N	2026-01-15 08:00:00	\N	important	2026-01-15 08:00:00	2027-01-15 08:00:00	3	t	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.402	2026-06-27 13:00:47.04
594ab92c-ee97-4788-8ccb-a62a1ae37cea	Demo Cooperative Video 4	\N	Fictional YouTube-linked video metadata with a local thumbnail.	\N	demoVid0004	https://www.youtube.com/watch?v=demoVid0004	84e59f6d-0311-404d-beaa-cf2172b47897	demo-cooperative-video-4	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	4	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.403	2026-06-27 13:00:47.042
f435a8e9-dab0-4d9b-a3bd-3fd76a4250b6	Demo Cooperative Video 5	डेमो वीडियो 5	Fictional YouTube-linked video metadata with a local thumbnail.	\N	demoVid0005	https://www.youtube.com/watch?v=demoVid0005	4e8d90dc-7a13-4084-addf-b476da99f4e6	demo-cooperative-video-5	published	t	\N	2026-01-15 08:00:00	\N	\N	\N	\N	5	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.405	2026-06-27 13:00:47.043
223805a3-6d2b-45cb-84a3-ed9fd06ea2d2	Demo Cooperative Video 6	\N	Fictional YouTube-linked video metadata with a local thumbnail.	\N	demoVid0006	https://www.youtube.com/watch?v=demoVid0006	1556504e-8fcc-4269-9d95-c388657993f5	demo-cooperative-video-6	unpublished	t	\N	\N	\N	\N	\N	\N	6	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.407	2026-06-27 13:00:47.044
7ff97163-1c2d-45b5-9ac5-aff9a2b19d96	Demo Cooperative Video 9	डेमो वीडियो 9	Fictional YouTube-linked video metadata with a local thumbnail.	\N	demoVid0009	https://www.youtube.com/watch?v=demoVid0009	0968939c-7d8e-44fa-b682-e301befe10d4	demo-cooperative-video-9	draft	t	\N	\N	\N	\N	\N	\N	9	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.413	2026-06-27 13:00:47.049
3326df60-93c4-46d2-abcc-506c9fff472d	Demo Cooperative Video 10	\N	Fictional YouTube-linked video metadata with a local thumbnail.	\N	demoVid0010	https://www.youtube.com/watch?v=demoVid0010	e2c4def6-a80f-493c-ac02-f98a476978f6	demo-cooperative-video-10	archived	f	\N	2026-01-15 08:00:00	2026-06-27 08:00:00	\N	\N	\N	10	f	daee13c3-8dd0-404d-8bc3-12ef2206dc60	daee13c3-8dd0-404d-8bc3-12ef2206dc60	2026-06-27 12:55:03.415	2026-06-27 13:00:47.05
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: blocks blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blocks
    ADD CONSTRAINT blocks_pkey PRIMARY KEY (id);


--
-- Name: commodities commodities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commodities
    ADD CONSTRAINT commodities_pkey PRIMARY KEY (id);


--
-- Name: communication_types communication_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_types
    ADD CONSTRAINT communication_types_pkey PRIMARY KEY (id);


--
-- Name: dashboard_datasets dashboard_datasets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_datasets
    ADD CONSTRAINT dashboard_datasets_pkey PRIMARY KEY (id);


--
-- Name: dashboard_metrics dashboard_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_metrics
    ADD CONSTRAINT dashboard_metrics_pkey PRIMARY KEY (id);


--
-- Name: dashboard_reports dashboard_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_reports
    ADD CONSTRAINT dashboard_reports_pkey PRIMARY KEY (id);


--
-- Name: digital_services digital_services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digital_services
    ADD CONSTRAINT digital_services_pkey PRIMARY KEY (id);


--
-- Name: districts districts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.districts
    ADD CONSTRAINT districts_pkey PRIMARY KEY (id);


--
-- Name: document_commodities document_commodities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_commodities
    ADD CONSTRAINT document_commodities_pkey PRIMARY KEY (id);


--
-- Name: document_districts document_districts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_districts
    ADD CONSTRAINT document_districts_pkey PRIMARY KEY (id);


--
-- Name: document_institutions document_institutions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_institutions
    ADD CONSTRAINT document_institutions_pkey PRIMARY KEY (id);


--
-- Name: document_programmes document_programmes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_programmes
    ADD CONSTRAINT document_programmes_pkey PRIMARY KEY (id);


--
-- Name: document_tags document_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_tags
    ADD CONSTRAINT document_tags_pkey PRIMARY KEY (id);


--
-- Name: document_types document_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_types
    ADD CONSTRAINT document_types_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: enquiries enquiries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enquiries
    ADD CONSTRAINT enquiries_pkey PRIMARY KEY (id);


--
-- Name: enquiry_types enquiry_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enquiry_types
    ADD CONSTRAINT enquiry_types_pkey PRIMARY KEY (id);


--
-- Name: event_commodities event_commodities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_commodities
    ADD CONSTRAINT event_commodities_pkey PRIMARY KEY (id);


--
-- Name: event_documents event_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_documents
    ADD CONSTRAINT event_documents_pkey PRIMARY KEY (id);


--
-- Name: event_field_definitions event_field_definitions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_field_definitions
    ADD CONSTRAINT event_field_definitions_pkey PRIMARY KEY (id);


--
-- Name: event_galleries event_galleries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_galleries
    ADD CONSTRAINT event_galleries_pkey PRIMARY KEY (id);


--
-- Name: event_institutions event_institutions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_institutions
    ADD CONSTRAINT event_institutions_pkey PRIMARY KEY (id);


--
-- Name: event_news event_news_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_news
    ADD CONSTRAINT event_news_pkey PRIMARY KEY (id);


--
-- Name: event_programmes event_programmes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_programmes
    ADD CONSTRAINT event_programmes_pkey PRIMARY KEY (id);


--
-- Name: event_types event_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_types
    ADD CONSTRAINT event_types_pkey PRIMARY KEY (id);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: faq_categories faq_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faq_categories
    ADD CONSTRAINT faq_categories_pkey PRIMARY KEY (id);


--
-- Name: faqs faqs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faqs
    ADD CONSTRAINT faqs_pkey PRIMARY KEY (id);


--
-- Name: financial_years financial_years_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_years
    ADD CONSTRAINT financial_years_pkey PRIMARY KEY (id);


--
-- Name: galleries galleries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.galleries
    ADD CONSTRAINT galleries_pkey PRIMARY KEY (id);


--
-- Name: gallery_images gallery_images_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gallery_images
    ADD CONSTRAINT gallery_images_pkey PRIMARY KEY (id);


--
-- Name: institution_types institution_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institution_types
    ADD CONSTRAINT institution_types_pkey PRIMARY KEY (id);


--
-- Name: institutional_memberships institutional_memberships_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institutional_memberships
    ADD CONSTRAINT institutional_memberships_pkey PRIMARY KEY (id);


--
-- Name: institutions institutions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institutions
    ADD CONSTRAINT institutions_pkey PRIMARY KEY (id);


--
-- Name: knowledge_categories knowledge_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_categories
    ADD CONSTRAINT knowledge_categories_pkey PRIMARY KEY (id);


--
-- Name: media_assets media_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.media_assets
    ADD CONSTRAINT media_assets_pkey PRIMARY KEY (id);


--
-- Name: media_usages media_usages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.media_usages
    ADD CONSTRAINT media_usages_pkey PRIMARY KEY (id);


--
-- Name: menu_items menu_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_items
    ADD CONSTRAINT menu_items_pkey PRIMARY KEY (id);


--
-- Name: official_communications official_communications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.official_communications
    ADD CONSTRAINT official_communications_pkey PRIMARY KEY (id);


--
-- Name: pages pages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: procurement_update_types procurement_update_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.procurement_update_types
    ADD CONSTRAINT procurement_update_types_pkey PRIMARY KEY (id);


--
-- Name: procurement_updates procurement_updates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.procurement_updates
    ADD CONSTRAINT procurement_updates_pkey PRIMARY KEY (id);


--
-- Name: programme_commodities programme_commodities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programme_commodities
    ADD CONSTRAINT programme_commodities_pkey PRIMARY KEY (id);


--
-- Name: programme_permitted_training_types programme_permitted_training_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programme_permitted_training_types
    ADD CONSTRAINT programme_permitted_training_types_pkey PRIMARY KEY (id);


--
-- Name: programme_schemes programme_schemes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programme_schemes
    ADD CONSTRAINT programme_schemes_pkey PRIMARY KEY (id);


--
-- Name: reporting_periods reporting_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporting_periods
    ADD CONSTRAINT reporting_periods_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: tender_types tender_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tender_types
    ADD CONSTRAINT tender_types_pkey PRIMARY KEY (id);


--
-- Name: tenders tenders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenders
    ADD CONSTRAINT tenders_pkey PRIMARY KEY (id);


--
-- Name: toolkit_distribution_items toolkit_distribution_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.toolkit_distribution_items
    ADD CONSTRAINT toolkit_distribution_items_pkey PRIMARY KEY (id);


--
-- Name: toolkit_distribution_summaries toolkit_distribution_summaries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.toolkit_distribution_summaries
    ADD CONSTRAINT toolkit_distribution_summaries_pkey PRIMARY KEY (id);


--
-- Name: toolkit_items toolkit_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.toolkit_items
    ADD CONSTRAINT toolkit_items_pkey PRIMARY KEY (id);


--
-- Name: toolkits toolkits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.toolkits
    ADD CONSTRAINT toolkits_pkey PRIMARY KEY (id);


--
-- Name: training_types training_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.training_types
    ADD CONSTRAINT training_types_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: videos videos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.videos
    ADD CONSTRAINT videos_pkey PRIMARY KEY (id);


--
-- Name: audit_logs_action_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_action_idx ON public.audit_logs USING btree (action);


--
-- Name: audit_logs_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_created_at_idx ON public.audit_logs USING btree (created_at);


--
-- Name: audit_logs_module_record_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_module_record_id_idx ON public.audit_logs USING btree (module, record_id);


--
-- Name: audit_logs_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_user_id_idx ON public.audit_logs USING btree (user_id);


--
-- Name: blocks_district_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX blocks_district_id_idx ON public.blocks USING btree (district_id);


--
-- Name: blocks_district_id_name_en_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX blocks_district_id_name_en_key ON public.blocks USING btree (district_id, name_en);


--
-- Name: blocks_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX blocks_slug_key ON public.blocks USING btree (slug);


--
-- Name: commodities_name_en_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX commodities_name_en_key ON public.commodities USING btree (name_en);


--
-- Name: commodities_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX commodities_slug_key ON public.commodities USING btree (slug);


--
-- Name: communication_types_name_en_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX communication_types_name_en_key ON public.communication_types USING btree (name_en);


--
-- Name: communication_types_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX communication_types_slug_key ON public.communication_types USING btree (slug);


--
-- Name: dashboard_datasets_report_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dashboard_datasets_report_id_idx ON public.dashboard_datasets USING btree (report_id);


--
-- Name: dashboard_metrics_report_id_financial_year_id_reporting_peri_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dashboard_metrics_report_id_financial_year_id_reporting_peri_id ON public.dashboard_metrics USING btree (report_id, financial_year_id, reporting_period_id);


--
-- Name: dashboard_metrics_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX dashboard_metrics_unique ON public.dashboard_metrics USING btree (report_id, metric_key, financial_year_id, reporting_period_id) NULLS NOT DISTINCT;


--
-- Name: dashboard_reports_publication_state_public_visibility_archi_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dashboard_reports_publication_state_public_visibility_archi_idx ON public.dashboard_reports USING btree (publication_state, public_visibility, archived_at, published_at);


--
-- Name: dashboard_reports_report_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX dashboard_reports_report_key_key ON public.dashboard_reports USING btree (report_key);


--
-- Name: dashboard_reports_show_on_homepage_display_order_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dashboard_reports_show_on_homepage_display_order_idx ON public.dashboard_reports USING btree (show_on_homepage, display_order);


--
-- Name: digital_services_publication_state_public_visibility_archiv_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX digital_services_publication_state_public_visibility_archiv_idx ON public.digital_services USING btree (publication_state, public_visibility, archived_at, published_at);


--
-- Name: digital_services_show_on_homepage_display_order_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX digital_services_show_on_homepage_display_order_idx ON public.digital_services USING btree (show_on_homepage, display_order);


--
-- Name: digital_services_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX digital_services_slug_key ON public.digital_services USING btree (slug);


--
-- Name: districts_name_en_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX districts_name_en_key ON public.districts USING btree (name_en);


--
-- Name: districts_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX districts_slug_key ON public.districts USING btree (slug);


--
-- Name: document_commodities_commodity_id_document_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX document_commodities_commodity_id_document_id_idx ON public.document_commodities USING btree (commodity_id, document_id);


--
-- Name: document_commodities_document_id_commodity_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX document_commodities_document_id_commodity_id_key ON public.document_commodities USING btree (document_id, commodity_id);


--
-- Name: document_districts_district_id_document_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX document_districts_district_id_document_id_idx ON public.document_districts USING btree (district_id, document_id);


--
-- Name: document_districts_document_id_district_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX document_districts_document_id_district_id_key ON public.document_districts USING btree (document_id, district_id);


--
-- Name: document_institutions_document_id_institution_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX document_institutions_document_id_institution_id_key ON public.document_institutions USING btree (document_id, institution_id);


--
-- Name: document_institutions_institution_id_document_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX document_institutions_institution_id_document_id_idx ON public.document_institutions USING btree (institution_id, document_id);


--
-- Name: document_programmes_document_id_programme_scheme_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX document_programmes_document_id_programme_scheme_id_key ON public.document_programmes USING btree (document_id, programme_scheme_id);


--
-- Name: document_programmes_programme_scheme_id_document_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX document_programmes_programme_scheme_id_document_id_idx ON public.document_programmes USING btree (programme_scheme_id, document_id);


--
-- Name: document_tags_document_id_tag_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX document_tags_document_id_tag_id_key ON public.document_tags USING btree (document_id, tag_id);


--
-- Name: document_tags_tag_id_document_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX document_tags_tag_id_document_id_idx ON public.document_tags USING btree (tag_id, document_id);


--
-- Name: document_types_name_en_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX document_types_name_en_key ON public.document_types USING btree (name_en);


--
-- Name: document_types_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX document_types_slug_key ON public.document_types USING btree (slug);


--
-- Name: documents_document_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX documents_document_type_id_idx ON public.documents USING btree (document_type_id);


--
-- Name: documents_financial_year_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX documents_financial_year_id_idx ON public.documents USING btree (financial_year_id);


--
-- Name: documents_knowledge_category_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX documents_knowledge_category_id_idx ON public.documents USING btree (knowledge_category_id);


--
-- Name: documents_publication_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX documents_publication_date_idx ON public.documents USING btree (publication_date);


--
-- Name: documents_publication_state_public_visibility_archived_at_p_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX documents_publication_state_public_visibility_archived_at_p_idx ON public.documents USING btree (publication_state, public_visibility, archived_at, published_at);


--
-- Name: documents_publication_state_public_visibility_is_public_arc_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX documents_publication_state_public_visibility_is_public_arc_idx ON public.documents USING btree (publication_state, public_visibility, is_public, archived_at, publication_date);


--
-- Name: documents_pubstate_vis_ispublic_archived_publishstart_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX documents_pubstate_vis_ispublic_archived_publishstart_idx ON public.documents USING btree (publication_state, public_visibility, is_public, archived_at, publish_start_at);


--
-- Name: documents_search_vector_gin_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX documents_search_vector_gin_idx ON public.documents USING gin (search_vector);


--
-- Name: documents_show_in_knowledge_centre_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX documents_show_in_knowledge_centre_idx ON public.documents USING btree (show_in_knowledge_centre);


--
-- Name: documents_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX documents_slug_key ON public.documents USING btree (slug);


--
-- Name: enquiries_archived_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX enquiries_archived_at_idx ON public.enquiries USING btree (archived_at);


--
-- Name: enquiries_enquiry_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX enquiries_enquiry_type_id_idx ON public.enquiries USING btree (enquiry_type_id);


--
-- Name: enquiries_spam_state_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX enquiries_spam_state_idx ON public.enquiries USING btree (spam_state);


--
-- Name: enquiries_submitted_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX enquiries_submitted_at_idx ON public.enquiries USING btree (submitted_at DESC);


--
-- Name: enquiry_types_name_en_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX enquiry_types_name_en_key ON public.enquiry_types USING btree (name_en);


--
-- Name: enquiry_types_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX enquiry_types_slug_key ON public.enquiry_types USING btree (slug);


--
-- Name: event_commodities_commodity_id_event_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX event_commodities_commodity_id_event_id_idx ON public.event_commodities USING btree (commodity_id, event_id);


--
-- Name: event_commodities_event_id_commodity_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX event_commodities_event_id_commodity_id_key ON public.event_commodities USING btree (event_id, commodity_id);


--
-- Name: event_documents_document_id_event_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX event_documents_document_id_event_id_idx ON public.event_documents USING btree (document_id, event_id);


--
-- Name: event_documents_event_id_document_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX event_documents_event_id_document_id_key ON public.event_documents USING btree (event_id, document_id);


--
-- Name: event_field_definitions_event_type_id_field_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX event_field_definitions_event_type_id_field_key_key ON public.event_field_definitions USING btree (event_type_id, field_key);


--
-- Name: event_field_definitions_event_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX event_field_definitions_event_type_id_idx ON public.event_field_definitions USING btree (event_type_id);


--
-- Name: event_galleries_event_id_gallery_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX event_galleries_event_id_gallery_id_key ON public.event_galleries USING btree (event_id, gallery_id);


--
-- Name: event_galleries_gallery_id_event_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX event_galleries_gallery_id_event_id_idx ON public.event_galleries USING btree (gallery_id, event_id);


--
-- Name: event_institutions_event_id_institution_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX event_institutions_event_id_institution_id_key ON public.event_institutions USING btree (event_id, institution_id);


--
-- Name: event_institutions_institution_id_event_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX event_institutions_institution_id_event_id_idx ON public.event_institutions USING btree (institution_id, event_id);


--
-- Name: event_news_event_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX event_news_event_id_key ON public.event_news USING btree (event_id);


--
-- Name: event_news_news_published_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX event_news_news_published_at_idx ON public.event_news USING btree (news_published_at);


--
-- Name: event_news_publication_state_public_visibility_archived_at__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX event_news_publication_state_public_visibility_archived_at__idx ON public.event_news USING btree (publication_state, public_visibility, archived_at, published_at);


--
-- Name: event_news_pubstate_vis_archived_publishstart_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX event_news_pubstate_vis_archived_publishstart_idx ON public.event_news USING btree (publication_state, public_visibility, archived_at, publish_start_at);


--
-- Name: event_news_search_vector_gin_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX event_news_search_vector_gin_idx ON public.event_news USING gin (search_vector);


--
-- Name: event_news_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX event_news_slug_key ON public.event_news USING btree (slug);


--
-- Name: event_programmes_event_id_programme_scheme_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX event_programmes_event_id_programme_scheme_id_key ON public.event_programmes USING btree (event_id, programme_scheme_id);


--
-- Name: event_programmes_programme_scheme_id_event_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX event_programmes_programme_scheme_id_event_id_idx ON public.event_programmes USING btree (programme_scheme_id, event_id);


--
-- Name: event_types_name_en_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX event_types_name_en_key ON public.event_types USING btree (name_en);


--
-- Name: event_types_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX event_types_slug_key ON public.event_types USING btree (slug);


--
-- Name: events_district_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX events_district_id_idx ON public.events USING btree (district_id);


--
-- Name: events_event_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX events_event_status_idx ON public.events USING btree (event_status);


--
-- Name: events_event_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX events_event_type_id_idx ON public.events USING btree (event_type_id);


--
-- Name: events_publication_state_public_visibility_archived_at_publ_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX events_publication_state_public_visibility_archived_at_publ_idx ON public.events USING btree (publication_state, public_visibility, archived_at, published_at);


--
-- Name: events_pubstate_vis_archived_publishstart_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX events_pubstate_vis_archived_publishstart_idx ON public.events USING btree (publication_state, public_visibility, archived_at, publish_start_at);


--
-- Name: events_search_vector_gin_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX events_search_vector_gin_idx ON public.events USING gin (search_vector);


--
-- Name: events_show_on_homepage_display_order_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX events_show_on_homepage_display_order_idx ON public.events USING btree (show_on_homepage, display_order);


--
-- Name: events_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX events_slug_key ON public.events USING btree (slug);


--
-- Name: events_start_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX events_start_date_idx ON public.events USING btree (start_date);


--
-- Name: faq_categories_name_en_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX faq_categories_name_en_key ON public.faq_categories USING btree (name_en);


--
-- Name: faq_categories_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX faq_categories_slug_key ON public.faq_categories USING btree (slug);


--
-- Name: faqs_faq_category_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX faqs_faq_category_id_idx ON public.faqs USING btree (faq_category_id);


--
-- Name: faqs_publication_state_public_visibility_archived_at_publis_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX faqs_publication_state_public_visibility_archived_at_publis_idx ON public.faqs USING btree (publication_state, public_visibility, archived_at, published_at);


--
-- Name: faqs_show_on_homepage_display_order_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX faqs_show_on_homepage_display_order_idx ON public.faqs USING btree (show_on_homepage, display_order);


--
-- Name: faqs_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX faqs_slug_key ON public.faqs USING btree (slug);


--
-- Name: financial_years_label_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX financial_years_label_key ON public.financial_years USING btree (label);


--
-- Name: galleries_publication_state_public_visibility_archived_at_p_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX galleries_publication_state_public_visibility_archived_at_p_idx ON public.galleries USING btree (publication_state, public_visibility, archived_at, published_at);


--
-- Name: galleries_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX galleries_slug_key ON public.galleries USING btree (slug);


--
-- Name: gallery_images_gallery_id_media_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX gallery_images_gallery_id_media_id_key ON public.gallery_images USING btree (gallery_id, media_id);


--
-- Name: institution_types_name_en_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX institution_types_name_en_key ON public.institution_types USING btree (name_en);


--
-- Name: institution_types_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX institution_types_slug_key ON public.institution_types USING btree (slug);


--
-- Name: institutional_memberships_business_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX institutional_memberships_business_key ON public.institutional_memberships USING btree (institution_id, membership_level, membership_type, district_union_id, reporting_period_id) NULLS NOT DISTINCT;


--
-- Name: institutional_memberships_district_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX institutional_memberships_district_id_idx ON public.institutional_memberships USING btree (district_id);


--
-- Name: institutional_memberships_institution_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX institutional_memberships_institution_id_idx ON public.institutional_memberships USING btree (institution_id);


--
-- Name: institutional_memberships_membership_level_membership_type__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX institutional_memberships_membership_level_membership_type__idx ON public.institutional_memberships USING btree (membership_level, membership_type, reporting_period_id);


--
-- Name: institutional_memberships_membership_number_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX institutional_memberships_membership_number_key ON public.institutional_memberships USING btree (membership_number);


--
-- Name: institutional_memberships_publication_state_public_visibili_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX institutional_memberships_publication_state_public_visibili_idx ON public.institutional_memberships USING btree (publication_state, public_visibility, archived_at, published_at);


--
-- Name: institutional_memberships_show_on_homepage_display_order_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX institutional_memberships_show_on_homepage_display_order_idx ON public.institutional_memberships USING btree (show_on_homepage, display_order);


--
-- Name: institutional_memberships_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX institutional_memberships_slug_key ON public.institutional_memberships USING btree (slug);


--
-- Name: institutions_district_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX institutions_district_id_idx ON public.institutions USING btree (district_id);


--
-- Name: institutions_institution_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX institutions_institution_type_id_idx ON public.institutions USING btree (institution_type_id);


--
-- Name: institutions_publication_state_public_visibility_archived_a_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX institutions_publication_state_public_visibility_archived_a_idx ON public.institutions USING btree (publication_state, public_visibility, archived_at, published_at);


--
-- Name: institutions_show_on_homepage_display_order_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX institutions_show_on_homepage_display_order_idx ON public.institutions USING btree (show_on_homepage, display_order);


--
-- Name: institutions_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX institutions_slug_key ON public.institutions USING btree (slug);


--
-- Name: knowledge_categories_name_en_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX knowledge_categories_name_en_key ON public.knowledge_categories USING btree (name_en);


--
-- Name: knowledge_categories_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX knowledge_categories_slug_key ON public.knowledge_categories USING btree (slug);


--
-- Name: media_assets_archived_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX media_assets_archived_at_idx ON public.media_assets USING btree (archived_at);


--
-- Name: media_assets_checksum_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX media_assets_checksum_idx ON public.media_assets USING btree (checksum);


--
-- Name: media_assets_mime_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX media_assets_mime_type_idx ON public.media_assets USING btree (mime_type);


--
-- Name: media_assets_storage_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX media_assets_storage_key_key ON public.media_assets USING btree (storage_key);


--
-- Name: media_usages_entity_type_entity_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX media_usages_entity_type_entity_id_idx ON public.media_usages USING btree (entity_type, entity_id);


--
-- Name: media_usages_media_id_entity_type_entity_id_field_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX media_usages_media_id_entity_type_entity_id_field_key ON public.media_usages USING btree (media_id, entity_type, entity_id, field);


--
-- Name: menu_items_location_display_order_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX menu_items_location_display_order_idx ON public.menu_items USING btree (location, display_order);


--
-- Name: menu_items_parent_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX menu_items_parent_id_idx ON public.menu_items USING btree (parent_id);


--
-- Name: official_communications_communication_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX official_communications_communication_type_id_idx ON public.official_communications USING btree (communication_type_id);


--
-- Name: official_communications_issue_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX official_communications_issue_date_idx ON public.official_communications USING btree (issue_date);


--
-- Name: official_communications_publication_state_public_visibility_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX official_communications_publication_state_public_visibility_idx ON public.official_communications USING btree (publication_state, public_visibility, archived_at, published_at);


--
-- Name: official_communications_search_vector_gin_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX official_communications_search_vector_gin_idx ON public.official_communications USING gin (search_vector);


--
-- Name: official_communications_show_on_homepage_display_order_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX official_communications_show_on_homepage_display_order_idx ON public.official_communications USING btree (show_on_homepage, display_order);


--
-- Name: official_communications_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX official_communications_slug_key ON public.official_communications USING btree (slug);


--
-- Name: pages_publication_state_public_visibility_archived_at_publi_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pages_publication_state_public_visibility_archived_at_publi_idx ON public.pages USING btree (publication_state, public_visibility, archived_at, published_at);


--
-- Name: pages_search_vector_gin_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pages_search_vector_gin_idx ON public.pages USING gin (search_vector);


--
-- Name: pages_show_on_homepage_display_order_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pages_show_on_homepage_display_order_idx ON public.pages USING btree (show_on_homepage, display_order);


--
-- Name: pages_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pages_slug_key ON public.pages USING btree (slug);


--
-- Name: permissions_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX permissions_key_key ON public.permissions USING btree (key);


--
-- Name: permissions_module_action_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX permissions_module_action_key ON public.permissions USING btree (module, action);


--
-- Name: procurement_update_types_name_en_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX procurement_update_types_name_en_key ON public.procurement_update_types USING btree (name_en);


--
-- Name: procurement_update_types_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX procurement_update_types_slug_key ON public.procurement_update_types USING btree (slug);


--
-- Name: procurement_updates_commodity_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX procurement_updates_commodity_id_idx ON public.procurement_updates USING btree (commodity_id);


--
-- Name: procurement_updates_district_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX procurement_updates_district_id_idx ON public.procurement_updates USING btree (district_id);


--
-- Name: procurement_updates_effective_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX procurement_updates_effective_date_idx ON public.procurement_updates USING btree (effective_date);


--
-- Name: procurement_updates_procurement_update_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX procurement_updates_procurement_update_type_id_idx ON public.procurement_updates USING btree (procurement_update_type_id);


--
-- Name: procurement_updates_publication_state_public_visibility_arc_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX procurement_updates_publication_state_public_visibility_arc_idx ON public.procurement_updates USING btree (publication_state, public_visibility, archived_at, published_at);


--
-- Name: procurement_updates_search_vector_gin_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX procurement_updates_search_vector_gin_idx ON public.procurement_updates USING gin (search_vector);


--
-- Name: procurement_updates_show_on_homepage_display_order_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX procurement_updates_show_on_homepage_display_order_idx ON public.procurement_updates USING btree (show_on_homepage, display_order);


--
-- Name: procurement_updates_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX procurement_updates_slug_key ON public.procurement_updates USING btree (slug);


--
-- Name: programme_commodities_commodity_id_programme_scheme_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX programme_commodities_commodity_id_programme_scheme_id_idx ON public.programme_commodities USING btree (commodity_id, programme_scheme_id);


--
-- Name: programme_commodities_programme_scheme_id_commodity_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX programme_commodities_programme_scheme_id_commodity_id_key ON public.programme_commodities USING btree (programme_scheme_id, commodity_id);


--
-- Name: programme_permitted_training_types_programme_scheme_id_trai_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX programme_permitted_training_types_programme_scheme_id_trai_key ON public.programme_permitted_training_types USING btree (programme_scheme_id, training_type_id);


--
-- Name: programme_permitted_training_types_training_type_id_program_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX programme_permitted_training_types_training_type_id_program_idx ON public.programme_permitted_training_types USING btree (training_type_id, programme_scheme_id);


--
-- Name: programme_schemes_publication_state_public_visibility_archi_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX programme_schemes_publication_state_public_visibility_archi_idx ON public.programme_schemes USING btree (publication_state, public_visibility, archived_at, published_at);


--
-- Name: programme_schemes_search_vector_gin_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX programme_schemes_search_vector_gin_idx ON public.programme_schemes USING gin (search_vector);


--
-- Name: programme_schemes_show_on_homepage_display_order_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX programme_schemes_show_on_homepage_display_order_idx ON public.programme_schemes USING btree (show_on_homepage, display_order);


--
-- Name: programme_schemes_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX programme_schemes_slug_key ON public.programme_schemes USING btree (slug);


--
-- Name: reporting_periods_financial_year_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reporting_periods_financial_year_id_idx ON public.reporting_periods USING btree (financial_year_id);


--
-- Name: reporting_periods_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX reporting_periods_slug_key ON public.reporting_periods USING btree (slug);


--
-- Name: role_permissions_role_id_permission_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX role_permissions_role_id_permission_id_key ON public.role_permissions USING btree (role_id, permission_id);


--
-- Name: roles_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX roles_key_key ON public.roles USING btree (key);


--
-- Name: settings_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX settings_key_key ON public.settings USING btree (key);


--
-- Name: tags_name_en_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX tags_name_en_key ON public.tags USING btree (name_en);


--
-- Name: tags_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX tags_slug_key ON public.tags USING btree (slug);


--
-- Name: tender_types_name_en_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX tender_types_name_en_key ON public.tender_types USING btree (name_en);


--
-- Name: tender_types_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX tender_types_slug_key ON public.tender_types USING btree (slug);


--
-- Name: tenders_publication_state_public_visibility_archived_at_pub_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tenders_publication_state_public_visibility_archived_at_pub_idx ON public.tenders USING btree (publication_state, public_visibility, archived_at, published_at);


--
-- Name: tenders_search_vector_gin_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tenders_search_vector_gin_idx ON public.tenders USING gin (search_vector);


--
-- Name: tenders_show_on_homepage_display_order_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tenders_show_on_homepage_display_order_idx ON public.tenders USING btree (show_on_homepage, display_order);


--
-- Name: tenders_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX tenders_slug_key ON public.tenders USING btree (slug);


--
-- Name: tenders_submission_deadline_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tenders_submission_deadline_idx ON public.tenders USING btree (submission_deadline);


--
-- Name: tenders_tender_number_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX tenders_tender_number_key ON public.tenders USING btree (tender_number);


--
-- Name: tenders_tender_type_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tenders_tender_type_id_idx ON public.tenders USING btree (tender_type_id);


--
-- Name: toolkit_distribution_items_summary_id_item_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX toolkit_distribution_items_summary_id_item_id_key ON public.toolkit_distribution_items USING btree (toolkit_distribution_summary_id, toolkit_item_id);


--
-- Name: toolkit_distribution_items_toolkit_item_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX toolkit_distribution_items_toolkit_item_id_idx ON public.toolkit_distribution_items USING btree (toolkit_item_id);


--
-- Name: toolkit_distribution_summaries_event_id_toolkit_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX toolkit_distribution_summaries_event_id_toolkit_id_key ON public.toolkit_distribution_summaries USING btree (event_id, toolkit_id);


--
-- Name: toolkit_distribution_summaries_toolkit_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX toolkit_distribution_summaries_toolkit_id_idx ON public.toolkit_distribution_summaries USING btree (toolkit_id);


--
-- Name: toolkit_items_toolkit_id_display_order_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX toolkit_items_toolkit_id_display_order_idx ON public.toolkit_items USING btree (toolkit_id, display_order);


--
-- Name: toolkits_pubstate_vis_archived_published_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX toolkits_pubstate_vis_archived_published_idx ON public.toolkits USING btree (publication_state, public_visibility, archived_at, published_at);


--
-- Name: toolkits_show_on_homepage_display_order_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX toolkits_show_on_homepage_display_order_idx ON public.toolkits USING btree (show_on_homepage, display_order);


--
-- Name: toolkits_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX toolkits_slug_key ON public.toolkits USING btree (slug);


--
-- Name: training_types_name_en_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX training_types_name_en_key ON public.training_types USING btree (name_en);


--
-- Name: training_types_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX training_types_slug_key ON public.training_types USING btree (slug);


--
-- Name: user_roles_user_id_role_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX user_roles_user_id_role_id_key ON public.user_roles USING btree (user_id, role_id);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: videos_publication_state_public_visibility_archived_at_publ_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX videos_publication_state_public_visibility_archived_at_publ_idx ON public.videos USING btree (publication_state, public_visibility, archived_at, published_at);


--
-- Name: videos_show_on_homepage_display_order_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX videos_show_on_homepage_display_order_idx ON public.videos USING btree (show_on_homepage, display_order);


--
-- Name: videos_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX videos_slug_key ON public.videos USING btree (slug);


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: blocks blocks_district_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blocks
    ADD CONSTRAINT blocks_district_id_fkey FOREIGN KEY (district_id) REFERENCES public.districts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: commodities commodities_icon_media_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commodities
    ADD CONSTRAINT commodities_icon_media_id_fkey FOREIGN KEY (icon_media_id) REFERENCES public.media_assets(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: dashboard_datasets dashboard_datasets_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_datasets
    ADD CONSTRAINT dashboard_datasets_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: dashboard_datasets dashboard_datasets_financial_year_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_datasets
    ADD CONSTRAINT dashboard_datasets_financial_year_id_fkey FOREIGN KEY (financial_year_id) REFERENCES public.financial_years(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: dashboard_datasets dashboard_datasets_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_datasets
    ADD CONSTRAINT dashboard_datasets_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.dashboard_reports(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: dashboard_datasets dashboard_datasets_reporting_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_datasets
    ADD CONSTRAINT dashboard_datasets_reporting_period_id_fkey FOREIGN KEY (reporting_period_id) REFERENCES public.reporting_periods(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: dashboard_datasets dashboard_datasets_source_file_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_datasets
    ADD CONSTRAINT dashboard_datasets_source_file_asset_id_fkey FOREIGN KEY (source_file_asset_id) REFERENCES public.media_assets(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: dashboard_metrics dashboard_metrics_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_metrics
    ADD CONSTRAINT dashboard_metrics_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: dashboard_metrics dashboard_metrics_dataset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_metrics
    ADD CONSTRAINT dashboard_metrics_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES public.dashboard_datasets(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: dashboard_metrics dashboard_metrics_financial_year_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_metrics
    ADD CONSTRAINT dashboard_metrics_financial_year_id_fkey FOREIGN KEY (financial_year_id) REFERENCES public.financial_years(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: dashboard_metrics dashboard_metrics_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_metrics
    ADD CONSTRAINT dashboard_metrics_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.dashboard_reports(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dashboard_metrics dashboard_metrics_reporting_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_metrics
    ADD CONSTRAINT dashboard_metrics_reporting_period_id_fkey FOREIGN KEY (reporting_period_id) REFERENCES public.reporting_periods(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: dashboard_metrics dashboard_metrics_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_metrics
    ADD CONSTRAINT dashboard_metrics_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: dashboard_reports dashboard_reports_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_reports
    ADD CONSTRAINT dashboard_reports_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: dashboard_reports dashboard_reports_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_reports
    ADD CONSTRAINT dashboard_reports_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: digital_services digital_services_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digital_services
    ADD CONSTRAINT digital_services_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: digital_services digital_services_icon_media_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digital_services
    ADD CONSTRAINT digital_services_icon_media_id_fkey FOREIGN KEY (icon_media_id) REFERENCES public.media_assets(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: digital_services digital_services_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digital_services
    ADD CONSTRAINT digital_services_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: document_commodities document_commodities_commodity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_commodities
    ADD CONSTRAINT document_commodities_commodity_id_fkey FOREIGN KEY (commodity_id) REFERENCES public.commodities(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: document_commodities document_commodities_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_commodities
    ADD CONSTRAINT document_commodities_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: document_districts document_districts_district_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_districts
    ADD CONSTRAINT document_districts_district_id_fkey FOREIGN KEY (district_id) REFERENCES public.districts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: document_districts document_districts_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_districts
    ADD CONSTRAINT document_districts_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: document_institutions document_institutions_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_institutions
    ADD CONSTRAINT document_institutions_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: document_institutions document_institutions_institution_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_institutions
    ADD CONSTRAINT document_institutions_institution_id_fkey FOREIGN KEY (institution_id) REFERENCES public.institutions(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: document_programmes document_programmes_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_programmes
    ADD CONSTRAINT document_programmes_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: document_programmes document_programmes_programme_scheme_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_programmes
    ADD CONSTRAINT document_programmes_programme_scheme_id_fkey FOREIGN KEY (programme_scheme_id) REFERENCES public.programme_schemes(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: document_tags document_tags_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_tags
    ADD CONSTRAINT document_tags_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: document_tags document_tags_tag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_tags
    ADD CONSTRAINT document_tags_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES public.tags(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: documents documents_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: documents documents_document_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_document_type_id_fkey FOREIGN KEY (document_type_id) REFERENCES public.document_types(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: documents documents_file_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_file_asset_id_fkey FOREIGN KEY (file_asset_id) REFERENCES public.media_assets(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: documents documents_financial_year_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_financial_year_id_fkey FOREIGN KEY (financial_year_id) REFERENCES public.financial_years(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: documents documents_knowledge_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_knowledge_category_id_fkey FOREIGN KEY (knowledge_category_id) REFERENCES public.knowledge_categories(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: documents documents_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: enquiries enquiries_commodity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enquiries
    ADD CONSTRAINT enquiries_commodity_id_fkey FOREIGN KEY (commodity_id) REFERENCES public.commodities(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: enquiries enquiries_enquiry_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enquiries
    ADD CONSTRAINT enquiries_enquiry_type_id_fkey FOREIGN KEY (enquiry_type_id) REFERENCES public.enquiry_types(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: enquiries enquiries_programme_scheme_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enquiries
    ADD CONSTRAINT enquiries_programme_scheme_id_fkey FOREIGN KEY (programme_scheme_id) REFERENCES public.programme_schemes(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: event_commodities event_commodities_commodity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_commodities
    ADD CONSTRAINT event_commodities_commodity_id_fkey FOREIGN KEY (commodity_id) REFERENCES public.commodities(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: event_commodities event_commodities_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_commodities
    ADD CONSTRAINT event_commodities_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: event_documents event_documents_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_documents
    ADD CONSTRAINT event_documents_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: event_documents event_documents_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_documents
    ADD CONSTRAINT event_documents_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: event_field_definitions event_field_definitions_event_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_field_definitions
    ADD CONSTRAINT event_field_definitions_event_type_id_fkey FOREIGN KEY (event_type_id) REFERENCES public.event_types(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: event_galleries event_galleries_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_galleries
    ADD CONSTRAINT event_galleries_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: event_galleries event_galleries_gallery_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_galleries
    ADD CONSTRAINT event_galleries_gallery_id_fkey FOREIGN KEY (gallery_id) REFERENCES public.galleries(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: event_institutions event_institutions_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_institutions
    ADD CONSTRAINT event_institutions_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: event_institutions event_institutions_institution_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_institutions
    ADD CONSTRAINT event_institutions_institution_id_fkey FOREIGN KEY (institution_id) REFERENCES public.institutions(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: event_news event_news_cover_media_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_news
    ADD CONSTRAINT event_news_cover_media_id_fkey FOREIGN KEY (cover_media_id) REFERENCES public.media_assets(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: event_news event_news_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_news
    ADD CONSTRAINT event_news_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: event_news event_news_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_news
    ADD CONSTRAINT event_news_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: event_news event_news_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_news
    ADD CONSTRAINT event_news_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: event_programmes event_programmes_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_programmes
    ADD CONSTRAINT event_programmes_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: event_programmes event_programmes_programme_scheme_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_programmes
    ADD CONSTRAINT event_programmes_programme_scheme_id_fkey FOREIGN KEY (programme_scheme_id) REFERENCES public.programme_schemes(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: events events_block_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_block_id_fkey FOREIGN KEY (block_id) REFERENCES public.blocks(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: events events_cover_media_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_cover_media_id_fkey FOREIGN KEY (cover_media_id) REFERENCES public.media_assets(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: events events_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: events events_district_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_district_id_fkey FOREIGN KEY (district_id) REFERENCES public.districts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: events events_event_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_event_type_id_fkey FOREIGN KEY (event_type_id) REFERENCES public.event_types(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: events events_training_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_training_type_id_fkey FOREIGN KEY (training_type_id) REFERENCES public.training_types(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: events events_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: faqs faqs_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faqs
    ADD CONSTRAINT faqs_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: faqs faqs_faq_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faqs
    ADD CONSTRAINT faqs_faq_category_id_fkey FOREIGN KEY (faq_category_id) REFERENCES public.faq_categories(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: faqs faqs_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faqs
    ADD CONSTRAINT faqs_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: galleries galleries_cover_media_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.galleries
    ADD CONSTRAINT galleries_cover_media_id_fkey FOREIGN KEY (cover_media_id) REFERENCES public.media_assets(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: galleries galleries_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.galleries
    ADD CONSTRAINT galleries_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: galleries galleries_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.galleries
    ADD CONSTRAINT galleries_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: gallery_images gallery_images_gallery_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gallery_images
    ADD CONSTRAINT gallery_images_gallery_id_fkey FOREIGN KEY (gallery_id) REFERENCES public.galleries(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: gallery_images gallery_images_media_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gallery_images
    ADD CONSTRAINT gallery_images_media_id_fkey FOREIGN KEY (media_id) REFERENCES public.media_assets(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: institutional_memberships institutional_memberships_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institutional_memberships
    ADD CONSTRAINT institutional_memberships_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: institutional_memberships institutional_memberships_district_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institutional_memberships
    ADD CONSTRAINT institutional_memberships_district_id_fkey FOREIGN KEY (district_id) REFERENCES public.districts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: institutional_memberships institutional_memberships_district_union_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institutional_memberships
    ADD CONSTRAINT institutional_memberships_district_union_id_fkey FOREIGN KEY (district_union_id) REFERENCES public.institutions(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: institutional_memberships institutional_memberships_institution_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institutional_memberships
    ADD CONSTRAINT institutional_memberships_institution_id_fkey FOREIGN KEY (institution_id) REFERENCES public.institutions(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: institutional_memberships institutional_memberships_reporting_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institutional_memberships
    ADD CONSTRAINT institutional_memberships_reporting_period_id_fkey FOREIGN KEY (reporting_period_id) REFERENCES public.reporting_periods(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: institutional_memberships institutional_memberships_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institutional_memberships
    ADD CONSTRAINT institutional_memberships_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: institutions institutions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institutions
    ADD CONSTRAINT institutions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: institutions institutions_district_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institutions
    ADD CONSTRAINT institutions_district_id_fkey FOREIGN KEY (district_id) REFERENCES public.districts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: institutions institutions_institution_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institutions
    ADD CONSTRAINT institutions_institution_type_id_fkey FOREIGN KEY (institution_type_id) REFERENCES public.institution_types(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: institutions institutions_logo_media_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institutions
    ADD CONSTRAINT institutions_logo_media_id_fkey FOREIGN KEY (logo_media_id) REFERENCES public.media_assets(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: institutions institutions_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institutions
    ADD CONSTRAINT institutions_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: media_assets media_assets_replaced_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.media_assets
    ADD CONSTRAINT media_assets_replaced_by_id_fkey FOREIGN KEY (replaced_by_id) REFERENCES public.media_assets(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: media_assets media_assets_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.media_assets
    ADD CONSTRAINT media_assets_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: media_usages media_usages_media_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.media_usages
    ADD CONSTRAINT media_usages_media_id_fkey FOREIGN KEY (media_id) REFERENCES public.media_assets(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: menu_items menu_items_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_items
    ADD CONSTRAINT menu_items_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: menu_items menu_items_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_items
    ADD CONSTRAINT menu_items_page_id_fkey FOREIGN KEY (page_id) REFERENCES public.pages(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: menu_items menu_items_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_items
    ADD CONSTRAINT menu_items_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.menu_items(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: menu_items menu_items_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_items
    ADD CONSTRAINT menu_items_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: official_communications official_communications_communication_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.official_communications
    ADD CONSTRAINT official_communications_communication_type_id_fkey FOREIGN KEY (communication_type_id) REFERENCES public.communication_types(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: official_communications official_communications_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.official_communications
    ADD CONSTRAINT official_communications_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: official_communications official_communications_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.official_communications
    ADD CONSTRAINT official_communications_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: official_communications official_communications_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.official_communications
    ADD CONSTRAINT official_communications_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: pages pages_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: pages pages_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: procurement_updates procurement_updates_block_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.procurement_updates
    ADD CONSTRAINT procurement_updates_block_id_fkey FOREIGN KEY (block_id) REFERENCES public.blocks(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: procurement_updates procurement_updates_commodity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.procurement_updates
    ADD CONSTRAINT procurement_updates_commodity_id_fkey FOREIGN KEY (commodity_id) REFERENCES public.commodities(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: procurement_updates procurement_updates_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.procurement_updates
    ADD CONSTRAINT procurement_updates_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: procurement_updates procurement_updates_district_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.procurement_updates
    ADD CONSTRAINT procurement_updates_district_id_fkey FOREIGN KEY (district_id) REFERENCES public.districts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: procurement_updates procurement_updates_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.procurement_updates
    ADD CONSTRAINT procurement_updates_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: procurement_updates procurement_updates_procurement_update_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.procurement_updates
    ADD CONSTRAINT procurement_updates_procurement_update_type_id_fkey FOREIGN KEY (procurement_update_type_id) REFERENCES public.procurement_update_types(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: procurement_updates procurement_updates_programme_scheme_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.procurement_updates
    ADD CONSTRAINT procurement_updates_programme_scheme_id_fkey FOREIGN KEY (programme_scheme_id) REFERENCES public.programme_schemes(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: procurement_updates procurement_updates_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.procurement_updates
    ADD CONSTRAINT procurement_updates_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: programme_commodities programme_commodities_commodity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programme_commodities
    ADD CONSTRAINT programme_commodities_commodity_id_fkey FOREIGN KEY (commodity_id) REFERENCES public.commodities(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: programme_commodities programme_commodities_programme_scheme_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programme_commodities
    ADD CONSTRAINT programme_commodities_programme_scheme_id_fkey FOREIGN KEY (programme_scheme_id) REFERENCES public.programme_schemes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: programme_permitted_training_types programme_permitted_training_types_programme_scheme_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programme_permitted_training_types
    ADD CONSTRAINT programme_permitted_training_types_programme_scheme_id_fkey FOREIGN KEY (programme_scheme_id) REFERENCES public.programme_schemes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: programme_permitted_training_types programme_permitted_training_types_training_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programme_permitted_training_types
    ADD CONSTRAINT programme_permitted_training_types_training_type_id_fkey FOREIGN KEY (training_type_id) REFERENCES public.training_types(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: programme_schemes programme_schemes_cover_media_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programme_schemes
    ADD CONSTRAINT programme_schemes_cover_media_id_fkey FOREIGN KEY (cover_media_id) REFERENCES public.media_assets(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: programme_schemes programme_schemes_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programme_schemes
    ADD CONSTRAINT programme_schemes_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: programme_schemes programme_schemes_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.programme_schemes
    ADD CONSTRAINT programme_schemes_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: reporting_periods reporting_periods_financial_year_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporting_periods
    ADD CONSTRAINT reporting_periods_financial_year_id_fkey FOREIGN KEY (financial_year_id) REFERENCES public.financial_years(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: role_permissions role_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: settings settings_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: tenders tenders_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenders
    ADD CONSTRAINT tenders_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: tenders tenders_tender_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenders
    ADD CONSTRAINT tenders_tender_type_id_fkey FOREIGN KEY (tender_type_id) REFERENCES public.tender_types(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: tenders tenders_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenders
    ADD CONSTRAINT tenders_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: toolkit_distribution_items toolkit_distribution_items_toolkit_distribution_summary_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.toolkit_distribution_items
    ADD CONSTRAINT toolkit_distribution_items_toolkit_distribution_summary_id_fkey FOREIGN KEY (toolkit_distribution_summary_id) REFERENCES public.toolkit_distribution_summaries(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: toolkit_distribution_items toolkit_distribution_items_toolkit_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.toolkit_distribution_items
    ADD CONSTRAINT toolkit_distribution_items_toolkit_item_id_fkey FOREIGN KEY (toolkit_item_id) REFERENCES public.toolkit_items(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: toolkit_distribution_summaries toolkit_distribution_summaries_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.toolkit_distribution_summaries
    ADD CONSTRAINT toolkit_distribution_summaries_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: toolkit_distribution_summaries toolkit_distribution_summaries_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.toolkit_distribution_summaries
    ADD CONSTRAINT toolkit_distribution_summaries_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: toolkit_distribution_summaries toolkit_distribution_summaries_toolkit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.toolkit_distribution_summaries
    ADD CONSTRAINT toolkit_distribution_summaries_toolkit_id_fkey FOREIGN KEY (toolkit_id) REFERENCES public.toolkits(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: toolkit_distribution_summaries toolkit_distribution_summaries_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.toolkit_distribution_summaries
    ADD CONSTRAINT toolkit_distribution_summaries_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: toolkit_items toolkit_items_toolkit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.toolkit_items
    ADD CONSTRAINT toolkit_items_toolkit_id_fkey FOREIGN KEY (toolkit_id) REFERENCES public.toolkits(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: toolkits toolkits_commodity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.toolkits
    ADD CONSTRAINT toolkits_commodity_id_fkey FOREIGN KEY (commodity_id) REFERENCES public.commodities(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: toolkits toolkits_cover_media_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.toolkits
    ADD CONSTRAINT toolkits_cover_media_id_fkey FOREIGN KEY (cover_media_id) REFERENCES public.media_assets(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: toolkits toolkits_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.toolkits
    ADD CONSTRAINT toolkits_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: toolkits toolkits_programme_scheme_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.toolkits
    ADD CONSTRAINT toolkits_programme_scheme_id_fkey FOREIGN KEY (programme_scheme_id) REFERENCES public.programme_schemes(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: toolkits toolkits_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.toolkits
    ADD CONSTRAINT toolkits_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: videos videos_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.videos
    ADD CONSTRAINT videos_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: videos videos_thumbnail_media_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.videos
    ADD CONSTRAINT videos_thumbnail_media_id_fkey FOREIGN KEY (thumbnail_media_id) REFERENCES public.media_assets(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: videos videos_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.videos
    ADD CONSTRAINT videos_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict NzlMo74XolW0QqIAAi9NRbyziypt7YhOy61dVjYoiY1XMmDDRh5wpxkKEAScViD

